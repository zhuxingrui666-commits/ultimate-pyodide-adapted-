/**
 * Python Server Factory
 * Python 服务器自我复制工厂
 * 创建一个新的 Python 服务器实例，本质上是复制当前实例
 */

declare const API: any;
declare const Module: any;

export interface ServerConfig {
  port?: number;
  host?: string;
  maxConnections?: number;
  timeout?: number;
  enableSSL?: boolean;
  sslCert?: string;
  sslKey?: string;
}

export interface ServerInstance {
  id: string;
  port: number;
  host: string;
  pid: number;
  status: 'starting' | 'running' | 'stopped' | 'error';
  uptime: number;
  requests: number;
  errors: number;
}

export interface ServerFactory {
  createServer: (config?: ServerConfig) => Promise<ServerInstance>;
  cloneServer: (sourceId: string, config?: ServerConfig) => Promise<ServerInstance>;
  listServers: () => ServerInstance[];
  getServer: (id: string) => ServerInstance | undefined;
  stopServer: (id: string) => Promise<void>;
  stopAll: () => Promise<void>;
  restartServer: (id: string) => Promise<ServerInstance>;
  getStats: () => ServerStats;
}

export interface ServerStats {
  totalServers: number;
  runningServers: number;
  stoppedServers: number;
  totalRequests: number;
  totalErrors: number;
  uptime: number;
}

export class PythonServerFactory implements ServerFactory {
  private servers: Map<string, ServerInstanceInternal>;
  private config: ServerConfig;
  private requestIdCounter: number;
  private startTime: number;

  constructor(config: ServerConfig = {}) {
    this.servers = new Map();
    this.requestIdCounter = 0;
    this.startTime = Date.now();
    this.config = {
      port: config.port || 8000,
      host: config.host || 'localhost',
      maxConnections: config.maxConnections || 100,
      timeout: config.timeout || 30000,
      ...config,
    };
  }

  async initialize(): Promise<void> {
    console.log('[ServerFactory] 初始化服务器工厂...');
    
    this.injectPythonServerModule();
    
    console.log('[ServerFactory] ✓ 服务器工厂初始化完成');
  }

  private injectPythonServerModule(): void {
    const pythonCode = `
import sys
import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from js import API

class PyodideRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        
        response = {
            'status': 'running',
            'path': self.path,
            'method': 'GET',
            'headers': dict(self.headers),
        }
        
        self.wfile.write(json.dumps(response).encode())
    
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        
        response = {
            'status': 'ok',
            'received': post_data.decode('utf-8', errors='ignore'),
        }
        
        self.wfile.write(json.dumps(response).encode())
    
    def log_message(self, format, *args):
        pass

class PyodideServer:
    def __init__(self, host='localhost', port=8000):
        self.host = host
        self.port = port
        self.server = None
        self.running = False
    
    def start(self):
        self.server = HTTPServer((self.host, self.port), PyodideRequestHandler)
        self.running = True
        print(f"服务器启动: http://{self.host}:{self.port}")
        self.server.serve_forever()
    
    def stop(self):
        if self.server:
            self.server.shutdown()
            self.running = False
            print(f"服务器停止: http://{self.host}:{self.port}")
    
    def is_running(self):
        return self.running

sys.modules['pyodide_server'] = PyodideServer

print("✓ Python 服务器模块已注入")
`;

    try {
      API.runPythonInternal(pythonCode);
      console.log('[ServerFactory] Python 服务器模块注入成功');
    } catch (error) {
      console.error('[ServerFactory] Python 服务器模块注入失败:', error);
    }
  }

  async createServer(config?: ServerConfig): Promise<ServerInstance> {
    const serverConfig = { ...this.config, ...config };
    const id = this.generateServerId();
    const port = serverConfig.port || this.findAvailablePort();

    console.log(`[ServerFactory] 创建服务器 ${id} (端口: ${port})...`);

    const server: ServerInstanceInternal = {
      id,
      port,
      host: serverConfig.host || 'localhost',
      pid: Date.now(),
      status: 'starting',
      uptime: 0,
      requests: 0,
      errors: 0,
      config: serverConfig,
      handler: this.createServerHandler(id),
      server: null,
    };

    try {
      const http = require('http');
      
      server.server = http.createServer(server.handler);
      
      await new Promise<void>((resolve, reject) => {
        server.server!.listen(port, server.host, () => {
          console.log(`[ServerFactory] ✓ 服务器 ${id} 已启动 (http://${server.host}:${port})`);
          resolve();
        });
        
        server.server!.on('error', (err: any) => {
          console.error(`[ServerFactory] 服务器 ${id} 启动失败:`, err);
          server.status = 'error';
          reject(err);
        });
      });

      server.status = 'running';
      server.startTime = Date.now();
      this.servers.set(id, server);

      this.injectServerPythonAPI(id, server);

      return this.toServerInstance(server);
    } catch (error) {
      server.status = 'error';
      throw error;
    }
  }

  async cloneServer(sourceId: string, config?: ServerConfig): Promise<ServerInstance> {
    const source = this.servers.get(sourceId);
    
    if (!source) {
      throw new Error(`源服务器 ${sourceId} 不存在`);
    }

    console.log(`[ServerFactory] 克隆服务器 ${sourceId}...`);

    const clonedConfig = {
      ...source.config,
      ...config,
      port: config?.port || this.findAvailablePort(),
    };

    return await this.createServer(clonedConfig);
  }

  private createServerHandler(serverId: string): any {
    const factory = this;
    
    return async (req: any, res: any) => {
      const server = this.servers.get(serverId);
      
      if (!server) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Server not found' }));
        return;
      }

      server.requests++;
      const startTime = Date.now();

      try {
        const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
        
        const response = await this.handleRequest(server, {
          method: req.method,
          path: parsedUrl.pathname,
          query: parsedUrl.searchParams,
          headers: req.headers,
          body: req.body,
          serverId,
        });

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(response));

      } catch (error) {
        server.errors++;
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: (error as Error).message }));
      }

      const duration = Date.now() - startTime;
      console.log(`[${serverId}] ${req.method} ${req.url} - ${res.statusCode} (${duration}ms)`);
    };
  }

  private async handleRequest(server: ServerInstanceInternal, request: any): Promise<any> {
    const { method, path } = request;

    if (path === '/status') {
      return {
        id: server.id,
        status: server.status,
        uptime: server.uptime,
        requests: server.requests,
        errors: server.errors,
        port: server.port,
        host: server.host,
      };
    }

    if (path === '/execute') {
      const code = request.query.get('code');
      if (code) {
        try {
          const result = API.runPythonInternal(code);
          return { success: true, result };
        } catch (error) {
          return { success: false, error: (error as Error).message };
        }
      }
      return { error: 'No code provided' };
    }

    if (path === '/info') {
      return {
        id: server.id,
        version: '1.0.0',
        python: API.runPythonInternal('import sys; sys.version'),
        platform: API.runPythonInternal('import platform; platform.platform()'),
      };
    }

    if (path === '/health') {
      return { status: 'healthy', timestamp: Date.now() };
    }

    if (path.startsWith('/python/')) {
      const codePath = path.slice(8);
      try {
        const result = API.runPythonInternal(decodeURIComponent(codePath));
        return { success: true, result };
      } catch (error) {
        return { success: false, error: (error as Error).message };
      }
    }

    return {
      message: 'Pyodide Server',
      endpoints: [
        'GET /status - 服务器状态',
        'GET /info - Python 信息',
        'GET /health - 健康检查',
        'GET /execute?code=<python_code> - 执行 Python 代码',
        'GET /python/<encoded_code> - 执行 Python 代码',
      ],
    };
  }

  private injectServerPythonAPI(serverId: string, server: ServerInstanceInternal): void {
    try {
      API.runPythonInternal(`
import sys

class ServerAPI_${serverId.replace(/-/g, '_')}:
    _server_id = "${serverId}"
    _server_port = ${server.port}
    _server_host = "${server.host}"
    
    @staticmethod
    def get_server_id():
        return ServerAPI_${serverId.replace(/-/g, '_')}._server_id
    
    @staticmethod
    def get_server_info():
        return {
            'id': ServerAPI_${serverId.replace(/-/g, '_')}._server_id,
            'port': ServerAPI_${serverId.replace(/-/g, '_')}._server_port,
            'host': ServerAPI_${serverId.replace(/-/g, '_')}._server_host,
        }
    
    @staticmethod
    def execute_code(code):
        return exec(code)
    
    @staticmethod
    def get_requests():
        from js import API
        server = API._serverFactory.servers.get("${serverId}")
        return server.requests if server else 0
    
    @staticmethod
    def get_errors():
        from js import API
        server = API._serverFactory.servers.get("${serverId}")
        return server.errors if server else 0

sys.modules['server_${serverId.replace(/-/g, '_')}'] = ServerAPI_${serverId.replace(/-/g, '_')}()

print("✓ 服务器 ${serverId} Python API 已注入")
`);
    } catch (error) {
      console.error(`[ServerFactory] 服务器 ${serverId} Python API 注入失败:`, error);
    }
  }

  listServers(): ServerInstance[] {
    return Array.from(this.servers.values()).map(s => this.toServerInstance(s));
  }

  getServer(id: string): ServerInstance | undefined {
    const server = this.servers.get(id);
    return server ? this.toServerInstance(server) : undefined;
  }

  async stopServer(id: string): Promise<void> {
    const server = this.servers.get(id);
    
    if (!server) {
      throw new Error(`服务器 ${id} 不存在`);
    }

    console.log(`[ServerFactory] 停止服务器 ${id}...`);

    if (server.server) {
      await new Promise<void>((resolve) => {
        server.server!.close(() => {
          console.log(`[ServerFactory] ✓ 服务器 ${id} 已停止`);
          resolve();
        });
      });
    }

    server.status = 'stopped';
    server.server = null;
  }

  async stopAll(): Promise<void> {
    console.log('[ServerFactory] 停止所有服务器...');
    
    const stopPromises = Array.from(this.servers.keys()).map(id => 
      this.stopServer(id).catch(err => {
        console.error(`[ServerFactory] 停止 ${id} 失败:`, err);
      })
    );

    await Promise.all(stopPromises);
    
    console.log('[ServerFactory] ✓ 所有服务器已停止');
  }

  async restartServer(id: string): Promise<ServerInstance> {
    const oldServer = this.servers.get(id);
    
    if (!oldServer) {
      throw new Error(`服务器 ${id} 不存在`);
    }

    console.log(`[ServerFactory] 重启服务器 ${id}...`);
    
    await this.stopServer(id);
    
    const newConfig = { ...oldServer.config, port: oldServer.port };
    return await this.createServer(newConfig);
  }

  getStats(): ServerStats {
    const servers = Array.from(this.servers.values());
    
    return {
      totalServers: servers.length,
      runningServers: servers.filter(s => s.status === 'running').length,
      stoppedServers: servers.filter(s => s.status === 'stopped').length,
      totalRequests: servers.reduce((sum, s) => sum + s.requests, 0),
      totalErrors: servers.reduce((sum, s) => sum + s.errors, 0),
      uptime: Date.now() - this.startTime,
    };
  }

  private generateServerId(): string {
    return `server-${Date.now()}-${++this.requestIdCounter}`;
  }

  private findAvailablePort(startPort: number = 8000): number {
    const usedPorts = new Set(Array.from(this.servers.values()).map(s => s.port));
    
    for (let port = startPort; port < startPort + 1000; port++) {
      if (!usedPorts.has(port)) {
        return port;
      }
    }
    
    return startPort + Math.floor(Math.random() * 1000);
  }

  private toServerInstance(server: ServerInstanceInternal): ServerInstance {
    return {
      id: server.id,
      port: server.port,
      host: server.host,
      pid: server.pid,
      status: server.status,
      uptime: server.uptime,
      requests: server.requests,
      errors: server.errors,
    };
  }

  updateServerUptime(): void {
    const now = Date.now();
    for (const server of this.servers.values()) {
      if (server.status === 'running' && server.startTime) {
        server.uptime = now - server.startTime;
      }
    }
  }
}

interface ServerInstanceInternal {
  id: string;
  port: number;
  host: string;
  pid: number;
  status: 'starting' | 'running' | 'stopped' | 'error';
  uptime: number;
  requests: number;
  errors: number;
  config: ServerConfig;
  handler: any;
  server: any;
  startTime?: number;
}

let globalServerFactory: PythonServerFactory | null = null;

export function getServerFactory(config?: ServerConfig): PythonServerFactory {
  if (!globalServerFactory) {
    globalServerFactory = new PythonServerFactory(config);
  }
  return globalServerFactory;
}

export async function initializeServerFactory(config?: ServerConfig): Promise<PythonServerFactory> {
  const factory = getServerFactory(config);
  await factory.initialize();
  
  if (typeof API !== 'undefined') {
    API._serverFactory = factory;
  }
  
  setInterval(() => {
    factory.updateServerUptime();
  }, 1000);
  
  return factory;
}
