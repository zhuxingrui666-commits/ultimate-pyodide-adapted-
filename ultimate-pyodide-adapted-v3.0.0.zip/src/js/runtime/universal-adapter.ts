/**
 * Universal Runtime Adapter
 * 支持多种 JavaScript 运行时环境
 */

declare const API: any;
declare const Module: any;

export type RuntimeType = 'node' | 'deno' | 'bun' | 'browser' | 'worker';

export interface RuntimeCapabilities {
  fs: boolean;
  net: boolean;
  process: boolean;
  crypto: boolean;
  timers: boolean;
  streams: boolean;
}

export interface RuntimeAdapter {
  type: RuntimeType;
  capabilities: RuntimeCapabilities;
  fs: RuntimeFS;
  net: RuntimeNet;
  process: RuntimeProcess;
  env: RuntimeEnv;
  streams: RuntimeStreams;
  fetch: RuntimeFetch;
  timers: RuntimeTimers;
}

export interface RuntimeFS {
  readFile(path: string, encoding?: string): any;
  writeFile(path: string, data: any, encoding?: string): void;
  exists(path: string): boolean;
  mkdir(path: string, recursive?: boolean): void;
  rmdir(path: string, recursive?: boolean): void;
  unlink(path: string): void;
  readdir(path: string): string[];
  stat(path: string): any;
  copyFile(src: string, dest: string): void;
  rename(src: string, dest: string): void;
  chmod(path: string, mode: number): void;
  realpath(path: string): string;
  watch(path: string, callback: (event: string, filename: string) => void): any;
}

export interface RuntimeNet {
  http: {
    request(options: any): Promise<any>;
    get(options: any): Promise<any>;
  };
  https: {
    request(options: any): Promise<any>;
    get(options: any): Promise<any>;
  };
  tcp: {
    createServer(options?: any): any;
    createConnection(options: any): any;
  };
  dns: {
    lookup(hostname: string, options?: any): Promise<any>;
    resolve(hostname: string, rrtype?: string): Promise<any[]>;
  };
}

export interface RuntimeProcess {
  exec(command: string, options?: any): Promise<any>;
  execSync(command: string, options?: any): any;
  spawn(command: string, args?: string[], options?: any): any;
  fork(modulePath: string, args?: string[], options?: any): any;
  env: NodeJS.ProcessEnv;
  cwd(): string;
  chdir(directory: string): void;
  pid: number;
  platform: string;
  arch: string;
}

export interface RuntimeEnv {
  get(key: string): string | undefined;
  set(key: string, value: string): void;
  delete(key: string): void;
  getAll(): NodeJS.ProcessEnv;
}

export interface RuntimeStreams {
  stdin: any;
  stdout: any;
  stderr: any;
}

export interface RuntimeFetch {
  fetch(url: string, options?: any): Promise<any>;
  createClient(options?: any): any;
}

export interface RuntimeTimers {
  setTimeout(callback: () => void, ms: number): any;
  setInterval(callback: () => void, ms: number): any;
  setImmediate(callback: () => void): any;
  clearTimeout(id: any): void;
  clearInterval(id: any): void;
  clearImmediate(id: any): void;
}

class UniversalRuntimeAdapter implements RuntimeAdapter {
  public type: RuntimeType;
  public capabilities: RuntimeCapabilities;
  public fs!: RuntimeFS;
  public net!: RuntimeNet;
  public process!: RuntimeProcess;
  public env!: RuntimeEnv;
  public streams!: RuntimeStreams;
  public fetch!: RuntimeFetch;
  public timers!: RuntimeTimers;

  constructor() {
    this.type = this.detectRuntime();
    this.capabilities = this.detectCapabilities();
    this.initializeAdapters();
  }

  private detectRuntime(): RuntimeType {
    if (typeof window !== 'undefined' && typeof document !== 'undefined') {
      return 'browser';
    }
    
    if (typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope) {
      return 'worker';
    }
    
    if (typeof Deno !== 'undefined') {
      return 'deno';
    }
    
    if (typeof Bun !== 'undefined') {
      return 'bun';
    }
    
    if (typeof process !== 'undefined' && process.versions && process.versions.node) {
      return 'node';
    }
    
    console.warn('[UniversalAdapter] 无法检测运行时，使用默认配置');
    return 'node';
  }

  private detectCapabilities(): RuntimeCapabilities {
    const caps: RuntimeCapabilities = {
      fs: false,
      net: false,
      process: false,
      crypto: false,
      timers: false,
      streams: false,
    };

    switch (this.type) {
      case 'node':
        caps.fs = true;
        caps.net = true;
        caps.process = true;
        caps.crypto = true;
        caps.timers = true;
        caps.streams = true;
        break;

      case 'deno':
        caps.fs = true;
        caps.net = true;
        caps.process = true;
        caps.crypto = true;
        caps.timers = true;
        caps.streams = true;
        break;

      case 'bun':
        caps.fs = true;
        caps.net = true;
        caps.process = true;
        caps.crypto = true;
        caps.timers = true;
        caps.streams = true;
        break;

      case 'browser':
      case 'worker':
        caps.fs = false;
        caps.net = true;
        caps.process = false;
        caps.crypto = typeof crypto !== 'undefined';
        caps.timers = true;
        caps.streams = true;
        break;
    }

    return caps;
  }

  private initializeAdapters(): void {
    console.log(`[UniversalAdapter] 检测到运行时: ${this.type}`);
    console.log('[UniversalAdapter] 能力:', this.capabilities);

    switch (this.type) {
      case 'node':
        this.initializeNodeAdapters();
        break;
      case 'deno':
        this.initializeDenoAdapters();
        break;
      case 'bun':
        this.initializeBunAdapters();
        break;
      case 'browser':
      case 'worker':
        this.initializeBrowserAdapters();
        break;
    }
  }

  private initializeNodeAdapters(): void {
    const nodeFS = require('fs');
    const nodePath = require('path');
    const nodeNet = require('net');
    const nodeHTTP = require('http');
    const nodeHTTPS = require('https');
    const nodeDNS = require('dns');
    const nodeCP = require('child_process');
    const nodeCrypto = require('crypto');

    this.fs = {
      readFile: (filepath: string, encoding?: string) => {
        if (encoding) {
          return nodeFS.readFileSync(filepath, encoding);
        }
        return nodeFS.readFileSync(filepath);
      },
      
      writeFile: (filepath: string, data: any, encoding?: string) => {
        if (encoding) {
          nodeFS.writeFileSync(filepath, data, encoding);
        } else {
          nodeFS.writeFileSync(filepath, data);
        }
      },
      
      exists: (filepath: string) => nodeFS.existsSync(filepath),
      
      mkdir: (filepath: string, recursive = true) => {
        nodeFS.mkdirSync(filepath, { recursive });
      },
      
      rmdir: (filepath: string, recursive = false) => {
        if (recursive) {
          nodeFS.rmSync(filepath, { recursive: true });
        } else {
          nodeFS.rmdirSync(filepath);
        }
      },
      
      unlink: (filepath: string) => nodeFS.unlinkSync(filepath),
      
      readdir: (filepath: string) => nodeFS.readdirSync(filepath),
      
      stat: (filepath: string) => {
        const stats = nodeFS.statSync(filepath);
        return {
          isFile: stats.isFile(),
          isDirectory: stats.isDirectory(),
          isSymbolicLink: stats.isSymbolicLink(),
          size: stats.size,
          mtime: stats.mtime.getTime() / 1000,
          atime: stats.atime.getTime() / 1000,
          ctime: stats.ctime.getTime() / 1000,
          mode: stats.mode,
        };
      },
      
      copyFile: (src: string, dest: string) => nodeFS.copyFileSync(src, dest),
      
      rename: (src: string, dest: string) => nodeFS.renameSync(src, dest),
      
      chmod: (filepath: string, mode: number) => nodeFS.chmodSync(filepath, mode),
      
      realpath: (filepath: string) => nodeFS.realpathSync(filepath),
      
      watch: (filepath: string, callback: (event: string, filename: string) => void) => {
        return nodeFS.watch(filepath, { persistent: false }, (eventType, filename) => {
          callback(eventType, filename || '');
        });
      },
    };

    this.net = {
      http: {
        request: (options: any) => new Promise((resolve, reject) => {
          const req = nodeHTTP.request(options, (res) => resolve(res));
          req.on('error', reject);
          req.end();
        }),
        get: (options: any) => new Promise((resolve, reject) => {
          const req = nodeHTTP.get(options, (res) => resolve(res));
          req.on('error', reject);
        }),
      },
      https: {
        request: (options: any) => new Promise((resolve, reject) => {
          const req = nodeHTTPS.request(options, (res) => resolve(res));
          req.on('error', reject);
          req.end();
        }),
        get: (options: any) => new Promise((resolve, reject) => {
          const req = nodeHTTPS.get(options, (res) => resolve(res));
          req.on('error', reject);
        }),
      },
      tcp: {
        createServer: (options?: any) => nodeNet.createServer(options),
        createConnection: (options: any) => nodeNet.createConnection(options),
      },
      dns: {
        lookup: (hostname: string, options?: any) => new Promise((resolve, reject) => {
          nodeDNS.lookup(hostname, options, (err, address, family) => {
            if (err) reject(err);
            else resolve({ address, family });
          });
        }),
        resolve: (hostname: string, rrtype?: string) => new Promise((resolve, reject) => {
          nodeDNS.resolve(hostname, rrtype, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses);
          });
        }),
      },
    };

    this.process = {
      exec: (command: string, options?: any) => new Promise((resolve, reject) => {
        nodeCP.exec(command, options, (error, stdout, stderr) => {
          if (error) reject({ error, stdout, stderr });
          else resolve({ stdout, stderr });
        });
      }),
      execSync: (command: string, options?: any) => nodeCP.execSync(command, options),
      spawn: (command: string, args?: string[], options?: any) => nodeCP.spawn(command, args, options),
      fork: (modulePath: string, args?: string[], options?: any) => nodeCP.fork(modulePath, args, options),
      env: process.env,
      cwd: () => process.cwd(),
      chdir: (directory: string) => process.chdir(directory),
      pid: process.pid,
      platform: process.platform,
      arch: process.arch,
    };

    this.env = {
      get: (key: string) => process.env[key],
      set: (key: string, value: string) => { process.env[key] = value; },
      delete: (key: string) => { delete process.env[key]; },
      getAll: () => process.env,
    };

    this.streams = {
      stdin: process.stdin,
      stdout: process.stdout,
      stderr: process.stderr,
    };

    this.fetch = {
      fetch: (url: string, options?: any) => fetch(url, options),
      createClient: (options?: any) => {
        return {
          fetch: (url: string, options?: any) => fetch(url, { ...options, client: this.fetch.createClient(options) }),
        };
      },
    };

    this.timers = {
      setTimeout: (callback: () => void, ms: number) => setTimeout(callback, ms),
      setInterval: (callback: () => void, ms: number) => setInterval(callback, ms),
      setImmediate: (callback: () => void) => setImmediate(callback),
      clearTimeout: (id: any) => clearTimeout(id),
      clearInterval: (id: any) => clearInterval(id),
      clearImmediate: (id: any) => clearImmediate(id),
    };

    console.log('[UniversalAdapter] Node.js 适配器已初始化');
  }

  private initializeDenoAdapters(): void {
    console.log('[UniversalAdapter] Deno 适配器初始化中...');
    
    this.fs = {
      readFile: async (filepath: string, encoding?: string) => {
        const data = await Deno.readFile(filepath);
        if (encoding === 'utf8') {
          return new TextDecoder().decode(data);
        }
        return data;
      },
      writeFile: async (filepath: string, data: any, encoding?: string) => {
        if (typeof data === 'string') {
          await Deno.writeTextFile(filepath, data);
        } else {
          await Deno.writeFile(filepath, data);
        }
      },
      exists: (filepath: string) => {
        try {
          Deno.statSync(filepath);
          return true;
        } catch {
          return false;
        }
      },
      mkdir: async (filepath: string, recursive = true) => {
        await Deno.mkdir(filepath, { recursive });
      },
      rmdir: async (filepath: string, recursive = false) => {
        await Deno.remove(filepath, { recursive });
      },
      unlink: async (filepath: string) => {
        await Deno.remove(filepath);
      },
      readdir: (filepath: string) => Array.from(Deno.readDirSync(filepath)).map(entry => entry.name),
      stat: (filepath: string) => {
        const stats = Deno.statSync(filepath);
        return {
          isFile: stats.isFile(),
          isDirectory: stats.isDirectory(),
          isSymbolicLink: stats.isSymbolicLink(),
          size: stats.size,
          mtime: stats.mtime?.getTime() ? stats.mtime.getTime() / 1000 : 0,
        };
      },
      copyFile: (src: string, dest: string) => Deno.copyFileSync(src, dest),
      rename: (src: string, dest: string) => Deno.renameSync(src, dest),
      chmod: (filepath: string, mode: number) => Deno.chmodSync(filepath, mode),
      realpath: (filepath: string) => Deno.realPathSync(filepath),
      watch: (filepath: string, callback: (event: string, filename: string) => void) => {
        const watcher = Deno.watchFile(filepath, { persistent: false });
        (async () => {
          for await (const event of watcher) {
            callback(event.kind, event.paths.join(', '));
          }
        })();
        return watcher;
      },
    };

    this.net = {
      http: {
        request: async (options: any) => {
          const url = typeof options === 'string' ? options : options.url || options.hostname;
          return await fetch(url);
        },
        get: async (options: any) => await fetch(typeof options === 'string' ? options : options.url || options.hostname),
      },
      https: {
        request: async (options: any) => {
          const url = typeof options === 'string' ? options : options.url || options.hostname;
          return await fetch(url);
        },
        get: async (options: any) => await fetch(typeof options === 'string' ? options : options.url || options.hostname),
      },
      tcp: {
        createServer: (options?: any) => Deno.listen(options),
        createConnection: (options: any) => Deno.connect(options),
      },
      dns: {
        lookup: async (hostname: string, options?: any) => {
          const results = await Deno.resolveDns(hostname, 'A');
          return { address: results[0], family: 4 };
        },
        resolve: async (hostname: string, rrtype?: string) => {
          const type = rrtype === 'AAAA' ? 'AAAA' : 'A';
          return await Deno.resolveDns(hostname, type);
        },
      },
    };

    this.process = {
      exec: async (command: string, options?: any) => {
        const proc = Deno.run({
          cmd: command.split(' '),
          stdout: 'piped',
          stderr: 'piped',
        });
        const [stdout, stderr] = await Promise.all([proc.output(), proc.stderrOutput()]);
        proc.close();
        return {
          stdout: new TextDecoder().decode(stdout),
          stderr: new TextDecoder().decode(stderr),
        };
      },
      execSync: (command: string, options?: any) => {
        const proc = Deno.run({
          cmd: command.split(' '),
          stdout: 'piped',
          stderr: 'piped',
        });
        const output = proc.outputSync();
        proc.close();
        return output;
      },
      spawn: (command: string, args?: string[], options?: any) => {
        return Deno.run({
          cmd: [command, ...(args || [])],
          ...options,
        });
      },
      fork: (modulePath: string, args?: string[], options?: any) => {
        const command = `deno run ${args?.join(' ') || ''} ${modulePath}`;
        return Deno.run({
          cmd: command.split(' '),
          ...options,
        });
      },
      env: Deno.env,
      cwd: () => Deno.cwd(),
      chdir: (directory: string) => Deno.chdir(directory),
      pid: Deno.pid,
      platform: Deno.build.os === 'windows' ? 'win32' : Deno.build.os,
      arch: Deno.build.arch,
    };

    this.env = {
      get: (key: string) => Deno.env.get(key),
      set: (key: string, value: string) => Deno.env.set(key, value),
      delete: (key: string) => Deno.env.delete(key),
      getAll: () => Deno.env.toObject(),
    };

    this.streams = {
      stdin: Deno.stdin,
      stdout: Deno.stdout,
      stderr: Deno.stderr,
    };

    this.fetch = {
      fetch: (url: string, options?: any) => fetch(url, options),
      createClient: (options?: any) => fetch,
    };

    this.timers = {
      setTimeout: (callback: () => void, ms: number) => setTimeout(callback, ms),
      setInterval: (callback: () => void, ms: number) => setInterval(callback, ms),
      setImmediate: (callback: () => void) => setImmediate(callback),
      clearTimeout: (id: any) => clearTimeout(id),
      clearInterval: (id: any) => clearInterval(id),
      clearImmediate: (id: any) => clearImmediate(id),
    };

    console.log('[UniversalAdapter] Deno 适配器已初始化');
  }

  private initializeBunAdapters(): void {
    console.log('[UniversalAdapter] Bun 适配器初始化中...');
    
    const bunFS = require('fs');
    const bunNet = require('net');
    const bunHTTP = require('http');
    const bunHTTPS = require('https');
    const bunDNS = require('dns');
    const bunCP = require('child_process');

    this.fs = {
      readFile: (filepath: string, encoding?: string) => {
        if (encoding) {
          return bunFS.readFileSync(filepath, encoding);
        }
        return bunFS.readFileSync(filepath);
      },
      writeFile: (filepath: string, data: any, encoding?: string) => {
        if (encoding) {
          bunFS.writeFileSync(filepath, data, encoding);
        } else {
          bunFS.writeFileSync(filepath, data);
        }
      },
      exists: (filepath: string) => bunFS.existsSync(filepath),
      mkdir: (filepath: string, recursive = true) => {
        bunFS.mkdirSync(filepath, { recursive });
      },
      rmdir: (filepath: string, recursive = false) => {
        if (recursive) {
          bunFS.rmSync(filepath, { recursive: true });
        } else {
          bunFS.rmdirSync(filepath);
        }
      },
      unlink: (filepath: string) => bunFS.unlinkSync(filepath),
      readdir: (filepath: string) => bunFS.readdirSync(filepath),
      stat: (filepath: string) => {
        const stats = bunFS.statSync(filepath);
        return {
          isFile: stats.isFile(),
          isDirectory: stats.isDirectory(),
          isSymbolicLink: stats.isSymbolicLink(),
          size: stats.size,
          mtime: stats.mtime.getTime() / 1000,
          atime: stats.atime.getTime() / 1000,
          ctime: stats.ctime.getTime() / 1000,
          mode: stats.mode,
        };
      },
      copyFile: (src: string, dest: string) => bunFS.copyFileSync(src, dest),
      rename: (src: string, dest: string) => bunFS.renameSync(src, dest),
      chmod: (filepath: string, mode: number) => bunFS.chmodSync(filepath, mode),
      realpath: (filepath: string) => bunFS.realpathSync(filepath),
      watch: (filepath: string, callback: (event: string, filename: string) => void) => {
        return bunFS.watch(filepath, { persistent: false }, (eventType, filename) => {
          callback(eventType, filename || '');
        });
      },
    };

    this.net = {
      http: {
        request: (options: any) => new Promise((resolve, reject) => {
          const req = bunHTTP.request(options, (res) => resolve(res));
          req.on('error', reject);
          req.end();
        }),
        get: (options: any) => new Promise((resolve, reject) => {
          const req = bunHTTP.get(options, (res) => resolve(res));
          req.on('error', reject);
        }),
      },
      https: {
        request: (options: any) => new Promise((resolve, reject) => {
          const req = bunHTTPS.request(options, (res) => resolve(res));
          req.on('error', reject);
          req.end();
        }),
        get: (options: any) => new Promise((resolve, reject) => {
          const req = bunHTTPS.get(options, (res) => resolve(res));
          req.on('error', reject);
        }),
      },
      tcp: {
        createServer: (options?: any) => bunNet.createServer(options),
        createConnection: (options: any) => bunNet.createConnection(options),
      },
      dns: {
        lookup: (hostname: string, options?: any) => new Promise((resolve, reject) => {
          bunDNS.lookup(hostname, options, (err, address, family) => {
            if (err) reject(err);
            else resolve({ address, family });
          });
        }),
        resolve: (hostname: string, rrtype?: string) => new Promise((resolve, reject) => {
          bunDNS.resolve(hostname, rrtype, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses);
          });
        }),
      },
    };

    this.process = {
      exec: (command: string, options?: any) => new Promise((resolve, reject) => {
        bunCP.exec(command, options, (error, stdout, stderr) => {
          if (error) reject({ error, stdout, stderr });
          else resolve({ stdout, stderr });
        });
      }),
      execSync: (command: string, options?: any) => bunCP.execSync(command, options),
      spawn: (command: string, args?: string[], options?: any) => bunCP.spawn(command, args, options),
      fork: (modulePath: string, args?: string[], options?: any) => bunCP.fork(modulePath, args, options),
      env: process.env,
      cwd: () => process.cwd(),
      chdir: (directory: string) => process.chdir(directory),
      pid: process.pid,
      platform: process.platform,
      arch: process.arch,
    };

    this.env = {
      get: (key: string) => process.env[key],
      set: (key: string, value: string) => { process.env[key] = value; },
      delete: (key: string) => { delete process.env[key]; },
      getAll: () => process.env,
    };

    this.streams = {
      stdin: process.stdin,
      stdout: process.stdout,
      stderr: process.stderr,
    };

    this.fetch = {
      fetch: (url: string, options?: any) => fetch(url, options),
      createClient: (options?: any) => fetch,
    };

    this.timers = {
      setTimeout: (callback: () => void, ms: number) => setTimeout(callback, ms),
      setInterval: (callback: () => void, ms: number) => setInterval(callback, ms),
      setImmediate: (callback: () => void) => setImmediate(callback),
      clearTimeout: (id: any) => clearTimeout(id),
      clearInterval: (id: any) => clearInterval(id),
      clearImmediate: (id: any) => clearImmediate(id),
    };

    console.log('[UniversalAdapter] Bun 适配器已初始化');
  }

  private initializeBrowserAdapters(): void {
    console.log('[UniversalAdapter] Browser/Web Worker 适配器初始化中...');

    this.fs = {
      readFile: (filepath: string, encoding?: string) => {
        throw new Error('文件系统在浏览器环境中不可用。请使用 IndexedDB 或其他存储方案。');
      },
      writeFile: (filepath: string, data: any, encoding?: string) => {
        throw new Error('文件系统在浏览器环境中不可用。请使用 IndexedDB 或其他存储方案。');
      },
      exists: (filepath: string) => {
        throw new Error('文件系统在浏览器环境中不可用');
      },
      mkdir: (filepath: string, recursive?: boolean) => {
        throw new Error('文件系统在浏览器环境中不可用');
      },
      rmdir: (filepath: string, recursive?: boolean) => {
        throw new Error('文件系统在浏览器环境中不可用');
      },
      unlink: (filepath: string) => {
        throw new Error('文件系统在浏览器环境中不可用');
      },
      readdir: (filepath: string) => {
        throw new Error('文件系统在浏览器环境中不可用');
      },
      stat: (filepath: string) => {
        throw new Error('文件系统在浏览器环境中不可用');
      },
      copyFile: (src: string, dest: string) => {
        throw new Error('文件系统在浏览器环境中不可用');
      },
      rename: (src: string, dest: string) => {
        throw new Error('文件系统在浏览器环境中不可用');
      },
      chmod: (filepath: string, mode: number) => {
        throw new Error('文件系统在浏览器环境中不可用');
      },
      realpath: (filepath: string) => {
        throw new Error('文件系统在浏览器环境中不可用');
      },
      watch: (filepath: string, callback: (event: string, filename: string) => void) => {
        throw new Error('文件系统在浏览器环境中不可用');
      },
    };

    this.net = {
      http: {
        request: async (options: any) => {
          const url = typeof options === 'string' ? options : options.url || options.hostname;
          return await fetch(url);
        },
        get: async (options: any) => await fetch(typeof options === 'string' ? options : options.url || options.hostname),
      },
      https: {
        request: async (options: any) => {
          const url = typeof options === 'string' ? options : options.url || options.hostname;
          return await fetch(url);
        },
        get: async (options: any) => await fetch(typeof options === 'string' ? options : options.url || options.hostname),
      },
      tcp: {
        createServer: (options?: any) => {
          throw new Error('TCP 套接字在浏览器环境中不可用');
        },
        createConnection: (options: any) => {
          throw new Error('TCP 套接字在浏览器环境中不可用');
        },
      },
      dns: {
        lookup: async (hostname: string, options?: any) => {
          const url = `https://dns.google/resolve?name=${hostname}&type=A`;
          const response = await fetch(url);
          const data = await response.json();
          if (data.Answer && data.Answer.length > 0) {
            return { address: data.Answer[0].data, family: 4 };
          }
          throw new Error('DNS 解析失败');
        },
        resolve: async (hostname: string, rrtype?: string) => {
          const type = rrtype === 'AAAA' ? 28 : 1;
          const url = `https://dns.google/resolve?name=${hostname}&type=${type}`;
          const response = await fetch(url);
          const data = await response.json();
          if (data.Answer) {
            return data.Answer.map((a: any) => a.data);
          }
          return [];
        },
      },
    };

    this.process = {
      exec: (command: string, options?: any) => {
        throw new Error('进程管理在浏览器环境中不可用');
      },
      execSync: (command: string, options?: any) => {
        throw new Error('进程管理在浏览器环境中不可用');
      },
      spawn: (command: string, args?: string[], options?: any) => {
        throw new Error('进程管理在浏览器环境中不可用');
      },
      fork: (modulePath: string, args?: string[], options?: any) => {
        throw new Error('进程管理在浏览器环境中不可用');
      },
      env: {},
      cwd: () => '/',
      chdir: (directory: string) => {
        throw new Error('chdir 在浏览器环境中不可用');
      },
      pid: -1,
      platform: 'browser',
      arch: 'unknown',
    };

    this.env = {
      get: (key: string) => undefined,
      set: (key: string, value: string) => {
        console.warn('环境变量在浏览器环境中无法持久化');
      },
      delete: (key: string) => {
        console.warn('环境变量在浏览器环境中无法删除');
      },
      getAll: () => ({}),
    };

    this.streams = {
      stdin: null,
      stdout: console,
      stderr: console,
    };

    this.fetch = {
      fetch: (url: string, options?: any) => fetch(url, options),
      createClient: (options?: any) => fetch,
    };

    this.timers = {
      setTimeout: (callback: () => void, ms: number) => setTimeout(callback, ms),
      setInterval: (callback: () => void, ms: number) => setInterval(callback, ms),
      setImmediate: (callback: () => void) => setImmediate(callback),
      clearTimeout: (id: any) => clearTimeout(id),
      clearInterval: (id: any) => clearInterval(id),
      clearImmediate: (id: any) => clearImmediate(id),
    };

    console.log('[UniversalAdapter] Browser/Web Worker 适配器已初始化');
  }

  getCapabilities(): RuntimeCapabilities {
    return { ...this.capabilities };
  }

  isCapable(capability: keyof RuntimeCapabilities): boolean {
    return this.capabilities[capability];
  }

  getRuntimeInfo(): any {
    return {
      type: this.type,
      capabilities: this.capabilities,
      platform: this.process?.platform || 'unknown',
      arch: this.process?.arch || 'unknown',
      version: this.process?.env?.['NODE_VERSION'] || 'unknown',
    };
  }
}

let globalRuntimeAdapter: UniversalRuntimeAdapter | null = null;

export function getRuntimeAdapter(): UniversalRuntimeAdapter {
  if (!globalRuntimeAdapter) {
    globalRuntimeAdapter = new UniversalRuntimeAdapter();
    
    if (typeof API !== 'undefined') {
      API._runtimeAdapter = globalRuntimeAdapter;
      API._runtimeCapabilities = globalRuntimeAdapter.getCapabilities();
      API._runtimeInfo = globalRuntimeAdapter.getRuntimeInfo();
    }
  }
  return globalRuntimeAdapter;
}

export function initializeRuntimeAdapter(): UniversalRuntimeAdapter {
  return getRuntimeAdapter();
}
