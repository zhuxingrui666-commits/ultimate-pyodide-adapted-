/**
 * Pyodide Node.js Backend Loader
 * 统一加载器，整合所有后端适配器
 */

import { NodeJSBackendAdapter, type BackendConfig } from './nodejs-backend';
import { FullFileSystemAdapter, type FileSystemOptions } from './fs/full-filesystem';
import { FullNetworkAdapter, type NetworkOptions } from './network/full-network';
import { ProcessAdapter, type ProcessOptions } from './process/process-adapter';

declare const loadPyodide: any;
declare const Module: any;
declare const API: any;

export interface PyodideNodeOptions {
  backend?: Partial<BackendConfig>;
  filesystem?: Partial<FileSystemOptions>;
  network?: Partial<NetworkOptions>;
  process?: Partial<ProcessOptions>;
  indexURL?: string;
  packageCacheDir?: string;
}

export interface PyodideInstance {
  pyodide: any;
  backend: NodeJSBackendAdapter;
  filesystem: FullFileSystemAdapter;
  network: FullNetworkAdapter;
  process: ProcessAdapter;
  load: () => Promise<PyodideInstance>;
  runPython: (code: string) => any;
  runPythonAsync: (code: string) => Promise<any>;
  globals: any;
  loadPackage: (packages: string | string[]) => Promise<void>;
}

class PyodideNodeLoader {
  private pyodideInstance: any = null;
  private backendAdapter: NodeJSBackendAdapter | null = null;
  private fsAdapter: FullFileSystemAdapter | null = null;
  private networkAdapter: FullNetworkAdapter | null = null;
  private processAdapter: ProcessAdapter | null = null;
  private options: PyodideNodeOptions;
  private loaded: boolean = false;

  constructor(options: PyodideNodeOptions = {}) {
    this.options = {
      backend: {},
      filesystem: {},
      network: {},
      process: {},
      ...options,
    };
  }

  async load(): Promise<PyodideNodeInstance> {
    if (this.loaded) {
      console.warn('[PyodideNode] 警告: Pyodide 已经加载');
      return this.createInstance();
    }

    console.log('[PyodideNode] 开始加载 Pyodide...');

    try {
      const indexURL = this.options.indexURL || 'https://cdn.jsdelivr.net/pyodide/v0.26.0/full/';
      
      console.log('[PyodideNode] 加载 Pyodide 核心...');
      this.pyodideInstance = await loadPyodide({
        indexURL: indexURL,
      });

      console.log('[PyodideNode] Pyodide 核心加载完成');
      console.log(`[PyodideNode] Python 版本: ${this.pyodideInstance.version}`);

      console.log('[PyodideNode] 初始化后端适配器...');
      
      this.backendAdapter = new NodeJSBackendAdapter(this.options.backend);
      await this.backendAdapter.initialize();

      console.log('[PyodideNode] 初始化文件系统适配器...');
      this.fsAdapter = new FullFileSystemAdapter(this.options.filesystem);
      this.fsAdapter.initialize();

      console.log('[PyodideNode] 初始化网络适配器...');
      this.networkAdapter = new FullNetworkAdapter(this.options.network);
      this.networkAdapter.initialize();

      console.log('[PyodideNode] 初始化进程适配器...');
      this.processAdapter = new ProcessAdapter(this.options.process);
      this.processAdapter.initialize();

      console.log('[PyodideNode] 注入 Python API...');
      await this.injectPythonAPI();

      this.loaded = true;
      console.log('[PyodideNode] ✓ Pyodide 加载完成');
      console.log('[PyodideNode] ✓ 所有适配器初始化完成');
      console.log('[PyodideNode] ✓ Python 在 Node.js 后端运行，具有完整系统权限');

      return this.createInstance();

    } catch (error) {
      console.error('[PyodideNode] 加载失败:', error);
      throw error;
    }
  }

  private async injectPythonAPI(): Promise<void> {
    const pythonSetupCode = `
import sys
from js import API

class PyodideNodeAPI:
    FS = API._nodeFS
    Network = API._nodeNetwork
    Process = API._nodeProcess
    Env = API._nodeEnvironment
    
    @staticmethod
    def read_file(filepath, encoding=None):
        return API._nodeFS.readFile(filepath, encoding)
    
    @staticmethod
    def write_file(filepath, data, encoding=None):
        return API._nodeFS.writeFile(filepath, data, encoding)
    
    @staticmethod
    def list_dir(dirpath):
        return list(API._nodeFS.readdir(dirpath))
    
    @staticmethod
    def file_exists(filepath):
        return API._nodeFS.exists(filepath)
    
    @staticmethod
    def make_dir(dirpath, recursive=True):
        return API._nodeFS.mkdir(dirpath, recursive)
    
    @staticmethod
    def remove_dir(dirpath, recursive=False):
        return API._nodeFS.rmdir(dirpath, recursive)
    
    @staticmethod
    def delete_file(filepath):
        return API._nodeFS.unlink(filepath)
    
    @staticmethod
    def file_stat(filepath):
        return API._nodeFS.stat(filepath)
    
    @staticmethod
    async def http_get(url):
        import asyncio
        return await asyncio.ensure_future(API._nodeNetwork.http.request(url))
    
    @staticmethod
    async def http_post(url, data=None):
        import asyncio
        return await asyncio.ensure_future(API._nodeNetwork.http.request(url))
    
    @staticmethod
    def exec_command(command, options=None):
        return API._nodeProcess.exec(command, options)
    
    @staticmethod
    def exec_command_sync(command, options=None):
        return API._nodeProcess.execSync(command, options)
    
    @staticmethod
    def spawn_process(command, args=None, options=None):
        return API._nodeProcess.spawn(command, args, options)
    
    @staticmethod
    def get_env():
        return API._nodeEnvironment.env
    
    @staticmethod
    def get_cwd():
        return API._nodeEnvironment.cwd
    
    @staticmethod
    def chdir(directory):
        return API._nodeEnvironment.cwd(directory)
    
    @staticmethod
    def get_platform():
        return API._nodeEnvironment.platform
    
    @staticmethod
    def get_pid():
        return API._processInfo.pid
    
    @staticmethod
    def get_memory_usage():
        return API._processInfo.memoryUsage()

sys.modules['pyodide_node'] = PyodideNodeAPI()

print("✓ Pyodide Node.js API 注入成功")
print("  - 完整文件系统访问: PyodideNodeAPI.FS")
print("  - 完整网络访问: PyodideNodeAPI.Network")
print("  - 进程管理: PyodideNodeAPI.Process")
print("  - 环境变量: PyodideNodeAPI.Env")
`;

    try {
      await this.pyodideInstance.runPythonAsync(pythonSetupCode);
      console.log('[PyodideNode] Python API 注入完成');
    } catch (error) {
      console.error('[PyodideNode] Python API 注入失败:', error);
      throw error;
    }
  }

  private createInstance(): PyodideNodeInstance {
    const instance = {
      pyodide: this.pyodideInstance,
      backend: this.backendAdapter!,
      filesystem: this.fsAdapter!,
      network: this.networkAdapter!,
      process: this.processAdapter!,

      runPython: (code: string) => {
        return this.pyodideInstance.runPython(code);
      },

      runPythonAsync: async (code: string) => {
        return await this.pyodideInstance.runPythonAsync(code);
      },

      globals: this.pyodideInstance.globals,

      loadPackage: async (packages: string | string[]) => {
        const pkgArray = Array.isArray(packages) ? packages : [packages];
        await this.pyodideInstance.loadPackage(pkgArray);
      },

      load: async () => {
        return this.load();
      },
    };

    return instance;
  }
}

export interface PyodideNodeInstance {
  pyodide: any;
  backend: NodeJSBackendAdapter;
  filesystem: FullFileSystemAdapter;
  network: FullNetworkAdapter;
  process: ProcessAdapter;
  runPython: (code: string) => any;
  runPythonAsync: (code: string) => Promise<any>;
  globals: any;
  loadPackage: (packages: string | string[]) => Promise<void>;
  load: () => Promise<PyodideNodeInstance>;
}

export async function loadPyodideNode(options?: PyodideNodeOptions): Promise<PyodideNodeInstance> {
  const loader = new PyodideNodeLoader(options);
  return await loader.load();
}

export { NodeJSBackendAdapter } from './nodejs-backend';
export { FullFileSystemAdapter } from './fs/full-filesystem';
export { FullNetworkAdapter } from './network/full-network';
export { ProcessAdapter } from './process/process-adapter';
