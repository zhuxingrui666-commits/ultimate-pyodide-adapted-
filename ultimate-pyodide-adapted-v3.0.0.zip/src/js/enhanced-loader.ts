/**
 * Enhanced Pyodide Loader
 * 整合所有增强功能：跨运行时、完整标准库、包管理等
 */

declare const loadPyodide: any;
declare const Module: any;
declare const API: any;

export interface EnhancedPyodideOptions {
  indexURL?: string;
  packageCacheDir?: string;
  
  runtime?: {
    type?: 'auto' | 'node' | 'deno' | 'bun' | 'browser';
    enableFullFS?: boolean;
    enableFullNetwork?: boolean;
    enableProcessAccess?: boolean;
  };
  
  packages?: {
    enableEnhancedManager?: boolean;
    enableLazyLoading?: boolean;
    cacheSize?: number;
    preloadPackages?: string[];
  };
  
  stdlib?: {
    enableFullStdlib?: boolean;
    preloadEssential?: boolean;
    lazyModules?: string[];
  };
  
  cache?: {
    enabled?: boolean;
    maxSize?: number;
    ttl?: number;
    strategy?: 'lru' | 'lfu' | 'fifo';
  };
}

export interface EnhancedPyodideInstance {
  pyodide: any;
  runtime: any;
  packages: any;
  stdlib: any;
  cache: any;
  
  runPython(code: string): any;
  runPythonAsync(code: string): Promise<any>;
  loadPackage(packages: string | string[]): Promise<any>;
  searchPackages(query: string): Promise<any[]>;
  
  getRuntimeInfo(): any;
  getPackageInfo(name?: string): any;
  getStdlibReport(): string;
  getCacheStats(): any;
  
  preload(packages: string | string[]): void;
  clearCache(): void;
  cleanup(): void;
}

class EnhancedPyodideLoader {
  private options: EnhancedPyodideOptions;
  private runtimeAdapter: any = null;
  private packageManager: any = null;
  private stdlibManager: any = null;
  private cacheManager: any = null;
  private lazyLoader: any = null;
  private pyodide: any = null;
  private loaded: boolean = false;

  constructor(options: EnhancedPyodideOptions = {}) {
    this.options = this.normalizeOptions(options);
  }

  private normalizeOptions(options: EnhancedPyodideOptions): EnhancedPyodideOptions {
    return {
      indexURL: options.indexURL || 'https://cdn.jsdelivr.net/pyodide/v0.26.0/full/',
      packageCacheDir: options.packageCacheDir,
      
      runtime: {
        type: options.runtime?.type || 'auto',
        enableFullFS: options.runtime?.enableFullFS ?? true,
        enableFullNetwork: options.runtime?.enableFullNetwork ?? true,
        enableProcessAccess: options.runtime?.enableProcessAccess ?? true,
      },
      
      packages: {
        enableEnhancedManager: options.packages?.enableEnhancedManager ?? true,
        enableLazyLoading: options.packages?.enableLazyLoading ?? true,
        cacheSize: options.packages?.cacheSize || 100 * 1024 * 1024,
        preloadPackages: options.packages?.preloadPackages || [],
      },
      
      stdlib: {
        enableFullStdlib: options.stdlib?.enableFullStdlib ?? true,
        preloadEssential: options.stdlib?.preloadEssential ?? true,
        lazyModules: options.stdlib?.lazyModules || [],
      },
      
      cache: {
        enabled: options.cache?.enabled ?? true,
        maxSize: options.cache?.maxSize || 100 * 1024 * 1024,
        ttl: options.cache?.ttl || 3600000,
        strategy: options.cache?.strategy || 'lru',
      },
    };
  }

  async load(): Promise<EnhancedPyodideInstance> {
    if (this.loaded) {
      console.warn('[EnhancedLoader] Pyodide 已经加载');
      return this.createInstance();
    }

    console.log('[EnhancedLoader] 开始加载增强版 Pyodide...');
    console.log('[EnhancedLoader] 选项:', this.options);

    try {
      console.log('[EnhancedLoader] 1/5 加载 Pyodide 核心...');
      this.pyodide = await loadPyodide({
        indexURL: this.options.indexURL,
        packageCacheDir: this.options.packageCacheDir,
      });
      console.log('[EnhancedLoader] ✓ Pyodide 核心加载完成');

      console.log('[EnhancedLoader] 2/5 初始化运行时适配器...');
      await this.initializeRuntime();
      console.log('[EnhancedLoader] ✓ 运行时适配器初始化完成');

      console.log('[EnhancedLoader] 3/5 初始化包管理器...');
      await this.initializePackages();
      console.log('[EnhancedLoader] ✓ 包管理器初始化完成');

      console.log('[EnhancedLoader] 4/5 初始化标准库...');
      await this.initializeStdlib();
      console.log('[EnhancedLoader] ✓ 标准库初始化完成');

      console.log('[EnhancedLoader] 5/5 初始化缓存系统...');
      await this.initializeCache();
      console.log('[EnhancedLoader] ✓ 缓存系统初始化完成');

      console.log('[EnhancedLoader] 注入 Python API...');
      await this.injectPythonAPI();

      this.loaded = true;

      console.log('[EnhancedLoader] ✓ 增强版 Pyodide 加载完成');
      console.log('');
      console.log('[EnhancedLoader] 功能已启用:');
      console.log('  ✓ 跨运行时支持:', this.runtimeAdapter?.type || 'unknown');
      console.log('  ✓ 完整文件系统:', this.options.runtime?.enableFullFS);
      console.log('  ✓ 完整网络:', this.options.runtime?.enableFullNetwork);
      console.log('  ✓ 进程管理:', this.options.runtime?.enableProcessAccess);
      console.log('  ✓ 增强包管理:', this.options.packages?.enableEnhancedManager);
      console.log('  ✓ 懒加载:', this.options.packages?.enableLazyLoading);
      console.log('  ✓ 完整标准库:', this.options.stdlib?.enableFullStdlib);
      console.log('  ✓ 智能缓存:', this.options.cache?.enabled);
      console.log('');

      return this.createInstance();

    } catch (error) {
      console.error('[EnhancedLoader] 加载失败:', error);
      throw error;
    }
  }

  private async initializeRuntime(): Promise<void> {
    const { getRuntimeAdapter } = await import('./runtime/universal-adapter');
    this.runtimeAdapter = getRuntimeAdapter();

    if (typeof API !== 'undefined') {
      API._runtimeAdapter = this.runtimeAdapter;
    }

    const backendConfig = {
      enableFullFS: this.options.runtime?.enableFullFS,
      enableFullNetwork: this.options.runtime?.enableFullNetwork,
      enableProcessAccess: this.options.runtime?.enableProcessAccess,
    };

    if (typeof API !== 'undefined' && API.initializeNodeBackend) {
      await API.initializeNodeBackend(backendConfig);
    }
  }

  private async initializePackages(): Promise<void> {
    if (!this.options.packages?.enableEnhancedManager) {
      console.log('[EnhancedLoader] 增强包管理器已禁用');
      return;
    }

    const { initializeEnhancedPackageManager } = await import('./package/enhanced-package-manager');
    this.packageManager = initializeEnhancedPackageManager(this.pyodide, {
      cacheDir: this.options.packageCacheDir || './.pyodide_cache',
      enableLazyLoading: this.options.packages?.enableLazyLoading,
    });

    if (this.options.packages?.preloadPackages) {
      console.log('[EnhancedLoader] 预加载包:', this.options.packages.preloadPackages);
      const { LazyLoader } = await import('./package/lazy-cache');
      this.lazyLoader = new LazyLoader(this.packageManager);
      this.lazyLoader.preload(this.options.packages.preloadPackages);
    }
  }

  private async initializeStdlib(): Promise<void> {
    if (!this.options.stdlib?.enableFullStdlib) {
      console.log('[EnhancedLoader] 完整标准库已禁用');
      return;
    }

    const { initializeStdlibManager } = await import('./stdlib/standard-library-manager');
    this.stdlibManager = initializeStdlibManager();

    if (this.options.stdlib?.preloadEssential) {
      console.log('[EnhancedLoader] 预加载核心标准库...');
      await this.stdlibManager.preloadEssentialModules();
    }

    if (this.options.stdlib?.lazyModules?.length) {
      console.log('[EnhancedLoader] 配置懒加载模块:', this.options.stdlib.lazyModules);
    }
  }

  private async initializeCache(): Promise<void> {
    if (!this.options.cache?.enabled) {
      console.log('[EnhancedLoader] 缓存系统已禁用');
      return;
    }

    const { initializeCacheManager } = await import('./package/lazy-cache');
    this.cacheManager = initializeCacheManager({
      enabled: this.options.cache?.enabled,
      cacheSize: this.options.cache?.maxSize,
      ttl: this.options.cache?.ttl,
      strategy: this.options.cache?.strategy,
    });

    setInterval(() => {
      if (this.cacheManager) {
        this.cacheManager.cleanup();
      }
    }, 60000);
  }

  private async injectPythonAPI(): Promise<void> {
    const pythonCode = `
import sys
from js import API

class EnhancedPyodideAPI:
    @staticmethod
    def get_runtime_info():
        if hasattr(API, '_runtimeAdapter'):
            return API._runtimeAdapter.getRuntimeInfo()
        return {}
    
    @staticmethod
    def get_package_info(name=None):
        if hasattr(API, '_enhancedPackageManager'):
            if name:
                return API._enhancedPackageManager.getPackageInfo(name)
            return API._enhancedPackageManager.getInstalledPackages()
        return []
    
    @staticmethod
    def get_stdlib_report():
        if hasattr(API, '_stdlibManager'):
            return API._stdlibManager.generateStdlibReport()
        return "标准库管理器不可用"
    
    @staticmethod
    def get_cache_stats():
        if hasattr(API, '_cacheManager'):
            return API._cacheManager.getStats()
        return {}
    
    @staticmethod
    def clear_cache():
        if hasattr(API, '_cacheManager'):
            API._cacheManager.clear()
            print("缓存已清空")
    
    @staticmethod
    def search_stdlib(query):
        if hasattr(API, '_stdlibManager'):
            return API._stdlibManager.searchModules(query)
        return []
    
    @staticmethod
    def preload_packages(packages):
        if hasattr(API, '_lazyLoader'):
            API._lazyLoader.preload(packages)
            print(f"已预加载: {packages}")
        else:
            print("懒加载器不可用")

sys.modules['enhanced_pyodide'] = EnhancedPyodideAPI()

print("✓ Enhanced Pyodide API 注入成功")
`;

    try {
      await this.pyodide.runPythonAsync(pythonCode);
      console.log('[EnhancedLoader] Python API 注入成功');
    } catch (error) {
      console.error('[EnhancedLoader] Python API 注入失败:', error);
    }
  }

  private createInstance(): EnhancedPyodideInstance {
    const instance: EnhancedPyodideInstance = {
      pyodide: this.pyodide,
      runtime: this.runtimeAdapter,
      packages: this.packageManager,
      stdlib: this.stdlibManager,
      cache: this.cacheManager,

      runPython: (code: string) => {
        return this.pyodide.runPython(code);
      },

      runPythonAsync: async (code: string) => {
        return await this.pyodide.runPythonAsync(code);
      },

      loadPackage: async (packages: string | string[]) => {
        if (this.packageManager) {
          return await this.packageManager.installPackage(packages);
        }
        return await this.pyodide.loadPackage(packages);
      },

      searchPackages: async (query: string) => {
        if (this.packageManager) {
          return await this.packageManager.searchPackages(query);
        }
        return [];
      },

      getRuntimeInfo: () => {
        if (this.runtimeAdapter) {
          return this.runtimeAdapter.getRuntimeInfo();
        }
        return {};
      },

      getPackageInfo: (name?: string) => {
        if (this.packageManager) {
          if (name) {
            return this.packageManager.getPackageInfo(name);
          }
          return this.packageManager.getInstalledPackages();
        }
        return [];
      },

      getStdlibReport: () => {
        if (this.stdlibManager) {
          return this.stdlibManager.generateStdlibReport();
        }
        return '标准库管理器不可用';
      },

      getCacheStats: () => {
        if (this.cacheManager) {
          return this.cacheManager.getStats();
        }
        return {};
      },

      preload: (packages: string | string[]) => {
        if (this.lazyLoader) {
          this.lazyLoader.preload(packages);
        }
      },

      clearCache: () => {
        if (this.cacheManager) {
          this.cacheManager.clear();
        }
      },

      cleanup: () => {
        if (this.cacheManager) {
          this.cacheManager.cleanup();
        }
      },
    };

    return instance;
  }

  isLoaded(): boolean {
    return this.loaded;
  }

  getOptions(): EnhancedPyodideOptions {
    return { ...this.options };
  }
}

export async function loadEnhancedPyodide(
  options?: EnhancedPyodideOptions
): Promise<EnhancedPyodideInstance> {
  const loader = new EnhancedPyodideLoader(options);
  return await loader.load();
}

export class EnhancedPyodide {
  private instance: EnhancedPyodideInstance | null = null;

  constructor(private options: EnhancedPyodideOptions = {}) {}

  async load(): Promise<EnhancedPyodideInstance> {
    if (this.instance) {
      return this.instance;
    }
    
    this.instance = await loadEnhancedPyodide(this.options);
    return this.instance;
  }

  getInstance(): EnhancedPyodideInstance | null {
    return this.instance;
  }
}

export { EnhancedPyodideLoader };
