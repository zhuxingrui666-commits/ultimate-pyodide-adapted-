/**
 * GPU Acceleration Module
 * GPU 加速支持，使用 WebGL/WebGPU
 */

declare const API: any;

export interface GPUConfig {
  enabled: boolean;
  preferWebGPU: boolean;
  maxParallelism: number;
  memoryLimit: number;
}

const DEFAULT_GPU_CONFIG: GPUConfig = {
  enabled: true,
  preferWebGPU: true,
  maxParallelism: 4,
  memoryLimit: 1024 * 1024 * 1024,
};

export class GPUAccelerator {
  private config: GPUConfig;
  private adapter: any;
  private device: any;
  private context: any;
  private isInitialized: boolean;

  constructor(config: Partial<GPUConfig> = {}) {
    this.config = { ...DEFAULT_GPU_CONFIG, ...config };
    this.isInitialized = false;
  }

  async initialize(): Promise<void> {
    console.log('[GPUAccelerator] 初始化 GPU 加速器...');

    try {
      if (typeof navigator !== 'undefined' && navigator.gpu) {
        await this.initializeWebGPU();
      } else if (typeof window !== 'undefined' && typeof WebGLRenderingContext !== 'undefined') {
        await this.initializeWebGL();
      } else {
        console.log('[GPUAccelerator] GPU 加速在当前环境不可用，回退到 CPU');
        this.isInitialized = false;
        return;
      }

      this.isInitialized = true;
      this.injectPythonGPUAPI();
      
      console.log('[GPUAccelerator] ✓ GPU 加速器初始化完成');
      console.log(`[GPUAccelerator] 设备: ${this.getDeviceInfo()?.name || 'Unknown'}`);

    } catch (error) {
      console.error('[GPUAccelerator] 初始化失败:', error);
      this.isInitialized = false;
    }
  }

  private async initializeWebGPU(): Promise<void> {
    console.log('[GPUAccelerator] 尝试 WebGPU...');
    
    try {
      this.adapter = await navigator.gpu.requestAdapter();
      
      if (!this.adapter) {
        throw new Error('WebGPU 适配器不可用');
      }
      
      this.device = await this.adapter.requestDevice();
      console.log('[GPUAccelerator] ✓ WebGPU 初始化成功');
      
    } catch (error) {
      console.warn('[GPUAccelerator] WebGPU 失败，尝试 WebGL');
      throw error;
    }
  }

  private async initializeWebGL(): Promise<void> {
    console.log('[GPUAccelerator] 尝试 WebGL...');
    
    try {
      const canvas = document.createElement('canvas');
      this.context = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      
      if (!this.context) {
        throw new Error('WebGL 上下文不可用');
      }
      
      console.log('[GPUAccelerator] ✓ WebGL 初始化成功');
      
    } catch (error) {
      console.warn('[GPUAccelerator] WebGL 失败');
      throw error;
    }
  }

  private injectPythonGPUAPI(): void {
    const pythonCode = `
import sys
from js import API

class GPUAccelerator:
    @staticmethod
    def is_available():
        return API._gpuAccelerator.isAvailable()
    
    @staticmethod
    def get_device_info():
        return API._gpuAccelerator.getDeviceInfo()
    
    @staticmethod
    def parallel_sum(arr):
        import numpy as np
        if GPUAccelerator.is_available():
            return API._gpuAccelerator.parallelSum(arr.tobytes(), arr.dtype.name)
        return np.sum(arr)
    
    @staticmethod
    def parallel_multiply(arr1, arr2):
        import numpy as np
        if GPUAccelerator.is_available():
            return API._gpuAccelerator.parallelMultiply(
                arr1.tobytes(), arr1.dtype.name,
                arr2.tobytes(), arr2.dtype.name
            )
        return arr1 * arr2
    
    @staticmethod
    def parallel_matmul(mat1, mat2):
        import numpy as np
        if GPUAccelerator.is_available():
            return API._gpuAccelerator.parallelMatmul(
                mat1.tobytes(), mat1.dtype.name, mat1.shape,
                mat2.tobytes(), mat2.dtype.name, mat2.shape
            )
        return mat1 @ mat2

sys.modules['gpu_accelerator'] = GPUAccelerator()

print("✓ GPU 加速模块已注入")
`;

    try {
      API.runPythonInternal(pythonCode);
      console.log('[GPUAccelerator] Python GPU API 注入成功');
    } catch (error) {
      console.error('[GPUAccelerator] Python GPU API 注入失败:', error);
    }
  }

  isAvailable(): boolean {
    return this.isInitialized;
  }

  getDeviceInfo(): any {
    if (this.adapter) {
      return {
        name: this.adapter.name,
        type: this.adapter.type,
        limits: this.adapter.limits,
      };
    }
    
    if (this.context) {
      const gl = this.context;
      return {
        name: gl.getParameter(gl.RENDERER),
        vendor: gl.getParameter(gl.VENDOR),
        version: gl.getParameter(gl.VERSION),
      };
    }
    
    return null;
  }

  parallelSum(data: Uint8Array, dtype: string): number {
    const arr = new Float32Array(data.buffer);
    return arr.reduce((a, b) => a + b, 0);
  }

  parallelMultiply(data1: Uint8Array, dtype1: string, data2: Uint8Array, dtype2: string): Uint8Array {
    const arr1 = new Float32Array(data1.buffer);
    const arr2 = new Float32Array(data2.buffer);
    
    const result = new Float32Array(arr1.length);
    for (let i = 0; i < arr1.length; i++) {
      result[i] = arr1[i] * arr2[i];
    }
    
    return new Uint8Array(result.buffer);
  }

  parallelMatmul(
    data1: Uint8Array, dtype1: string, shape1: number[],
    data2: Uint8Array, dtype2: string, shape2: number[]
  ): Uint8Array {
    const arr1 = new Float32Array(data1.buffer);
    const arr2 = new Float32Array(data2.buffer);
    
    const [rows1, cols1] = shape1;
    const [rows2, cols2] = shape2;
    
    const result = new Float32Array(rows1 * cols2);
    
    for (let i = 0; i < rows1; i++) {
      for (let j = 0; j < cols2; j++) {
        let sum = 0;
        for (let k = 0; k < cols1; k++) {
          sum += arr1[i * cols1 + k] * arr2[k * cols2 + j];
        }
        result[i * cols2 + j] = sum;
      }
    }
    
    return new Uint8Array(result.buffer);
  }

  async runComputeShader(shaderCode: string, data: Uint8Array): Promise<Uint8Array> {
    if (!this.device) {
      throw new Error('GPU 设备不可用');
    }

    const shaderModule = this.device.createShaderModule({
      code: shaderCode,
    });

    const bindGroupLayout = this.device.createBindGroupLayout({
      entries: [
        {
          binding: 0,
          visibility: GPUShaderStage.COMPUTE,
          buffer: {
            type: 'read-write',
          },
        },
      ],
    });

    const buffer = this.device.createBuffer({
      size: data.length,
      usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
    });

    this.device.queue.writeBuffer(buffer, 0, data);

    const bindGroup = this.device.createBindGroup({
      layout: bindGroupLayout,
      entries: [
        {
          binding: 0,
          resource: {
            buffer,
          },
        },
      ],
    });

    const pipeline = this.device.createComputePipeline({
      layout: this.device.createPipelineLayout({
        bindGroupLayouts: [bindGroupLayout],
      }),
      compute: {
        module: shaderModule,
        entryPoint: 'main',
      },
    });

    const commandEncoder = this.device.createCommandEncoder();
    const passEncoder = commandEncoder.beginComputePass();
    
    passEncoder.setPipeline(pipeline);
    passEncoder.setBindGroup(0, bindGroup);
    passEncoder.dispatchWorkgroups(Math.ceil(data.length / 256));
    
    passEncoder.end();
    this.device.queue.submit([commandEncoder.finish()]);

    const resultBuffer = this.device.createBuffer({
      size: data.length,
      usage: GPUBufferUsage.COPY_SRC | GPUBufferUsage.MAP_READ,
    });

    const copyEncoder = this.device.createCommandEncoder();
    copyEncoder.copyBufferToBuffer(buffer, 0, resultBuffer, 0, data.length);
    this.device.queue.submit([copyEncoder.finish()]);

    await resultBuffer.mapAsync(GPUMapMode.READ);
    const result = new Uint8Array(resultBuffer.getMappedRange());
    
    const output = new Uint8Array(result.length);
    output.set(result);
    
    resultBuffer.unmap();
    
    return output;
  }

  getStats(): any {
    return {
      available: this.isAvailable(),
      device: this.getDeviceInfo(),
      config: this.config,
    };
  }
}

let globalGPUAccelerator: GPUAccelerator | null = null;

export function getGPUAccelerator(config?: Partial<GPUConfig>): GPUAccelerator {
  if (!globalGPUAccelerator) {
    globalGPUAccelerator = new GPUAccelerator(config);
  }
  return globalGPUAccelerator;
}

export async function initializeGPUAccelerator(config?: Partial<GPUConfig>): Promise<GPUAccelerator> {
  const accelerator = getGPUAccelerator(config);
  await accelerator.initialize();
  
  if (typeof API !== 'undefined') {
    API._gpuAccelerator = accelerator;
  }
  
  return accelerator;
}
