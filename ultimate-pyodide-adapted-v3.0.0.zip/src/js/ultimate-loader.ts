/**
 * Ultimate Pyodide Loader v3.0
 * 完整性能优化版 - 对标原生 Python
 * 支持：多线程、多进程、性能优化、自动服务器
 */

declare const loadPyodide: any;
declare const Module: any;
declare const API: any;

export interface UltimatePyodideOptions {
  indexURL?: string;
  packageCacheDir?: string;
  
  runtime?: {
    type?: 'auto' | 'node' | 'deno' | 'bun' | 'browser';
    enableFullFS?: boolean;
    enableFullNetwork?: boolean;
    enableProcessAccess?: boolean;
  };
  
  packages?: {
    enableEnhancedManager?: boolean;
    enableLazyLoading?: boolean;
    cacheSize?: number;
    preloadPackages?: string[];
  };
  
  stdlib?: {
    enableFullStdlib?: boolean;
    preloadEssential?: boolean;
    lazyModules?: string[];
  };
  
  performance?: {
    enableJIT?: boolean;
    enableThreadPool?: boolean;
    maxWorkers?: number;
    enableMemoryPool?: boolean;
  };
  
  threading?: {
    enable?: boolean;
    maxThreads?: number;
  };
  
  multiprocessing?: {
    enable?: boolean;
    maxProcesses?: number;
  };
  
  server?: {
    enable?: boolean;
    defaultPort?: number;
    defaultHost?: string;
  };
  
  cache?: {
    enabled?: boolean;
    maxSize?: number;
    ttl?: number;
  };
}

export interface UltimatePyodideInstance {
  pyodide: any;
  runtime: any;
  packages: any;
  stdlib: any;
  performance: any;
  threading: any;
  multiprocessing: any;
  server: any;
  cache: any;
  
  runPython(code: string): any;
  runPythonAsync(code: string): Promise<any>;
  loadPackage(packages: string | string[]): Promise<any>;
  
  getRuntimeInfo(): any;
  getPerformanceMetrics(): any;
  getThreadingInfo(): any;
  getMultiprocessingInfo(): any;
  getServerInfo(): any;
  getCacheStats(): any;
  
  createServer(config?: any): Promise<any>;
  cloneServer(sourceId: string, config?: any): Promise<any>;
  
  preload(packages: string | string[]): void;
  clearCache(): void;
  cleanup(): void;
  
  benchmark(): Promise<any>;
}

class UltimatePyodideLoader {
  private options: UltimatePyodideOptions;
  private loaded: boolean = false;
  
  private runtimeAdapter: any = null;
  private packageManager: any = null;
  private stdlibManager: any = null;
  private performanceOptimizer: any = null;
  private threadManager: any = null;
  private processManager: any = null;
  private serverFactory: any = null;
  private cacheManager: any = null;
  private pyodide: any = null;

  constructor(options: UltimatePyodideOptions = {}) {
    this.options = this.normalizeOptions(options);
  }

  private normalizeOptions(options: UltimatePyodideOptions): UltimatePyodideOptions {
    return {
      indexURL: options.indexURL || 'https://cdn.jsdelivr.net/pyodide/v0.26.0/full/',
      packageCacheDir: options.packageCacheDir,
      
      runtime: {
        type: options.runtime?.type || 'auto',
        enableFullFS: options.runtime?.enableFullFS ?? true,
        enableFullNetwork: options.runtime?.enableFullNetwork ?? true,
        enableProcessAccess: options.runtime?.enableProcessAccess ?? true,
      },
      
      packages: {
        enableEnhancedManager: options.packages?.enableEnhancedManager ?? true,
        enableLazyLoading: options.packages?.enableLazyLoading ?? true,
        cacheSize: options.packages?.cacheSize || 100 * 1024 * 1024,
        preloadPackages: options.packages?.preloadPackages || [],
      },
      
      stdlib: {
        enableFullStdlib: options.stdlib?.enableFullStdlib ?? true,
        preloadEssential: options.stdlib?.preloadEssential ?? true,
        lazyModules: options.stdlib?.lazyModules || [],
      },
      
      performance: {
        enableJIT: options.performance?.enableJIT ?? true,
        enableThreadPool: options.performance?.enableThreadPool ?? true,
        maxWorkers: options.performance?.maxWorkers || 8,
        enableMemoryPool: options.performance?.enableMemoryPool ?? true,
      },
      
      threading: {
        enable: options.threading?.enable ?? true,
        maxThreads: options.threading?.maxThreads || 64,
      },
      
      multiprocessing: {
        enable: options.multiprocessing?.enable ?? true,
        maxProcesses: options.multiprocessing?.maxProcesses || 8,
      },
      
      server: {
        enable: options.server?.enable ?? true,
        defaultPort: options.server?.defaultPort || 8000,
        defaultHost: options.server?.defaultHost || 'localhost',
      },
      
      cache: {
        enabled: options.cache?.enabled ?? true,
        maxSize: options.cache?.maxSize || 100 * 1024 * 1024,
        ttl: options.cache?.ttl || 3600000,
      },
    };
  }

  async load(): Promise<UltimatePyodideInstance> {
    if (this.loaded) {
      console.warn('[UltimateLoader] Pyodide 已经加载');
      return this.createInstance();
    }

    console.log('='.repeat(80));
    console.log('Ultimate Pyodide Loader v3.0 - 完整性能优化版');
    console.log('='.repeat(80));
    console.log();

    try {
      console.log('[1/9] 加载 Pyodide 核心...');
      this.pyodide = await loadPyodide({
        indexURL: this.options.indexURL,
        packageCacheDir: this.options.packageCacheDir,
      });
      console.log('✓ Pyodide 核心加载完成');
      console.log(`  Python 版本: ${this.pyodide.version}`);
      console.log();

      console.log('[2/9] 初始化运行时适配器...');
      await this.initializeRuntime();
      console.log('✓ 运行时适配器初始化完成');
      console.log();

      console.log('[3/9] 初始化包管理器...');
      await this.initializePackages();
      console.log('✓ 包管理器初始化完成');
      console.log();

      console.log('[4/9] 初始化标准库...');
      await this.initializeStdlib();
      console.log('✓ 标准库初始化完成');
      console.log();

      console.log('[5/9] 初始化性能优化器...');
      await this.initializePerformance();
      console.log('✓ 性能优化器初始化完成');
      console.log();

      console.log('[6/9] 初始化多线程支持...');
      await this.initializeThreading();
      console.log('✓ 多线程支持初始化完成');
      console.log();

      console.log('[7/9] 初始化多进程支持...');
      await this.initializeMultiprocessing();
      console.log('✓ 多进程支持初始化完成');
      console.log();

      console.log('[8/9] 初始化服务器工厂...');
      await this.initializeServer();
      console.log('✓ 服务器工厂初始化完成');
      console.log();

      console.log('[9/9] 初始化缓存系统...');
      await this.initializeCache();
      console.log('✓ 缓存系统初始化完成');
      console.log();

      console.log('='.repeat(80));
      console.log('✓ Ultimate Pyodide 加载完成！');
      console.log('='.repeat(80));
      console.log();
      
      this.printFeatureSummary();
      
      this.loaded = true;
      return this.createInstance();

    } catch (error) {
      console.error('[UltimateLoader] 加载失败:', error);
      throw error;
    }
  }

  private async initializeRuntime(): Promise<void> {
    const { getRuntimeAdapter } = await import('./runtime/universal-adapter');
    this.runtimeAdapter = getRuntimeAdapter();
    
    if (typeof API !== 'undefined') {
      API._runtimeAdapter = this.runtimeAdapter;
    }
  }

  private async initializePackages(): Promise<void> {
    if (!this.options.packages?.enableEnhancedManager) {
      console.log('  (增强包管理器已禁用)');
      return;
    }

    const { initializeEnhancedPackageManager } = await import('./package/enhanced-package-manager');
    this.packageManager = initializeEnhancedPackageManager(this.pyodide, {
      cacheDir: this.options.packageCacheDir || './.pyodide_cache',
      enableLazyLoading: this.options.packages?.enableLazyLoading,
    });
  }

  private async initializeStdlib(): Promise<void> {
    if (!this.options.stdlib?.enableFullStdlib) {
      console.log('  (完整标准库已禁用)');
      return;
    }

    const { initializeStdlibManager } = await import('./stdlib/standard-library-manager');
    this.stdlibManager = initializeStdlibManager();

    if (this.options.stdlib?.preloadEssential) {
      await this.stdlibManager.preloadEssentialModules();
    }
  }

  private async initializePerformance(): Promise<void> {
    const { initializePerformanceOptimizer } = await import('./performance/optimizer');
    this.performanceOptimizer = initializePerformanceOptimizer({
      enableJIT: this.options.performance?.enableJIT,
      enableThreadPool: this.options.performance?.enableThreadPool,
      maxWorkers: this.options.performance?.maxWorkers,
      enableMemoryPool: this.options.performance?.enableMemoryPool,
    });
  }

  private async initializeThreading(): Promise<void> {
    if (!this.options.threading?.enable) {
      console.log('  (多线程已禁用)');
      return;
    }

    const { initializeThreadManager } = await import('./threading/thread-manager');
    this.threadManager = initializeThreadManager({
      maxThreads: this.options.threading?.maxThreads,
    });
  }

  private async initializeMultiprocessing(): Promise<void> {
    if (!this.options.multiprocessing?.enable) {
      console.log('  (多进程已禁用)');
      return;
    }

    const { initializeProcessManager } = await import('./multiprocessing/process-manager');
    this.processManager = initializeProcessManager({
      maxProcesses: this.options.multiprocessing?.maxProcesses,
    });
  }

  private async initializeServer(): Promise<void> {
    if (!this.options.server?.enable) {
      console.log('  (服务器已禁用)');
      return;
    }

    const { initializeServerFactory } = await import('./server/server-factory');
    this.serverFactory = await initializeServerFactory({
      port: this.options.server?.defaultPort,
      host: this.options.server?.defaultHost,
    });
  }

  private async initializeCache(): Promise<void> {
    if (!this.options.cache?.enabled) {
      console.log('  (缓存已禁用)');
      return;
    }

    const { initializeCacheManager } = await import('./package/lazy-cache');
    this.cacheManager = initializeCacheManager({
      enabled: true,
      cacheSize: this.options.cache?.maxSize,
      ttl: this.options.cache?.ttl,
    });
  }

  private printFeatureSummary(): void {
    console.log('已启用的功能:');
    console.log('  ✓ 跨运行时支持:', this.runtimeAdapter?.type || 'unknown');
    console.log('  ✓ 增强包管理:', this.options.packages?.enableEnhancedManager);
    console.log('  ✓ 完整标准库:', this.options.stdlib?.enableFullStdlib);
    console.log('  ✓ 性能优化:', this.options.performance?.enableJIT);
    console.log('  ✓ 多线程:', this.options.threading?.enable);
    console.log('  ✓ 多进程:', this.options.multiprocessing?.enable);
    console.log('  ✓ 服务器工厂:', this.options.server?.enable);
    console.log('  ✓ 智能缓存:', this.options.cache?.enabled);
    console.log();
  }

  private createInstance(): UltimatePyodideInstance {
    const instance: UltimatePyodideInstance = {
      pyodide: this.pyodide,
      runtime: this.runtimeAdapter,
      packages: this.packageManager,
      stdlib: this.stdlibManager,
      performance: this.performanceOptimizer,
      threading: this.threadManager,
      multiprocessing: this.processManager,
      server: this.serverFactory,
      cache: this.cacheManager,

      runPython: (code: string) => {
        return this.pyodide.runPython(code);
      },

      runPythonAsync: async (code: string) => {
        return await this.pyodide.runPythonAsync(code);
      },

      loadPackage: async (packages: string | string[]) => {
        if (this.packageManager) {
          return await this.packageManager.installPackage(packages);
        }
        return await this.pyodide.loadPackage(packages);
      },

      getRuntimeInfo: () => {
        if (this.runtimeAdapter) {
          return this.runtimeAdapter.getRuntimeInfo();
        }
        return {};
      },

      getPerformanceMetrics: () => {
        if (this.performanceOptimizer) {
          return this.performanceOptimizer.getMetrics();
        }
        return {};
      },

      getThreadingInfo: () => {
        if (this.threadManager) {
          return {
            activeThreads: this.threadManager.getActiveCount(),
            maxThreads: this.options.threading?.maxThreads,
          };
        }
        return {};
      },

      getMultiprocessingInfo: () => {
        if (this.processManager) {
          return {
            activeProcesses: this.processManager.getProcessCount(),
            maxProcesses: this.options.multiprocessing?.maxProcesses,
          };
        }
        return {};
      },

      getServerInfo: () => {
        if (this.serverFactory) {
          return this.serverFactory.getStats();
        }
        return {};
      },

      getCacheStats: () => {
        if (this.cacheManager) {
          return this.cacheManager.getStats();
        }
        return {};
      },

      createServer: async (config?: any) => {
        if (this.serverFactory) {
          return await this.serverFactory.createServer(config);
        }
        throw new Error('服务器工厂未初始化');
      },

      cloneServer: async (sourceId: string, config?: any) => {
        if (this.serverFactory) {
          return await this.serverFactory.cloneServer(sourceId, config);
        }
        throw new Error('服务器工厂未初始化');
      },

      preload: (packages: string | string[]) => {
        console.log('预加载包:', packages);
      },

      clearCache: () => {
        if (this.cacheManager) {
          this.cacheManager.clear();
        }
      },

      cleanup: () => {
        if (this.cacheManager) {
          this.cacheManager.cleanup();
        }
      },

      benchmark: async () => {
        const { runPerformanceBenchmarks } = await import('./performance/benchmark');
        await runPerformanceBenchmarks();
        return { status: 'completed' };
      },
    };

    return instance;
  }
}

export async function loadUltimatePyodide(
  options?: UltimatePyodideOptions
): Promise<UltimatePyodideInstance> {
  const loader = new UltimatePyodideLoader(options);
  return await loader.load();
}

export class UltimatePyodide {
  private instance: UltimatePyodideInstance | null = null;

  constructor(private options: UltimatePyodideOptions = {}) {}

  async load(): Promise<UltimatePyodideInstance> {
    if (this.instance) {
      return this.instance;
    }
    
    this.instance = await loadUltimatePyodide(this.options);
    return this.instance;
  }

  getInstance(): UltimatePyodideInstance | null {
    return this.instance;
  }
}
