/**
 * Full Network Adapter for Pyodide
 * 提供完整的网络访问能力，包括 HTTP、HTTPS、TCP、UDP、WebSocket 等
 */

import * as http from 'http';
import * as https from 'https';
import * as net from 'net';
import * as tls from 'tls';
import * as dns from 'dns';
import { URL } from 'url';

declare const Module: any;
declare const API: any;

export interface NetworkOptions {
  enableHTTP?: boolean;
  enableHTTPS?: boolean;
  enableTCP?: boolean;
  enableUDP?: boolean;
  enableDNS?: boolean;
  enableWebSocket?: boolean;
  timeout?: number;
  maxConnections?: number;
}

const defaultNetworkOptions: NetworkOptions = {
  enableHTTP: true,
  enableHTTPS: true,
  enableTCP: true,
  enableUDP: false,
  enableDNS: true,
  enableWebSocket: true,
  timeout: 30000,
  maxConnections: 100,
};

export class FullNetworkAdapter {
  private options: NetworkOptions;
  private activeConnections: Map<string, any>;
  private servers: Map<string, any>;

  constructor(options: NetworkOptions = {}) {
    this.options = { ...defaultNetworkOptions, ...options };
    this.activeConnections = new Map();
    this.servers = new Map();
  }

  initialize(): void {
    console.log('[FullNetwork] 初始化完整网络适配器...');
    
    this.injectHTTP();
    this.injectHTTPS();
    this.injectTCP();
    this.injectDNS();
    this.injectURL();
    
    console.log('[FullNetwork] 网络适配完成');
  }

  private injectHTTP(): void {
    if (!this.options.enableHTTP) return;

    const HTTPOperations = {
      request: (options: http.RequestOptions | string | URL): Promise<http.IncomingMessage> => {
        return new Promise((resolve, reject) => {
          const req = http.request(options, (res) => {
            resolve(res);
          });
          
          req.on('error', (err) => {
            reject(err);
          });
          
          req.on('timeout', () => {
            req.destroy();
            reject(new Error('Request timeout'));
          });
          
          if (!req.writableEnded) {
            setTimeout(() => {
              if (!req.writableEnded) {
                req.end();
              }
            }, 100);
          }
        });
      },
      
      get: (options: http.RequestOptions | string | URL): Promise<http.IncomingMessage> => {
        return new Promise((resolve, reject) => {
          const req = http.get(options, (res) => {
            resolve(res);
          });
          
          req.on('error', (err) => {
            reject(err);
          });
          
          req.on('timeout', () => {
            req.destroy();
            reject(new Error('Request timeout'));
          });
        });
      },
      
      createServer: (requestListener?: (req: http.IncomingMessage, res: http.ServerResponse) => void): any => {
        const server = http.createServer(requestListener);
        
        const serverWrapper = {
          listen: (port: number, hostname?: string, backlog?: number): Promise<void> => {
            return new Promise((resolve, reject) => {
              server.listen(port, hostname, backlog, () => {
                const address = server.address();
                const addr = typeof address === 'string' ? address : `${address?.address}:${address?.port}`;
                this.servers.set(addr, server);
                resolve();
              });
              
              server.on('error', reject);
            });
          },
          
          close: (): Promise<void> => {
            return new Promise((resolve) => {
              server.close(() => resolve());
            });
          },
          
          on: (event: string, callback: any) => {
            server.on(event, callback);
          },
          
          once: (event: string, callback: any) => {
            server.once(event, callback);
          },
          
          off: (event: string, callback: any) => {
            server.off(event, callback);
          },
          
          getConnections: (): Promise<number> => {
            return new Promise((resolve, reject) => {
              server.getConnections((err, count) => {
                if (err) reject(err);
                else resolve(count);
              });
            });
          },
          
          server,
        };
        
        return serverWrapper;
      },
      
      Agent: http.Agent,
      
      METHODS: http.METHODS,
      
      STATUS_CODES: http.STATUS_CODES,
    };

    API._httpOperations = HTTPOperations;
  }

  private injectHTTPS(): void {
    if (!this.options.enableHTTPS) return;

    const HTTPSOperations = {
      request: (options: https.RequestOptions | string | URL): Promise<http.IncomingMessage> => {
        return new Promise((resolve, reject) => {
          const req = https.request(options, (res) => {
            resolve(res);
          });
          
          req.on('error', (err) => {
            reject(err);
          });
          
          req.on('timeout', () => {
            req.destroy();
            reject(new Error('Request timeout'));
          });
          
          if (!req.writableEnded) {
            setTimeout(() => {
              if (!req.writableEnded) {
                req.end();
              }
            }, 100);
          }
        });
      },
      
      get: (options: https.RequestOptions | string | URL): Promise<http.IncomingMessage> => {
        return new Promise((resolve, reject) => {
          const req = https.get(options, (res) => {
            resolve(res);
          });
          
          req.on('error', (err) => {
            reject(err);
          });
          
          req.on('timeout', () => {
            req.destroy();
            reject(new Error('Request timeout'));
          });
        });
      },
      
      createServer: (options: https.ServerOptions, requestListener?: (req: http.IncomingMessage, res: http.ServerResponse) => void): any => {
        const server = https.createServer(options, requestListener);
        
        const serverWrapper = {
          listen: (port: number, hostname?: string, backlog?: number): Promise<void> => {
            return new Promise((resolve, reject) => {
              server.listen(port, hostname, backlog, () => {
                const address = server.address();
                const addr = typeof address === 'string' ? address : `${address?.address}:${address?.port}`;
                this.servers.set(addr, server);
                resolve();
              });
              
              server.on('error', reject);
            });
          },
          
          close: (): Promise<void> => {
            return new Promise((resolve) => {
              server.close(() => resolve());
            });
          },
          
          on: (event: string, callback: any) => {
            server.on(event, callback);
          },
          
          once: (event: string, callback: any) => {
            server.once(event, callback);
          },
          
          getConnections: (): Promise<number> => {
            return new Promise((resolve, reject) => {
              server.getConnections((err, count) => {
                if (err) reject(err);
                else resolve(count);
              });
            });
          },
          
          server,
        };
        
        return serverWrapper;
      },
      
      Agent: https.Agent,
    };

    API._httpsOperations = HTTPSOperations;
  }

  private injectTCP(): void {
    if (!this.options.enableTCP) return;

    const TCPOperations = {
      createServer: (connectionListener?: (socket: net.Socket) => void): any => {
        const server = net.createServer(connectionListener);
        
        const serverWrapper = {
          listen: (port: number, hostname?: string, backlog?: number): Promise<void> => {
            return new Promise((resolve, reject) => {
              server.listen(port, hostname, backlog, () => {
                const address = server.address();
                const addr = typeof address === 'string' ? address : `${address?.address}:${address?.port}`;
                this.servers.set(addr, server);
                resolve();
              });
              
              server.on('error', reject);
            });
          },
          
          close: (): Promise<void> => {
            return new Promise((resolve) => {
              server.close(() => resolve());
            });
          },
          
          on: (event: string, callback: any) => {
            server.on(event, callback);
          },
          
          getConnections: (): Promise<number> => {
            return new Promise((resolve, reject) => {
              server.getConnections((err, count) => {
                if (err) reject(err);
                else resolve(count);
              });
            });
          },
          
          address: () => server.address(),
          
          server,
        };
        
        return serverWrapper;
      },
      
      createConnection: (options: net.NetConnectOptions, connectionListener?: () => void): any => {
        const socket = net.createConnection(options, connectionListener);
        const connId = `${socket.remoteAddress}:${socket.remotePort}`;
        this.activeConnections.set(connId, socket);
        
        const socketWrapper = {
          connect: (port: number, host?: string, connectionListener?: () => void): any => {
            socket.connect(port, host, connectionListener);
            return socketWrapper;
          },
          
          on: (event: string, callback: any) => {
            socket.on(event, callback);
            return socketWrapper;
          },
          
          once: (event: string, callback: any) => {
            socket.once(event, callback);
            return socketWrapper;
          },
          
          off: (event: string, callback: any) => {
            socket.off(event, callback);
            return socketWrapper;
          },
          
          write: (data: any, encoding?: string, callback?: Function): boolean => {
            return socket.write(data, encoding, callback);
          },
          
          end: (data?: any, encoding?: string, callback?: Function): void => {
            socket.end(data, encoding, callback);
            const connId = `${socket.remoteAddress}:${socket.remotePort}`;
            this.activeConnections.delete(connId);
          },
          
          destroy: (error?: Error): void => {
            socket.destroy(error);
            const connId = `${socket.remoteAddress}:${socket.remotePort}`;
            this.activeConnections.delete(connId);
          },
          
          pause: (): void => {
            socket.pause();
          },
          
          resume: (): void => {
            socket.resume();
          },
          
          setTimeout: (timeout: number, callback?: () => void): void => {
            socket.setTimeout(timeout, callback);
          },
          
          setEncoding: (encoding?: string): void => {
            socket.setEncoding(encoding);
          },
          
          pipe: (destination: any, options?: any): any => {
            return socket.pipe(destination, options);
          },
          
          remoteAddress: socket.remoteAddress,
          remotePort: socket.remotePort,
          localAddress: socket.localAddress,
          localPort: socket.localPort,
          
          socket,
        };
        
        return socketWrapper;
      },
      
      isIP: (input: string): number => {
        return net.isIP(input);
      },
      
      isIPv4: (input: string): boolean => {
        return net.isIPv4(input);
      },
      
      isIPv6: (input: string): boolean => {
        return net.isIPv6(input);
      },
    };

    API._tcpOperations = TCPOperations;
  }

  private injectDNS(): void {
    if (!this.options.enableDNS) return;

    const DNSOperations = {
      lookup: (hostname: string, options?: dns.LookupOneOptions): Promise<dns.LookupAddress | dns.LookupAddress[]> => {
        return new Promise((resolve, reject) => {
          dns.lookup(hostname, options, (err, address, family) => {
            if (err) reject(err);
            else resolve({ address, family } as dns.LookupAddress);
          });
        });
      },
      
      resolve: (hostname: string, rrtype?: string): Promise<string[]> => {
        return new Promise((resolve, reject) => {
          dns.resolve(hostname, rrtype, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses as string[]);
          });
        });
      },
      
      resolve4: (hostname: string): Promise<string[]> => {
        return new Promise((resolve, reject) => {
          dns.resolve4(hostname, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses);
          });
        });
      },
      
      resolve6: (hostname: string): Promise<string[]> => {
        return new Promise((resolve, reject) => {
          dns.resolve6(hostname, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses);
          });
        });
      },
      
      resolveMx: (hostname: string): Promise<dns.MxRecord[]> => {
        return new Promise((resolve, reject) => {
          dns.resolveMx(hostname, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses);
          });
        });
      },
      
      resolveTxt: (hostname: string): Promise<string[][]> => {
        return new Promise((resolve, reject) => {
          dns.resolveTxt(hostname, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses);
          });
        });
      },
      
      resolveNs: (hostname: string): Promise<string[]> => {
        return new Promise((resolve, reject) => {
          dns.resolveNs(hostname, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses);
          });
        });
      },
      
      resolveCname: (hostname: string): Promise<string[]> => {
        return new Promise((resolve, reject) => {
          dns.resolveCname(hostname, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses);
          });
        });
      },
      
      reverse: (hostname: string): Promise<string[]> => {
        return new Promise((resolve, reject) => {
          dns.reverse(hostname, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses);
          });
        });
      },
      
      setServers: (servers: string[]): void => {
        dns.setServers(servers);
      },
      
      getServers: (): string[] => {
        return dns.getServers();
      },
    };

    API._dnsOperations = DNSOperations;
  }

  private injectURL(): void {
    const URLOperations = {
      parse: (urlStr: string): URL => {
        return new URL(urlStr);
      },
      
      resolve: (from: string, to: string): string => {
        const base = new URL(from);
        const target = new URL(to, base);
        return target.toString();
      },
      
      format: (url: URL | string): string => {
        if (typeof url === 'string') {
          return new URL(url).toString();
        }
        return url.toString();
      },
    };

    API._urlOperations = URLOperations;
  }

  getActiveConnections(): number {
    return this.activeConnections.size;
  }

  getActiveServers(): number {
    return this.servers.size;
  }

  closeAll(): void {
    for (const [id, conn] of this.activeConnections.entries()) {
      try {
        conn.destroy();
      } catch (err) {
        console.error(`[FullNetwork] 关闭连接 ${id} 失败:`, err);
      }
    }
    
    for (const [id, server] of this.servers.entries()) {
      try {
        server.close();
      } catch (err) {
        console.error(`[FullNetwork] 关闭服务器 ${id} 失败:`, err);
      }
    }
    
    this.activeConnections.clear();
    this.servers.clear();
  }
}

export function createNetworkAdapter(options?: NetworkOptions): FullNetworkAdapter {
  return new FullNetworkAdapter(options);
}
