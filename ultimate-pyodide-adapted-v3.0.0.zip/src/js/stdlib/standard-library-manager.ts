/**
 * Python Standard Library Integration
 * 提供完整的 Python 标准库支持
 */

declare const API: any;
declare const Module: any;

export interface StandardLibraryModule {
  name: string;
  description: string;
  aliases?: string[];
  dependencies?: string[];
  lazy?: boolean;
}

export const PYTHON_STDLIB_MODULES: StandardLibraryModule[] = [
  {
    name: 'os',
    description: '操作系统接口模块',
    aliases: ['posix', 'nt', 'os2', 'ce', 'java', 'riscos'],
  },
  {
    name: 'sys',
    description: '系统配置和函数',
  },
  {
    name: 'builtins',
    description: '内置函数和异常',
  },
  {
    name: 'io',
    description: 'I/O 操作',
    aliases: ['_io'],
  },
  {
    name: 'abc',
    description: '抽象基类',
  },
  {
    name: 'argparse',
    description: '命令行参数解析',
  },
  {
    name: 'ast',
    description: '抽象语法树',
  },
  {
    name: 'asyncio',
    description: '异步 I/O',
    lazy: true,
  },
  {
    name: 'base64',
    description: 'Base64 编码解码',
  },
  {
    name: 'binascii',
    description: '二进制和 ASCII 转换',
  },
  {
    name: 'bisect',
    description: '二分查找算法',
  },
  {
    name: 'calendar',
    description: '日历操作',
  },
  {
    name: 'codecs',
    description: '编解码器',
  },
  {
    name: 'collections',
    description: '容器数据类型',
    aliases: ['collections.abc'],
  },
  {
    name: 'concurrent',
    description: '并发执行',
    aliases: ['concurrent.futures'],
    lazy: true,
  },
  {
    name: 'contextlib',
    description: '上下文管理器工具',
  },
  {
    name: 'copy',
    description: '浅拷贝和深拷贝',
  },
  {
    name: 'cryptography',
    description: '加密和解密（需要外部库）',
  },
  {
    name: 'csv',
    description: 'CSV 文件读写',
  },
  {
    name: 'datetime',
    description: '日期和时间',
  },
  {
    name: 'decimal',
    description: '十进制浮点运算',
  },
  {
    name: 'difflib',
    description: '序列比对',
  },
  {
    name: 'dis',
    description: '字节码反汇编',
  },
  {
    name: 'doctest',
    description: '文档测试',
  },
  {
    name: 'enum',
    description: '枚举类型',
  },
  {
    name: 'functools',
    description: '函数式编程工具',
  },
  {
    name: 'gc',
    description: '垃圾回收接口',
  },
  {
    name: 'getopt',
    description: '命令行选项解析',
  },
  {
    name: 'getpass',
    description: '密码输入',
  },
  {
    name: 'gettext',
    description: '国际化',
  },
  {
    name: 'glob',
    description: '文件路径模式匹配',
  },
  {
    name: 'hashlib',
    description: '安全哈希',
  },
  {
    name: 'heapq',
    description: '堆队列算法',
  },
  {
    name: 'hmac',
    description: 'HMAC 消息认证',
  },
  {
    name: 'html',
    description: 'HTML 处理',
    aliases: ['html.parser', 'html.entities'],
  },
  {
    name: 'http',
    description: 'HTTP 协议',
    aliases: ['http.client', 'http.server'],
    lazy: true,
  },
  {
    name: 'importlib',
    description: '导入机制',
    aliases: ['importlib.abc', 'importlib.machinery', 'importlib.resources', 'importlib.util'],
  },
  {
    name: 'inspect',
    description: '检查对象',
  },
  {
    name: 'io',
    description: 'I/O 操作',
  },
  {
    name: 'itertools',
    description: '迭代器工具',
  },
  {
    name: 'json',
    description: 'JSON 编码解码',
  },
  {
    name: 'keyword',
    description: 'Python 关键字检查',
  },
  {
    name: 'linecache',
    description: '文本行缓存',
  },
  {
    name: 'locale',
    description: '区域设置',
  },
  {
    name: 'logging',
    description: '日志记录',
  },
  {
    name: 'lzma',
    description: 'LZMA 压缩',
  },
  {
    name: 'math',
    description: '数学函数',
  },
  {
    name: 'mimetypes',
    description: 'MIME 类型猜测',
  },
  {
    name: 'multiprocessing',
    description: '多进程',
    lazy: true,
  },
  {
    name: 'netrc',
    description: 'netrc 文件处理',
  },
  {
    name: 'numbers',
    description: '数字抽象基类',
  },
  {
    name: 'operator',
    description: '标准操作符函数',
  },
  {
    name: 'os.path',
    description: '路径操作',
  },
  {
    name: 'pathlib',
    description: '面向对象路径',
  },
  {
    name: 'pickle',
    description: '对象序列化',
  },
  {
    name: 'pprint',
    description: '美化打印',
  },
  {
    name: 'profile',
    description: '性能分析',
    aliases: ['cProfile', 'pstats'],
  },
  {
    name: 'pty',
    description: '伪终端',
    lazy: true,
  },
  {
    name: 'pwd',
    description: '密码数据库',
  },
  {
    name: 'py_compile',
    description: 'Python 源文件编译',
  },
  {
    name: 'queue',
    description: '队列',
  },
  {
    name: 'random',
    description: '随机数生成',
  },
  {
    name: 're',
    description: '正则表达式',
  },
  {
    name: 'readline',
    description: 'GNU Readline',
    lazy: true,
  },
  {
    name: 'reprlib',
    description: '替代repr实现',
  },
  {
    name: 'resource',
    description: '资源使用',
  },
  {
    name: 'rlcompleter',
    description: '补全函数',
    lazy: true,
  },
  {
    name: 'runpy',
    description: '模块执行',
  },
  {
    name: 'secrets',
    description: '安全随机数',
  },
  {
    name: 'select',
    description: 'I/O 多路复用',
  },
  {
    name: 'selectors',
    description: '高层 I/O 多路复用',
  },
  {
    name: 'shelve',
    description: '持久化字典',
  },
  {
    name: 'shlex',
    description: 'Shell 词法分析',
  },
  {
    name: 'signal',
    description: '信号处理',
  },
  {
    name: 'site',
    description: '站点配置',
  },
  {
    name: 'socket',
    description: '底层网络接口',
    lazy: true,
  },
  {
    name: 'socketserver',
    description: '网络服务器框架',
    lazy: true,
  },
  {
    name: 'sqlite3',
    description: 'SQLite 数据库',
    lazy: true,
  },
  {
    name: 'stat',
    description: 'stat() 结果解释',
  },
  {
    name: 'statistics',
    description: '统计函数',
  },
  {
    name: 'string',
    description: '字符串工具',
  },
  {
    name: 'stringprep',
    description: '字符串准备',
  },
  {
    name: 'struct',
    description: '二进制结构体',
  },
  {
    name: 'subprocess',
    description: '子进程管理',
    lazy: true,
  },
  {
    name: 'sunau',
    description: 'AU 音频文件',
    lazy: true,
  },
  {
    name: 'symtable',
    description: '符号表访问',
  },
  {
    name: 'sysconfig',
    description: 'Python 配置',
  },
  {
    name: 'syslog',
    description: '系统日志',
    lazy: true,
  },
  {
    name: 'tarfile',
    description: 'tar 归档',
  },
  {
    name: 'tempfile',
    description: '临时文件和目录',
  },
  {
    name: 'textwrap',
    description: '文本封装',
  },
  {
    name: 'threading',
    description: '线程',
    lazy: true,
  },
  {
    name: 'time',
    description: '时间访问和转换',
  },
  {
    name: 'timeit',
    description: '小代码片段执行时间',
  },
  {
    name: 'token',
    description: 'Python 词法单元',
  },
  {
    name: 'tokenize',
    description: 'Python 词法分析器',
  },
  {
    name: 'trace',
    description: '执行追踪',
  },
  {
    name: 'traceback',
    description: '执行追踪提取',
  },
  {
    name: 'tty',
    description: '终端控制',
    lazy: true,
  },
  {
    name: 'turtle',
    description: 'Turtle 图形',
    lazy: true,
  },
  {
    name: 'types',
    description: '内置类型',
  },
  {
    name: 'typing',
    description: '类型提示',
  },
  {
    name: 'unicodedata',
    description: 'Unicode 数据库',
  },
  {
    name: 'unittest',
    description: '单元测试框架',
    aliases: ['unittest.mock'],
    lazy: true,
  },
  {
    name: 'urllib',
    description: 'URL 处理',
    aliases: ['urllib.parse', 'urllib.request', 'urllib.response', 'urllib.error', 'urllib.robotparser'],
    lazy: true,
  },
  {
    name: 'uuid',
    description: 'UUID 生成',
  },
  {
    name: 'venv',
    description: '虚拟环境',
    lazy: true,
  },
  {
    name: 'warnings',
    description: '警告控制',
  },
  {
    name: 'wave',
    description: 'WAV 音频文件',
    lazy: true,
  },
  {
    name: 'weakref',
    description: '弱引用',
  },
  {
    name: 'webbrowser',
    description: 'Web 浏览器控制',
    lazy: true,
  },
  {
    name: 'xml',
    description: 'XML 处理',
    aliases: ['xml.etree.ElementTree', 'xml.dom', 'xml.dom.minidom', 'xml.dom.pulldom', 'xml.sax', 'xml.parsers.expat'],
  },
  {
    name: 'xmlrpc',
    description: 'XML-RPC 客户端和服务器',
    aliases: ['xmlrpc.client', 'xmlrpc.server'],
    lazy: true,
  },
  {
    name: 'zipfile',
    description: 'ZIP 归档',
  },
  {
    name: 'zipimport',
    description: '从 ZIP 导入',
  },
  {
    name: 'zlib',
    description: 'zlib 压缩',
  },
  {
    name: 'gzip',
    description: 'gzip 压缩',
  },
  {
    name: 'bz2',
    description: 'bzip2 压缩',
  },
  {
    name: 'fileinput',
    description: '迭代文件行',
  },
  {
    name: 'fnmatch',
    description: 'Unix 文件名模式匹配',
  },
  {
    name: 'ipaddress',
    description: 'IPv4/IPv6 操作',
  },
  {
    name: 'platform',
    description: '平台信息',
  },
  {
    name: 'errno',
    description: '标准错误符号',
  },
  {
    name: 'ctypes',
    description: '外部函数库',
    lazy: true,
  },
  {
    name: 'array',
    description: '高效数值数组',
  },
  {
    name: 'scheduler',
    description: '事件调度',
  },
  {
    name: 'code',
    description: '交互式解释器',
  },
  {
    name: 'codeop',
    description: '编译Python代码',
  },
  {
    name: 'compileall',
    description: '字节编译库',
  },
  {
    name: 'dbm',
    description: '数据库',
    aliases: ['dbm.gnu', 'dbm.ndbm', 'dbm.dumb'],
    lazy: true,
  },
  {
    name: 'ensurepip',
    description: 'pip 安装',
    lazy: true,
  },
  {
    name: 'formatter',
    description: '通用格式化',
    lazy: true,
  },
  {
    name: 'fpectl',
    description: '浮点异常控制',
    lazy: true,
  },
  {
    name: 'grp',
    description: '组数据库',
  },
  {
    name: 'imghdr',
    description: '图像文件类型',
    lazy: true,
  },
  {
    name: 'mailcap',
    description: '邮件capability',
    lazy: true,
  },
  {
    name: 'mailbox',
    description: '邮箱格式',
    lazy: true,
  },
  {
    name: 'msilib',
    description: 'Windows安装程序',
    lazy: true,
  },
  {
    name: 'nis',
    description: 'NIS数据库',
    lazy: true,
  },
  {
    name: 'nntplib',
    description: 'NNTP协议',
    lazy: true,
  },
  {
    name: 'ntpath',
    description: 'Windows路径',
  },
  {
    name: 'nturl2path',
    description: 'URL转换为Windows路径',
    lazy: true,
  },
  {
    name: 'opcode',
    description: '操作码',
  },
  {
    name: 'optparse',
    description: '选项解析',
  },
  {
    name: 'ossaudiodev',
    description: 'OpenSound音频设备',
    lazy: true,
  },
  {
    name: 'parser',
    description: 'Python解析器',
    lazy: true,
  },
  {
    name: 'pyclbr',
    description: 'Python类浏览器',
    lazy: true,
  },
  {
    name: 'spwd',
    description: 'shadow密码数据库',
    lazy: true,
  },
  {
    name: 'telnetlib',
    description: 'Telnet客户端',
    lazy: true,
  },
  {
    name: 'uu',
    description: 'UU编码解码',
  },
  {
    name: 'xdrlib',
    description: 'XDR数据序列化',
    lazy: true,
  },
];

export class StandardLibraryManager {
  private loadedModules: Set<string>;
  private lazyModules: Set<string>;
  private moduleMetadata: Map<string, StandardLibraryModule>;

  constructor() {
    this.loadedModules = new Set();
    this.lazyModules = new Set();
    this.moduleMetadata = new Map();
    
    for (const mod of PYTHON_STDLIB_MODULES) {
      this.moduleMetadata.set(mod.name, mod);
      
      if (mod.aliases) {
        for (const alias of mod.aliases) {
          this.moduleMetadata.set(alias, mod);
        }
      }
      
      if (mod.lazy) {
        this.lazyModules.add(mod.name);
      }
    }
  }

  getAvailableModules(): StandardLibraryModule[] {
    return PYTHON_STDLIB_MODULES;
  }

  getModuleInfo(moduleName: string): StandardLibraryModule | undefined {
    return this.moduleMetadata.get(moduleName);
  }

  getLazyModules(): string[] {
    return Array.from(this.lazyModules);
  }

  isModuleAvailable(moduleName: string): boolean {
    return this.moduleMetadata.has(moduleName);
  }

  isLazyModule(moduleName: string): boolean {
    return this.lazyModules.has(moduleName);
  }

  isModuleLoaded(moduleName: string): boolean {
    return this.loadedModules.has(moduleName);
  }

  markAsLoaded(moduleName: string): void {
    this.loadedModules.add(moduleName);
  }

  markAsUnloaded(moduleName: string): void {
    this.loadedModules.delete(moduleName);
  }

  async preloadEssentialModules(): Promise<void> {
    console.log('[StdlibManager] 预加载核心标准库...');
    
    const essentialModules = [
      'os', 'sys', 'builtins', 'io', 'abc', 'argparse', 'ast', 'base64',
      'bisect', 'calendar', 'codecs', 'collections', 'contextlib',
      'copy', 'csv', 'datetime', 'decimal', 'enum', 'functools',
      'hashlib', 'heapq', 'hmac', 'inspect', 'itertools', 'json',
      'keyword', 'linecache', 'locale', 'logging', 'math', 'numbers',
      'operator', 'pathlib', 'pickle', 'pprint', 'queue', 'random',
      're', 'reprlib', 'secrets', 'selectors', 'shelve', 'shlex',
      'signal', 'stat', 'statistics', 'string', 'struct', 'tempfile',
      'textwrap', 'threading', 'time', 'traceback', 'types', 'typing',
      'unicodedata', 'warnings', 'weakref', 'zipfile', 'zipimport',
      'zlib', 'gzip', 'bz2', 'lzma', 'fileinput', 'fnmatch', 'glob',
      'os.path', 'platform', 'errno', 'array', 'code', 'codeop',
    ].filter(mod => !this.lazyModules.has(mod));

    let loaded = 0;
    for (const mod of essentialModules) {
      try {
        await this.loadModule(mod);
        loaded++;
      } catch (err) {
        console.warn(`[StdlibManager] 预加载 ${mod} 失败:`, err);
      }
    }

    console.log(`[StdlibManager] 已预加载 ${loaded}/${essentialModules.length} 个核心模块`);
  }

  async loadModule(moduleName: string): Promise<void> {
    if (this.loadedModules.has(moduleName)) {
      return;
    }

    console.log(`[StdlibManager] 加载模块: ${moduleName}`);

    try {
      if (typeof API !== 'undefined' && API.runPythonInternal) {
        API.runPythonInternal(`import ${moduleName.split('.')[0]}`);
        this.loadedModules.add(moduleName);
      }
    } catch (err) {
      console.warn(`[StdlibManager] 加载 ${moduleName} 失败:`, err);
      throw err;
    }
  }

  async loadModules(moduleNames: string[]): Promise<void> {
    console.log(`[StdlibManager] 批量加载 ${moduleNames.length} 个模块...`);
    
    for (const name of moduleNames) {
      await this.loadModule(name);
    }
    
    console.log(`[StdlibManager] 已加载 ${moduleNames.length} 个模块`);
  }

  getLoadedModules(): string[] {
    return Array.from(this.loadedModules);
  }

  getModuleCount(): { loaded: number; total: number; lazy: number } {
    return {
      loaded: this.loadedModules.size,
      total: this.moduleMetadata.size,
      lazy: this.lazyModules.size,
    };
  }

  searchModules(query: string): StandardLibraryModule[] {
    const lowerQuery = query.toLowerCase();
    return PYTHON_STDLIB_MODULES.filter(mod => 
      mod.name.toLowerCase().includes(lowerQuery) ||
      mod.description.toLowerCase().includes(lowerQuery) ||
      (mod.aliases && mod.aliases.some(a => a.toLowerCase().includes(lowerQuery)))
    );
  }

  generateStdlibReport(): string {
    const counts = this.getModuleCount();
    const loaded = this.getLoadedModules();
    const lazy = this.getLazyModules();

    let report = 'Python 标准库报告\n';
    report += '='.repeat(80) + '\n\n';
    report += `总模块数: ${counts.total}\n`;
    report += `已加载数: ${counts.loaded}\n`;
    report += `懒加载数: ${counts.lazy}\n`;
    report += `未加载数: ${counts.total - counts.loaded}\n\n`;

    report += '已加载模块:\n';
    report += '-'.repeat(80) + '\n';
    for (const mod of loaded.sort()) {
      const info = this.moduleMetadata.get(mod);
      report += `  ${mod.padEnd(30)} ${info?.description || ''}\n`;
    }

    report += '\n懒加载模块:\n';
    report += '-'.repeat(80) + '\n';
    for (const mod of lazy.sort()) {
      report += `  ${mod}\n`;
    }

    return report;
  }
}

let globalStdlibManager: StandardLibraryManager | null = null;

export function getStdlibManager(): StandardLibraryManager {
  if (!globalStdlibManager) {
    globalStdlibManager = new StandardLibraryManager();
  }
  return globalStdlibManager;
}

export function initializeStdlibManager(): StandardLibraryManager {
  const manager = getStdlibManager();
  
  if (typeof API !== 'undefined') {
    API._stdlibManager = manager;
  }
  
  return manager;
}
