/**
 * Full FileSystem Adapter for Pyodide
 * 提供完整的真实文件系统访问，替代 Emscripten 的虚拟文件系统
 */

import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

declare const Module: any;
declare const API: any;

export interface FileSystemOptions {
  rootPath?: string;
  enableSymlinks?: boolean;
  enablePermissions?: boolean;
  caseSensitive?: boolean;
  maxFileSize?: number;
}

const defaultFSOptions: FileSystemOptions = {
  enableSymlinks: true,
  enablePermissions: true,
  caseSensitive: false,
  maxFileSize: 10 * 1024 * 1024 * 1024,
};

export class FullFileSystemAdapter {
  private options: FileSystemOptions;
  private realRoot: string;
  private mountPoints: Map<string, string>;

  constructor(options: FileSystemOptions = {}) {
    this.options = { ...defaultFSOptions, ...options };
    this.realRoot = this.options.rootPath || process.cwd();
    this.mountPoints = new Map();
    
    this.mountPoints.set('/', this.realRoot);
  }

  initialize(): void {
    console.log('[FullFS] 初始化完整文件系统...');
    
    this.patchEmscriptenFS();
    this.injectFileOperations();
    
    console.log('[FullFS] 文件系统适配完成');
  }

  private patchEmscriptenFS(): void {
    const FS = Module.FS;
    const originalReadFile = FS.readFile;
    const originalWriteFile = FS.writeFile;
    const originalUnlink = FS.unlink;
    const originalReaddir = FS.readdir;
    const originalMkdir = FS.mkdir;
    const originalRmdir = FS.rmdir;
    const originalStat = FS.stat;
    const originalLstat = FS.lstat;
    const originalRename = FS.rename;
    const originalTruncate = FS.truncate;
    const originalReadlink = FS.readlink;
    const originalChmod = FS.chmod;
    const originalAccess = FS.access;

    FS.readFile = (filepath: string, encoding?: string, forcing?: boolean) => {
      try {
        const realPath = this.resolvePath(filepath);
        if (encoding) {
          return fs.readFileSync(realPath, encoding);
        }
        return Buffer.from(fs.readFileSync(realPath));
      } catch (err) {
        return originalReadFile.call(FS, filepath, encoding, forcing);
      }
    };

    FS.writeFile = (filepath: string, data: any, encoding?: string, canOwn?: boolean, position?: number, encodingMustBeString?: boolean) => {
      try {
        const realPath = this.resolvePath(filepath);
        
        this.ensureParentDir(path.dirname(realPath));
        
        if (Buffer.isBuffer(data)) {
          fs.writeFileSync(realPath, data);
        } else if (typeof data === 'string') {
          fs.writeFileSync(realPath, data, encoding);
        } else {
          throw new Error('Unsupported data type');
        }
        
        return;
      } catch (err) {
        return originalWriteFile.call(FS, filepath, data, encoding, canOwn, position, encodingMustBeString);
      }
    };

    FS.unlink = (filepath: string) => {
      try {
        const realPath = this.resolvePath(filepath);
        fs.unlinkSync(realPath);
        return;
      } catch (err) {
        return originalUnlink.call(FS, filepath);
      }
    };

    FS.readdir = (path: string) => {
      try {
        const realPath = this.resolvePath(path);
        return fs.readdirSync(realPath);
      } catch (err) {
        return originalReaddir.call(FS, path);
      }
    };

    FS.mkdir = (path: string, mode?: number) => {
      try {
        const realPath = this.resolvePath(path);
        const dirMode = mode !== undefined ? mode : 0o755;
        fs.mkdirSync(realPath, { recursive: true, mode: dirMode });
        return;
      } catch (err) {
        return originalMkdir.call(FS, path, mode);
      }
    };

    FS.rmdir = (path: string) => {
      try {
        const realPath = this.resolvePath(path);
        fs.rmdirSync(realPath);
        return;
      } catch (err) {
        return originalRmdir.call(FS, path);
      }
    };

    FS.stat = (path: string, dontFollow?: boolean) => {
      try {
        const realPath = this.resolvePath(path);
        const stats = fs.statSync(realPath, { bigint: false });
        return this.convertStats(stats);
      } catch (err) {
        return originalStat.call(FS, path, dontFollow);
      }
    };

    FS.lstat = (path: string) => {
      try {
        const realPath = this.resolvePath(path);
        const stats = fs.lstatSync(realPath);
        return this.convertStats(stats);
      } catch (err) {
        return originalLstat.call(FS, path);
      }
    };

    FS.rename = (oldPath: string, newPath: string) => {
      try {
        const realOldPath = this.resolvePath(oldPath);
        const realNewPath = this.resolvePath(newPath);
        
        this.ensureParentDir(path.dirname(realNewPath));
        
        fs.renameSync(realOldPath, realNewPath);
        return;
      } catch (err) {
        return originalRename.call(FS, oldPath, newPath);
      }
    };

    FS.truncate = (path: string, len?: number) => {
      try {
        const realPath = this.resolvePath(path);
        fs.truncateSync(realPath, len);
        return;
      } catch (err) {
        return originalTruncate.call(FS, path, len);
      }
    };

    FS.readlink = (path: string) => {
      try {
        const realPath = this.resolvePath(path);
        return fs.readlinkSync(realPath);
      } catch (err) {
        return originalReadlink.call(FS, path);
      }
    };

    FS.chmod = (path: string, mode: number) => {
      try {
        const realPath = this.resolvePath(path);
        fs.chmodSync(realPath, mode);
        return;
      } catch (err) {
        return originalChmod.call(FS, path, mode);
      }
    };

    FS.access = (path: string, mode?: number) => {
      try {
        const realPath = this.resolvePath(path);
        const accessMode = mode !== undefined ? mode : fs.constants.F_OK;
        fs.accessSync(realPath, accessMode);
        return;
      } catch (err) {
        return originalAccess.call(FS, path, mode);
      }
    };

    FS.symlink = (target: string, linkpath: string) => {
      try {
        const realLinkPath = this.resolvePath(linkpath);
        const realTarget = path.isAbsolute(target) ? target : path.resolve(path.dirname(realLinkPath), target);
        
        this.ensureParentDir(path.dirname(realLinkPath));
        
        fs.symlinkSync(realTarget, realLinkPath);
        return;
      } catch (err) {
        throw new FS.ErrnoError(1);
      }
    };

    FS.link = (target: string, linkpath: string) => {
      try {
        const realLinkPath = this.resolvePath(linkpath);
        const realTarget = this.resolvePath(target);
        
        this.ensureParentDir(path.dirname(realLinkPath));
        
        fs.linkSync(realTarget, realLinkPath);
        return;
      } catch (err) {
        throw new FS.ErrnoError(1);
      }
    };

    FS.copyFile = (src: string, dest: string, flags?: number) => {
      try {
        const realSrc = this.resolvePath(src);
        const realDest = this.resolvePath(dest);
        
        this.ensureParentDir(path.dirname(realDest));
        
        const copyFlags = flags !== undefined ? flags : 0;
        fs.copyFileSync(realSrc, realDest, copyFlags);
        return;
      } catch (err) {
        throw new FS.ErrnoError(1);
      }
    };

    FS.utime = (path: string, atime: number, mtime: number) => {
      try {
        const realPath = this.resolvePath(path);
        fs.utimesSync(realPath, new Date(atime * 1000), new Date(mtime * 1000));
        return;
      } catch (err) {
        throw new FS.ErrnoError(1);
      }
    };

    FS.mount = (fs: any, opts: any, mountpoint: string) => {
      const realMountpoint = this.resolvePath(mountpoint);
      this.mountPoints.set(mountpoint, realMountpoint);
      console.log(`[FullFS] 挂载 ${mountpoint} -> ${realMountpoint}`);
      return null;
    };

    FS.unmount = (mountpoint: string) => {
      this.mountPoints.delete(mountpoint);
      console.log(`[FullFS] 卸载 ${mountpoint}`);
    };

    FS.syncfs = (populate: boolean, callback: (err: any) => void) => {
      setTimeout(() => callback(null), 0);
    };

    FS.lookup = (parent: any, name: string) => {
      const fullPath = path.join(parent.path, name);
      const realPath = this.resolvePath(fullPath);
      
      try {
        const stats = fs.lstatSync(realPath);
        
        if (stats.isDirectory()) {
          return FS.createNode(parent, name, 0o755 | 0o40000, 0);
        } else if (stats.isSymbolicLink()) {
          const target = fs.readlinkSync(realPath);
          return FS.createLink(parent, name, target);
        } else {
          return FS.createNode(parent, name, 0o644 | 0o100000, stats.size);
        }
      } catch (err) {
        throw FS.ErrnoError(2);
      }
    };

    FS.createPath = (parent: any, pathStr: string, canRead?: boolean, canWrite?: boolean) => {
      const parts = pathStr.split('/').filter(p => p.length > 0);
      let current = parent;
      
      for (const part of parts) {
        const existing = FS.lookupNode(current, part);
        if (existing) {
          current = existing;
        } else {
          current = FS.createNode(current, part, 0o755 | 0o40000, 0);
        }
      }
      
      return current;
    };

    console.log('[FullFS] Emscripten FS 已修补');
  }

  private resolvePath(virtualPath: string): string {
    if (path.isAbsolute(virtualPath)) {
      for (const [mountPoint, realPath] of this.mountPoints.entries()) {
        if (virtualPath.startsWith(mountPoint)) {
          return virtualPath.replace(mountPoint, realPath);
        }
      }
      return path.join(this.realRoot, virtualPath.substring(1));
    }
    
    return path.join(this.realRoot, virtualPath);
  }

  private ensureParentDir(dirPath: string): void {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
  }

  private convertStats(stats: fs.Stats): any {
    return {
      isFile: () => stats.isFile(),
      isDirectory: () => stats.isDirectory(),
      isBlockDevice: () => stats.isBlockDevice(),
      isCharacterDevice: () => stats.isCharacterDevice(),
      isSymbolicLink: () => stats.isSymbolicLink(),
      isFIFO: () => stats.isFIFO(),
      isSocket: () => stats.isSocket(),
      dev: stats.dev,
      ino: stats.ino,
      mode: stats.mode,
      nlink: stats.nlink,
      uid: stats.uid,
      gid: stats.gid,
      rdev: stats.rdev,
      size: stats.size,
      blksize: 4096,
      blocks: Math.ceil(stats.size / 512),
      atime: stats.atime,
      mtime: stats.mtime,
      ctime: stats.ctime,
    };
  }

  private injectFileOperations(): void {
    const FileOperations = {
      copy: (src: string, dest: string) => {
        const realSrc = this.resolvePath(src);
        const realDest = this.resolvePath(dest);
        
        this.ensureParentDir(path.dirname(realDest));
        
        fs.copyFileSync(realSrc, realDest);
      },
      
      move: (src: string, dest: string) => {
        const realSrc = this.resolvePath(src);
        const realDest = this.resolvePath(dest);
        
        this.ensureParentDir(path.dirname(realDest));
        
        fs.renameSync(realSrc, realDest);
      },
      
      getHash: (filepath: string, algorithm: string = 'sha256'): string => {
        const realPath = this.resolvePath(filepath);
        const hash = crypto.createHash(algorithm);
        hash.update(fs.readFileSync(realPath));
        return hash.digest('hex');
      },
      
      watch: (filepath: string, callback: (event: string, filename: string) => void) => {
        const realPath = this.resolvePath(filepath);
        return fs.watch(realPath, (eventType, filename) => {
          callback(eventType, filename || '');
        });
      },
      
      watchFile: (filepath: string, callback: (stats: fs.Stats) => void, interval?: number) => {
        const realPath = this.resolvePath(filepath);
        return fs.watchFile(realPath, { interval: interval || 500 }, (curr, prev) => {
          callback(curr);
        });
      },
      
      unwatchFile: (filepath: string) => {
        const realPath = this.resolvePath(filepath);
        return fs.unwatchFile(realPath);
      },
    };

    API._fullFileSystem = FileOperations;
  }

  mount(realPath: string, virtualPath: string): void {
    this.mountPoints.set(virtualPath, realPath);
    console.log(`[FullFS] 新挂载点: ${virtualPath} -> ${realPath}`);
  }

  unmount(virtualPath: string): void {
    this.mountPoints.delete(virtualPath);
    console.log(`[FullFS] 卸载挂载点: ${virtualPath}`);
  }

  getMountPoints(): Map<string, string> {
    return new Map(this.mountPoints);
  }

  getRealPath(virtualPath: string): string {
    return this.resolvePath(virtualPath);
  }

  getVirtualPath(realPath: string): string {
    const normalized = path.normalize(realPath);
    
    for (const [mountPoint, mountRoot] of this.mountPoints.entries()) {
      if (normalized.startsWith(mountRoot)) {
        return normalized.replace(mountRoot, mountPoint);
      }
    }
    
    return normalized;
  }
}

export function createFileSystemAdapter(options?: FileSystemOptions): FullFileSystemAdapter {
  return new FullFileSystemAdapter(options);
}
