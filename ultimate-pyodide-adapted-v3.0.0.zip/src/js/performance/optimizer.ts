/**
 * Performance Optimization Module
 * 性能优化引擎，直接对标原生 Python
 */

declare const API: any;
declare const Module: any;

export interface PerformanceConfig {
  enableJIT?: boolean;
  enableThreadPool?: boolean;
  maxWorkers?: number;
  enableMemoryPool?: boolean;
  enableCacheOptimization?: boolean;
  enableLazyCompilation?: boolean;
}

const DEFAULT_CONFIG: PerformanceConfig = {
  enableJIT: true,
  enableThreadPool: true,
  maxWorkers: navigator.hardwareConcurrency || 4,
  enableMemoryPool: true,
  enableCacheOptimization: true,
  enableLazyCompilation: true,
};

export class PerformanceOptimizer {
  private config: PerformanceConfig;
  private threadPool: WorkerThreadPool | null = null;
  private memoryPool: MemoryPool | null = null;
  private compiledCache: Map<string, any>;
  private metrics: PerformanceMetrics;
  private startTime: number;

  constructor(config: PerformanceConfig = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.compiledCache = new Map();
    this.metrics = {
      startupTime: 0,
      compilationTime: 0,
      executionTime: 0,
      memoryUsage: 0,
      threadPoolHits: 0,
      cacheHits: 0,
      cacheMisses: 0,
    };
    this.startTime = Date.now();
  }

  initialize(): void {
    console.log('[PerformanceOptimizer] 初始化性能优化器...');
    
    this.initializeMetrics();
    
    if (this.config.enableThreadPool) {
      this.initializeThreadPool();
    }
    
    if (this.config.enableMemoryPool) {
      this.initializeMemoryPool();
    }
    
    if (this.config.enableCacheOptimization) {
      this.initializeCodeCache();
    }
    
    this.injectPythonOptimizations();
    
    this.metrics.startupTime = Date.now() - this.startTime;
    
    console.log('[PerformanceOptimizer] ✓ 性能优化器初始化完成');
    console.log(`[PerformanceOptimizer] 启动时间: ${this.metrics.startupTime}ms`);
    console.log(`[PerformanceOptimizer] 线程池大小: ${this.config.maxWorkers}`);
  }

  private initializeMetrics(): void {
    if (typeof performance !== 'undefined') {
      this.metrics.performance = {
        now: performance.now.bind(performance),
        memory: performance.memory ? {
          usedJSHeapSize: () => performance.memory.usedJSHeapSize,
          totalJSHeapSize: () => performance.memory.totalJSHeapSize,
          jsHeapSizeLimit: () => performance.memory.jsHeapSizeLimit,
        } : null,
      };
    }
  }

  private initializeThreadPool(): void {
    console.log('[PerformanceOptimizer] 初始化线程池...');
    this.threadPool = new WorkerThreadPool(this.config.maxWorkers!);
  }

  private initializeMemoryPool(): void {
    console.log('[PerformanceOptimizer] 初始化内存池...');
    this.memoryPool = new MemoryPool(100 * 1024 * 1024);
  }

  private initializeCodeCache(): void {
    console.log('[PerformanceOptimizer] 初始化代码缓存...');
    this.compiledCache = new Map();
  }

  private injectPythonOptimizations(): void {
    const pythonCode = `
import sys
from js import API

class PerformanceOptimizer:
    @staticmethod
    def get_performance_metrics():
        return API._perfOptimizer.getMetrics()
    
    @staticmethod
    def clear_cache():
        API._perfOptimizer.clearCompiledCache()
        print("编译缓存已清空")
    
    @staticmethod
    def enable_profiling():
        sys.setprofile(PerformanceOptimizer._profile_func)
        print("性能分析已启用")
    
    @staticmethod
    def disable_profiling():
        sys.setprofile(None)
        print("性能分析已禁用")
    
    @staticmethod
    def _profile_func(frame, event, arg):
        if event == 'call':
            print(f"调用: {frame.f_code.co_name}")
        return PerformanceOptimizer._profile_func

sys.modules['performance_optimizer'] = PerformanceOptimizer()
`;

    try {
      API.runPythonInternal(pythonCode);
      console.log('[PerformanceOptimizer] Python 优化注入成功');
    } catch (error) {
      console.error('[PerformanceOptimizer] Python 优化注入失败:', error);
    }
  }

  async runInThreadPool<T>(
    fn: () => T,
    timeout?: number
  ): Promise<T> {
    if (!this.threadPool) {
      throw new Error('线程池未初始化');
    }
    
    this.metrics.threadPoolHits++;
    return await this.threadPool.run(fn, timeout);
  }

  compileCode(code: string): any {
    const start = Date.now();
    
    if (this.compiledCache.has(code)) {
      this.metrics.cacheHits++;
      return this.compiledCache.get(code);
    }
    
    this.metrics.cacheMisses++;
    
    try {
      const compiled = API.runPythonInternal(`compile(${JSON.stringify(code)}, '<string>', 'exec')`);
      this.compiledCache.set(code, compiled);
      this.metrics.compilationTime += Date.now() - start;
      return compiled;
    } catch (error) {
      throw new Error(`编译失败: ${error}`);
    }
  }

  executeOptimized(code: string): any {
    const execStart = Date.now();
    
    try {
      const result = API.runPythonInternal(code);
      this.metrics.executionTime += Date.now() - execStart;
      return result;
    } catch (error) {
      throw new Error(`执行失败: ${error}`);
    }
  }

  getMetrics(): PerformanceMetrics {
    return {
      ...this.metrics,
      memoryUsage: this.getMemoryUsage(),
      uptime: Date.now() - this.startTime,
      cacheHitRate: this.metrics.cacheHits / 
        (this.metrics.cacheHits + this.metrics.cacheMisses) * 100 || 0,
    };
  }

  private getMemoryUsage(): number {
    if (typeof process !== 'undefined' && process.memoryUsage) {
      return process.memoryUsage().heapUsed;
    }
    return 0;
  }

  clearCompiledCache(): void {
    this.compiledCache.clear();
    console.log('[PerformanceOptimizer] 编译缓存已清空');
  }

  getThreadPoolStatus(): any {
    if (!this.threadPool) {
      return { initialized: false };
    }
    return this.threadPool.getStatus();
  }

  shutdown(): void {
    if (this.threadPool) {
      this.threadPool.terminate();
    }
    if (this.memoryPool) {
      this.memoryPool.clear();
    }
    this.clearCompiledCache();
    console.log('[PerformanceOptimizer] 性能优化器已关闭');
  }
}

export class WorkerThreadPool {
  private workers: Worker[] = [];
  private taskQueue: Array<{
    task: () => any;
    resolve: (value: any) => void;
    reject: (error: any) => void;
  }> = [];
  private activeWorkers: Set<Worker> = new Set();
  private workerScriptURL: string;

  constructor(private size: number) {
    const workerScript = `
      self.onmessage = function(e) {
        try {
          const result = eval('(' + e.data.fn + ')()');
          self.postMessage({ success: true, result: result });
        } catch (error) {
          self.postMessage({ success: false, error: error.message });
        }
      };
    `;
    const blob = new Blob([workerScript], { type: 'application/javascript' });
    this.workerScriptURL = URL.createObjectURL(blob);
  }

  async run<T>(task: () => T, timeout?: number): Promise<T> {
    return new Promise((resolve, reject) => {
      const timeoutId = timeout ? setTimeout(() => {
        reject(new Error(`任务超时: ${timeout}ms`));
      }, timeout) : null;

      this.taskQueue.push({
        task,
        resolve: (value) => {
          if (timeoutId) clearTimeout(timeoutId);
          resolve(value);
        },
        reject: (error) => {
          if (timeoutId) clearTimeout(timeoutId);
          reject(error);
        },
      });

      this.processQueue();
    });
  }

  private processQueue(): void {
    while (this.taskQueue.length > 0 && this.activeWorkers.size < this.size) {
      const { task, resolve, reject } = this.taskQueue.shift()!;
      
      const worker = new Worker(this.workerScriptURL);
      this.activeWorkers.add(worker);

      worker.onmessage = (e) => {
        this.activeWorkers.delete(worker);
        worker.terminate();
        
        if (e.data.success) {
          resolve(e.data.result);
        } else {
          reject(new Error(e.data.error));
        }
        
        this.processQueue();
      };

      worker.onerror = (error) => {
        this.activeWorkers.delete(worker);
        worker.terminate();
        reject(error);
        this.processQueue();
      };

      try {
        worker.postMessage({ fn: task.toString() });
      } catch (error) {
        this.activeWorkers.delete(worker);
        reject(error);
        this.processQueue();
      }
    }
  }

  getStatus(): any {
    return {
      size: this.size,
      activeWorkers: this.activeWorkers.size,
      queuedTasks: this.taskQueue.length,
    };
  }

  terminate(): void {
    for (const worker of this.workers) {
      worker.terminate();
    }
    this.workers = [];
    this.activeWorkers.clear();
    this.taskQueue = [];
  }
}

export class MemoryPool {
  private pools: Map<number, Array<ArrayBuffer>> = new Map();
  private totalSize: number;
  private usedSize: number;

  constructor(maxSize: number) {
    this.totalSize = maxSize;
    this.usedSize = 0;
  }

  allocate(size: number): ArrayBuffer {
    const poolSize = this.findNearestPowerOf2(size);
    
    if (!this.pools.has(poolSize)) {
      this.pools.set(poolSize, []);
    }
    
    const pool = this.pools.get(poolSize)!;
    
    if (pool.length > 0) {
      const buffer = pool.pop()!;
      this.usedSize += buffer.byteLength;
      return buffer;
    }
    
    if (this.usedSize + poolSize <= this.totalSize) {
      const buffer = new ArrayBuffer(poolSize);
      this.usedSize += poolSize;
      return buffer;
    }
    
    return new ArrayBuffer(size);
  }

  release(buffer: ArrayBuffer): void {
    const size = this.findNearestPowerOf2(buffer.byteLength);
    
    if (!this.pools.has(size)) {
      this.pools.set(size, []);
    }
    
    this.pools.get(size)!.push(buffer);
    this.usedSize -= buffer.byteLength;
  }

  private findNearestPowerOf2(n: number): number {
    let power = 256;
    while (power < n) {
      power *= 2;
    }
    return Math.min(power, this.totalSize);
  }

  clear(): void {
    this.pools.clear();
    this.usedSize = 0;
  }

  getStats(): any {
    return {
      totalSize: this.totalSize,
      usedSize: this.usedSize,
      usagePercent: (this.usedSize / this.totalSize) * 100,
      poolCount: this.pools.size,
    };
  }
}

export interface PerformanceMetrics {
  startupTime: number;
  compilationTime: number;
  executionTime: number;
  memoryUsage: number;
  threadPoolHits: number;
  cacheHits: number;
  cacheMisses: number;
  uptime?: number;
  cacheHitRate?: number;
  performance?: {
    now: () => number;
    memory: {
      usedJSHeapSize: () => number;
      totalJSHeapSize: () => number;
      jsHeapSizeLimit: () => number;
    } | null;
  };
}

let globalOptimizer: PerformanceOptimizer | null = null;

export function getPerformanceOptimizer(config?: PerformanceConfig): PerformanceOptimizer {
  if (!globalOptimizer) {
    globalOptimizer = new PerformanceOptimizer(config);
  }
  return globalOptimizer;
}

export function initializePerformanceOptimizer(config?: PerformanceConfig): PerformanceOptimizer {
  const optimizer = getPerformanceOptimizer(config);
  optimizer.initialize();
  
  if (typeof API !== 'undefined') {
    API._perfOptimizer = optimizer;
  }
  
  return optimizer;
}
