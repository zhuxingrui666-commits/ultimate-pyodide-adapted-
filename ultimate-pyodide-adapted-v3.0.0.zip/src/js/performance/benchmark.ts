/**
 * Performance Benchmark Suite
 * 性能基准测试，直接对标原生 Python
 */

declare const API: any;

export interface BenchmarkResult {
  name: string;
  iterations: number;
  totalTime: number;
  avgTime: number;
  minTime: number;
  maxTime: number;
  opsPerSecond: number;
  memoryUsed?: number;
}

export interface BenchmarkSuite {
  name: string;
  description: string;
  benchmarks: Benchmark[];
}

export interface Benchmark {
  name: string;
  fn: () => any;
  iterations?: number;
  warmup?: number;
}

export class PerformanceBenchmark {
  private results: Map<string, BenchmarkResult>;
  private startTime: number;

  constructor() {
    this.results = new Map();
    this.startTime = Date.now();
  }

  async runBenchmark(benchmark: Benchmark): Promise<BenchmarkResult> {
    const iterations = benchmark.iterations || 1000;
    const warmup = benchmark.warmup || 10;

    console.log(`[Benchmark] 运行基准测试: ${benchmark.name}`);
    console.log(`  预热: ${warmup} 次`);
    console.log(`  迭代: ${iterations} 次`);

    for (let i = 0; i < warmup; i++) {
      benchmark.fn();
    }

    const times: number[] = [];
    let memoryBefore = this.getMemoryUsage();

    for (let i = 0; i < iterations; i++) {
      const start = performance.now();
      benchmark.fn();
      const end = performance.now();
      times.push(end - start);
    }

    let memoryAfter = this.getMemoryUsage();

    const result: BenchmarkResult = {
      name: benchmark.name,
      iterations,
      totalTime: times.reduce((a, b) => a + b, 0),
      avgTime: times.reduce((a, b) => a + b, 0) / times.length,
      minTime: Math.min(...times),
      maxTime: Math.max(...times),
      opsPerSecond: 1000 / (times.reduce((a, b) => a + b, 0) / times.length),
      memoryUsed: memoryAfter - memoryBefore,
    };

    this.results.set(benchmark.name, result);

    console.log(`[Benchmark] ✓ ${benchmark.name}`);
    console.log(`  平均: ${result.avgTime.toFixed(4)}ms`);
    console.log(`  OPS: ${result.opsPerSecond.toFixed(2)}`);
    console.log(`  最小: ${result.minTime.toFixed(4)}ms`);
    console.log(`  最大: ${result.maxTime.toFixed(4)}ms`);
    if (result.memoryUsed) {
      console.log(`  内存: ${(result.memoryUsed / 1024).toFixed(2)}KB`);
    }
    console.log();

    return result;
  }

  async runSuite(suite: BenchmarkSuite): Promise<BenchmarkResult[]> {
    console.log('='.repeat(80));
    console.log(`基准测试套件: ${suite.name}`);
    console.log(suite.description);
    console.log('='.repeat(80));
    console.log();

    const results: BenchmarkResult[] = [];

    for (const benchmark of suite.benchmarks) {
      const result = await this.runBenchmark(benchmark);
      results.push(result);
    }

    console.log('='.repeat(80));
    console.log(`基准测试套件完成: ${suite.name}`);
    console.log('='.repeat(80));
    console.log();

    return results;
  }

  private getMemoryUsage(): number {
    if (typeof process !== 'undefined' && process.memoryUsage) {
      return process.memoryUsage().heapUsed;
    }
    return 0;
  }

  getResult(name: string): BenchmarkResult | undefined {
    return this.results.get(name);
  }

  getAllResults(): Map<string, BenchmarkResult> {
    return new Map(this.results);
  }

  generateReport(): string {
    let report = '\n';
    report += '='.repeat(80) + '\n';
    report += '性能基准测试报告\n';
    report += '='.repeat(80) + '\n';
    report += `生成时间: ${new Date().toISOString()}\n`;
    report += `总测试数: ${this.results.size}\n`;
    report += '\n';

    for (const [name, result] of this.results.entries()) {
      report += `${name}\n`;
      report += '-'.repeat(80) + '\n';
      report += `  迭代次数: ${result.iterations}\n`;
      report += `  总时间: ${result.totalTime.toFixed(2)}ms\n`;
      report += `  平均时间: ${result.avgTime.toFixed(4)}ms\n`;
      report += `  最小时间: ${result.minTime.toFixed(4)}ms\n`;
      report += `  最大时间: ${result.maxTime.toFixed(4)}ms\n`;
      report += `  OPS: ${result.opsPerSecond.toFixed(2)}\n`;
      if (result.memoryUsed) {
        report += `  内存使用: ${(result.memoryUsed / 1024).toFixed(2)}KB\n`;
      }
      report += '\n';
    }

    return report;
  }

  compareWithNative(results: any): string {
    let report = '\n';
    report += '='.repeat(80) + '\n';
    report += '与原生 Python 性能对比\n';
    report += '='.repeat(80) + '\n\n';

    for (const [name, pyodideResult] of this.results.entries()) {
      const nativeResult = results[name];
      
      if (nativeResult) {
        const speedRatio = nativeResult.avgTime / pyodideResult.avgTime;
        const percentDiff = ((pyodideResult.avgTime - nativeResult.avgTime) / nativeResult.avgTime) * 100;
        
        report += `${name}\n`;
        report += '-'.repeat(80) + '\n';
        report += `  Pyodide: ${pyodideResult.avgTime.toFixed(4)}ms\n`;
        report += `  Native:  ${nativeResult.avgTime.toFixed(4)}ms\n`;
        report += `  速度比: ${speedRatio.toFixed(2)}x ${speedRatio >= 1 ? '(更快)' : '(更慢)'}\n`;
        report += `  差异: ${percentDiff >= 0 ? '+' : ''}${percentDiff.toFixed(2)}%\n`;
        report += '\n';
      }
    }

    return report;
  }
}

export class PythonPerformanceSuite {
  private benchmark: PerformanceBenchmark;

  constructor() {
    this.benchmark = new PerformanceBenchmark();
  }

  async runAllBenchmarks(): Promise<void> {
    console.log('='.repeat(80));
    console.log('Pyodide 性能基准测试');
    console.log('='.repeat(80));
    console.log();

    await this.runBasicOperations();
    await this.runArithmeticOperations();
    await this.runDataStructures();
    await this.runFunctionCalls();
    await this.runAsyncOperations();

    console.log(this.benchmark.generateReport());
  }

  private async runBasicOperations(): Promise<void> {
    const suite: BenchmarkSuite = {
      name: '基础操作',
      description: '测试 Python 基础操作的性能',
      benchmarks: [
        {
          name: '整数加法',
          fn: () => {
            API.runPythonInternal('x = 1 + 1');
          },
          iterations: 10000,
          warmup: 100,
        },
        {
          name: '字符串拼接',
          fn: () => {
            API.runPythonInternal('s = "hello" + " " + "world"');
          },
          iterations: 5000,
          warmup: 50,
        },
        {
          name: '列表创建',
          fn: () => {
            API.runPythonInternal('lst = [1, 2, 3, 4, 5]');
          },
          iterations: 10000,
          warmup: 100,
        },
        {
          name: '字典创建',
          fn: () => {
            API.runPythonInternal('d = {"a": 1, "b": 2, "c": 3}');
          },
          iterations: 5000,
          warmup: 50,
        },
      ],
    };

    await this.benchmark.runSuite(suite);
  }

  private async runArithmeticOperations(): Promise<void> {
    const suite: BenchmarkSuite = {
      name: '算术运算',
      description: '测试数学运算的性能',
      benchmarks: [
        {
          name: '浮点加法',
          fn: () => {
            API.runPythonInternal('x = 1.5 + 2.5');
          },
          iterations: 10000,
          warmup: 100,
        },
        {
          name: '乘法运算',
          fn: () => {
            API.runPythonInternal('x = 100 * 200');
          },
          iterations: 10000,
          warmup: 100,
        },
        {
          name: '除法运算',
          fn: () => {
            API.runPythonInternal('x = 1000 / 7');
          },
          iterations: 5000,
          warmup: 50,
        },
        {
          name: '幂运算',
          fn: () => {
            API.runPythonInternal('x = 2 ** 10');
          },
          iterations: 5000,
          warmup: 50,
        },
      ],
    };

    await this.benchmark.runSuite(suite);
  }

  private async runDataStructures(): Promise<void> {
    const suite: BenchmarkSuite = {
      name: '数据结构',
      description: '测试数据结构的性能',
      benchmarks: [
        {
          name: '列表追加',
          fn: () => {
            API.runPythonInternal('lst = []\nfor i in range(100):\n    lst.append(i)');
          },
          iterations: 1000,
          warmup: 10,
        },
        {
          name: '列表索引',
          fn: () => {
            API.runPythonInternal('lst = list(range(1000)); x = lst[500]');
          },
          iterations: 10000,
          warmup: 100,
        },
        {
          name: '字典查找',
          fn: () => {
            API.runPythonInternal('d = {i: i*2 for i in range(1000)}; x = d.get(500)');
          },
          iterations: 10000,
          warmup: 100,
        },
        {
          name: '集合操作',
          fn: () => {
            API.runPythonInternal('s = set(range(1000)); 500 in s');
          },
          iterations: 5000,
          warmup: 50,
        },
      ],
    };

    await this.benchmark.runSuite(suite);
  }

  private async runFunctionCalls(): Promise<void> {
    const suite: BenchmarkSuite = {
      name: '函数调用',
      description: '测试函数调用的性能',
      benchmarks: [
        {
          name: '内置函数 len',
          fn: () => {
            API.runPythonInternal('x = len([1,2,3,4,5])');
          },
          iterations: 10000,
          warmup: 100,
        },
        {
          name: '内置函数 sum',
          fn: () => {
            API.runPythonInternal('x = sum(range(100))');
          },
          iterations: 5000,
          warmup: 50,
        },
        {
          name: '自定义函数',
          fn: () => {
            API.runPythonInternal(`
def foo(x):
    return x * 2
foo(42)
            `);
          },
          iterations: 5000,
          warmup: 50,
        },
      ],
    };

    await this.benchmark.runSuite(suite);
  }

  private async runAsyncOperations(): Promise<void> {
    const suite: BenchmarkSuite = {
      name: '异步操作',
      description: '测试异步操作的性能',
      benchmarks: [
        {
          name: 'AsyncIO 事件循环',
          fn: async () => {
            await API.runPythonAsync(`
import asyncio
async def test():
    await asyncio.sleep(0)
asyncio.run(test())
            `);
          },
          iterations: 1000,
          warmup: 10,
        },
      ],
    };

    await this.benchmark.runSuite(suite);
  }
}

export async function runPerformanceBenchmarks(): Promise<void> {
  const suite = new PythonPerformanceSuite();
  await suite.runAllBenchmarks();
}

export function createBenchmark(name: string, fn: () => any, iterations?: number): Benchmark {
  return { name, fn, iterations };
}

export function createSuite(name: string, description: string, benchmarks: Benchmark[]): BenchmarkSuite {
  return { name, description, benchmarks };
}
