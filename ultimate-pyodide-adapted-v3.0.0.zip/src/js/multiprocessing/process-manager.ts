/**
 * Multi-processing Support Module
 * 完整的多进程支持，对标原生 Python multiprocessing
 */

declare const API: any;
declare const Module: any;

export interface ProcessConfig {
  maxProcesses?: number;
  method?: 'spawn' | 'fork' | 'forkserver';
  enableSharedMemory?: boolean;
}

const DEFAULT_PROCESS_CONFIG: ProcessConfig = {
  maxProcesses: require('os').cpus().length,
  method: 'spawn',
  enableSharedMemory: true,
};

export class ProcessManager {
  private processes: Map<number, ProcessInfo>;
  private processIdCounter: number;
  private config: ProcessConfig;
  private sharedData: Map<string, any>;

  constructor(config: ProcessConfig = {}) {
    this.config = { ...DEFAULT_PROCESS_CONFIG, ...config };
    this.processes = new Map();
    this.processIdCounter = 0;
    this.sharedData = new Map();
  }

  initialize(): void {
    console.log('[ProcessManager] 初始化进程管理器...');
    
    this.injectPythonMultiprocessing();
    this.injectProcessPool();
    this.injectSharedMemory();
    this.injectProcessQueue();
    
    console.log('[ProcessManager] ✓ 进程管理器初始化完成');
    console.log(`[ProcessManager] 最大进程数: ${this.config.maxProcesses}`);
    console.log(`[ProcessManager] 启动方法: ${this.config.method}`);
  }

  private injectPythonMultiprocessing(): void {
    const pythonCode = `
import sys
import multiprocessing as mp
from multiprocessing import Process, Queue, Manager, Pool, Value, Array, Lock
from multiprocessing.connection import Listener, Client
from js import API

class EnhancedProcess(Process):
    def __init__(self, group=None, target=None, name=None, args=(), kwargs=None):
        super().__init__(group=group, target=target, name=name, args=args, kwargs=kwargs)
        self._pconn = None
        self._parentconn = None
        self._parent_pid = API._processManager.getCurrentPid()
        self._original_target = target
    
    def run(self):
        if self._target is not None:
            self._target(*self._args, **self._kwargs)
    
    def start(self):
        if hasattr(API, '_processManager'):
            API._processManager.startProcess(self._name)
        super().start()
    
    def join(self, timeout=None):
        super().join(timeout)
        if hasattr(API, '_processManager'):
            API._processManager.onProcessExit(self.pid)
    
    def terminate(self):
        if hasattr(API, '_processManager'):
            API._processManager.terminateProcess(self.pid)
        super().terminate()

mp.Process = EnhancedProcess

class ProcessPoolExecutor:
    def __init__(self, max_workers=None):
        import os
        self.max_workers = max_workers or os.cpu_count()
        self._pool = None
        self._tasks = []
        self._results = []
    
    def submit(self, fn, *args, **kwargs):
        from concurrent.futures import Future
        future = Future()
        
        if self._pool is None:
            self._pool = mp.Pool(processes=self.max_workers)
        
        result = self._pool.apply_async(fn, args, kwargs)
        self._tasks.append((future, result))
        return future
    
    def map(self, fn, *iterables, chunksize=1):
        if self._pool is None:
            self._pool = mp.Pool(processes=self.max_workers)
        return self._pool.map(fn, *iterables, chunksize=chunksize)
    
    def shutdown(self, wait=True):
        if self._pool:
            self._pool.close()
            if wait:
                self._pool.join()
            self._pool = None
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.shutdown(wait=True)

class EnhancedQueue:
    def __init__(self, maxsize=0):
        self._queue = []
        self._maxsize = maxsize
        self._lock = mp.Lock()
        self._not_empty = mp.Condition(self._lock)
        self._not_full = mp.Condition(self._lock)
    
    def put(self, obj, block=True, timeout=None):
        with self._not_full:
            if self._maxsize > 0:
                if timeout:
                    import time
                    endtime = time.time() + timeout
                    while len(self._queue) >= self._maxsize:
                        if time.time() >= endtime:
                            raise Exception("Queue full")
                        self._not_full.wait(timeout - (time.time() - endtime))
                else:
                    while len(self._queue) >= self._maxsize:
                        self._not_full.wait()
            self._queue.append(obj)
            self._not_empty.notify()
    
    def get(self, block=True, timeout=None):
        with self._not_empty:
            if not block:
                if len(self._queue) == 0:
                    raise Exception("Queue empty")
            elif timeout:
                import time
                endtime = time.time() + timeout
                while len(self._queue) == 0:
                    if time.time() >= endtime:
                        raise Exception("Queue empty")
                    self._not_empty.wait(timeout - (time.time() - endtime))
            else:
                while len(self._queue) == 0:
                    self._not_empty.wait()
            
            item = self._queue.pop(0)
            self._not_full.notify()
            return item
    
    def qsize(self):
        return len(self._queue)
    
    def empty(self):
        return len(self._queue) == 0
    
    def full(self):
        return self._maxsize > 0 and len(self._queue) >= self._maxsize

mp.Queue = EnhancedQueue
mp.JoinableQueue = EnhancedQueue
mp.SimpleQueue = EnhancedQueue

class EnhancedManager:
    def __init__(self):
        self._dict = {}
        self._lock = mp.Lock()
    
    def dict(self):
        return self._dict
    
    def list(self):
        return []
    
    def Value(self, typecode, value):
        return value
    
    def Array(self, typecode, size):
        return [0] * size
    
    def Lock(self):
        return mp.Lock()
    
    def Namespace(self, **kwargs):
        class NS:
            pass
        ns = NS()
        for k, v in kwargs.items():
            setattr(ns, k, v)
        return ns

mp.Manager = EnhancedManager

def cpu_count():
    import os
    return os.cpu_count() or 1

mp.cpu_count = cpu_count

sys.modules['multiprocessing'].Process = EnhancedProcess
sys.modules['multiprocessing'].Queue = EnhancedQueue
sys.modules['multiprocessing'].Manager = EnhancedManager

print("✓ 多进程支持已启用")
print(f"  - CPU 核心数: {cpu_count()}")
print(f"  - 最大进程数: {API._processManager.config['maxProcesses']}")
`;

    try {
      API.runPythonInternal(pythonCode);
      console.log('[ProcessManager] Python 多进程注入成功');
    } catch (error) {
      console.error('[ProcessManager] Python 多进程注入失败:', error);
    }
  }

  private injectProcessPool(): void {
    console.log('[ProcessManager] 初始化进程池...');
  }

  private injectSharedMemory(): void {
    if (!this.config.enableSharedMemory) {
      return;
    }

    const pythonCode = `
try:
    from multiprocessing import shared_memory
    
    class EnhancedSharedMemory:
        @staticmethod
        def create(name, size):
            if hasattr(API, '_processManager'):
                return API._processManager.createSharedMemory(name, size)
            return None
        
        @staticmethod
        def attach(name):
            if hasattr(API, '_processManager'):
                return API._processManager.attachSharedMemory(name)
            return None
    
    sys.modules['multiprocessing.shared_memory'] = type('shared_memory', (), {
        'SharedMemory': EnhancedSharedMemory,
    })()
    
    print("✓ 共享内存支持已启用")
except ImportError:
    print("! 共享内存模块不可用")
`;

    try {
      API.runPythonInternal(pythonCode);
    } catch (error) {
      console.error('[ProcessManager] 共享内存注入失败:', error);
    }
  }

  private injectProcessQueue(): void {
    console.log('[ProcessManager] 初始化进程队列...');
  }

  startProcess(name: string): number {
    const id = ++this.processIdCounter;
    
    this.processes.set(id, {
      id,
      name,
      pid: id,
      running: true,
      started: Date.now(),
    });
    
    console.log(`[ProcessManager] 启动进程 ${name} (PID: ${id})`);
    return id;
  }

  onProcessExit(pid: number): void {
    for (const [id, process] of this.processes.entries()) {
      if (process.pid === pid) {
        process.running = false;
        process.finished = Date.now();
        console.log(`[ProcessManager] 进程 ${process.name} (PID: ${pid}) 已退出`);
        break;
      }
    }
  }

  terminateProcess(pid: number): void {
    for (const [id, process] of this.processes.entries()) {
      if (process.pid === pid) {
        process.running = false;
        console.log(`[ProcessManager] 终止进程 ${process.name} (PID: ${pid})`);
        break;
      }
    }
  }

  getCurrentPid(): number {
    return process.pid;
  }

  getCurrentProcessInfo(): ProcessInfo | undefined {
    return {
      id: process.pid,
      name: 'main',
      pid: process.pid,
      running: true,
      started: Date.now(),
    };
  }

  createSharedMemory(name: string, size: number): ArrayBuffer {
    const buffer = new ArrayBuffer(size);
    this.sharedData.set(name, buffer);
    console.log(`[ProcessManager] 创建共享内存 ${name} (${size} bytes)`);
    return buffer;
  }

  attachSharedMemory(name: string): ArrayBuffer | null {
    const buffer = this.sharedData.get(name);
    if (buffer) {
      console.log(`[ProcessManager] 附加共享内存 ${name}`);
      return buffer;
    }
    console.warn(`[ProcessManager] 共享内存 ${name} 不存在`);
    return null;
  }

  getProcessCount(): number {
    return this.processes.size;
  }

  getActiveProcesses(): ProcessInfo[] {
    return Array.from(this.processes.values()).filter(p => p.running);
  }

  shutdown(): void {
    console.log('[ProcessManager] 关闭进程管理器...');
    
    for (const [id, process] of this.processes.entries()) {
      if (process.running) {
        process.running = false;
        console.log(`[ProcessManager] 终止进程 ${process.name} (PID: ${process.pid})`);
      }
    }
    
    this.processes.clear();
    this.sharedData.clear();
    
    console.log('[ProcessManager] 进程管理器已关闭');
  }
}

export interface ProcessInfo {
  id: number;
  name: string;
  pid: number;
  running: boolean;
  started: number;
  finished?: number;
}

export interface ProcessPool {
  apply(fn: Function, args: any[]): any;
  applyAsync(fn: Function, args: any[]): Promise<any>;
  map(fn: Function, iterable: any[]): any[];
  mapAsync(fn: Function, iterable: any[]): Promise<any[]>;
  close(): void;
  join(): void;
  terminate(): void;
}

export class Pool implements ProcessPool {
  private workers: number;
  private tasks: Array<{ fn: Function; args: any[]; resolve: Function; reject: Function }>;
  private running: number;
  private closed: boolean;

  constructor(processes?: number) {
    this.workers = processes || require('os').cpus().length;
    this.tasks = [];
    this.running = 0;
    this.closed = false;
  }

  apply(fn: Function, args: any[]): any {
    return fn(...args);
  }

  applyAsync(fn: Function, args: any[]): Promise<any> {
    return new Promise((resolve, reject) => {
      if (this.closed) {
        reject(new Error('Pool is closed'));
        return;
      }
      
      this.running++;
      
      Promise.resolve().then(() => {
        try {
          const result = fn(...args);
          resolve(result);
        } catch (error) {
          reject(error);
        } finally {
          this.running--;
          this.processNext();
        }
      });
    });
  }

  map(fn: Function, iterable: any[]): any[] {
    return iterable.map(item => fn(item));
  }

  mapAsync(fn: Function, iterable: any[]): Promise<any[]> {
    return Promise.all(iterable.map(item => this.applyAsync(fn, [item])));
  }

  private processNext(): void {
    if (this.tasks.length > 0) {
      const task = this.tasks.shift()!;
      this.applyAsync(task.fn, task.args)
        .then(task.resolve)
        .catch(task.reject);
    }
  }

  close(): void {
    this.closed = true;
  }

  join(): void {
    setTimeout(() => {
      console.log('[Pool] 所有任务完成');
    }, 100);
  }

  terminate(): void {
    this.close();
    this.tasks = [];
    console.log('[Pool] 进程池已终止');
  }
}

let globalProcessManager: ProcessManager | null = null;

export function getProcessManager(config?: ProcessConfig): ProcessManager {
  if (!globalProcessManager) {
    globalProcessManager = new ProcessManager(config);
  }
  return globalProcessManager;
}

export function initializeProcessManager(config?: ProcessConfig): ProcessManager {
  const manager = getProcessManager(config);
  manager.initialize();
  
  if (typeof API !== 'undefined') {
    API._processManager = manager;
  }
  
  return manager;
}
