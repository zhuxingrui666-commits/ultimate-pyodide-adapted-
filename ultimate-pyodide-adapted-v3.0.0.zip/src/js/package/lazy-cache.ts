/**
 * Package Cache and Lazy Loading System
 * 智能包缓存和按需加载
 */

declare const API: any;

export interface CacheEntry {
  key: string;
  data: any;
  size: number;
  timestamp: number;
  accessCount: number;
  metadata?: any;
}

export interface LazyLoadConfig {
  enabled: boolean;
  preloadThreshold: number;
  cacheSize: number;
  ttl: number;
  strategy: 'lru' | 'lfu' | 'fifo';
}

const DEFAULT_LAZY_CONFIG: LazyLoadConfig = {
  enabled: true,
  preloadThreshold: 3,
  cacheSize: 100 * 1024 * 1024,
  ttl: 3600000,
  strategy: 'lru',
};

export class PackageCacheManager {
  private cache: Map<string, CacheEntry>;
  private config: LazyLoadConfig;
  private totalSize: number;
  private accessLog: string[];
  private listeners: Map<string, Function[]>;

  constructor(config: Partial<LazyLoadConfig> = {}) {
    this.config = { ...DEFAULT_LAZY_CONFIG, ...config };
    this.cache = new Map();
    this.totalSize = 0;
    this.accessLog = [];
    this.listeners = new Map();
  }

  set(key: string, data: any, metadata?: any): void {
    if (!this.config.enabled) {
      return;
    }

    const size = this.calculateSize(data);
    
    while (this.totalSize + size > this.config.cacheSize && this.cache.size > 0) {
      this.evict();
    }

    const entry: CacheEntry = {
      key,
      data,
      size,
      timestamp: Date.now(),
      accessCount: 0,
      metadata,
    };

    if (this.cache.has(key)) {
      const oldEntry = this.cache.get(key)!;
      this.totalSize -= oldEntry.size;
    }

    this.cache.set(key, entry);
    this.totalSize += size;
    this.accessLog.push(key);

    this.emit('set', { key, size, metadata });
  }

  get(key: string): any | undefined {
    if (!this.config.enabled) {
      return undefined;
    }

    const entry = this.cache.get(key);
    
    if (!entry) {
      this.emit('miss', { key });
      return undefined;
    }

    const age = Date.now() - entry.timestamp;
    if (age > this.config.ttl) {
      this.delete(key);
      this.emit('expired', { key, age });
      return undefined;
    }

    entry.accessCount++;
    entry.timestamp = Date.now();
    
    this.emit('hit', { key, accessCount: entry.accessCount });
    
    return entry.data;
  }

  has(key: string): boolean {
    if (!this.config.enabled) {
      return false;
    }

    const entry = this.cache.get(key);
    
    if (!entry) {
      return false;
    }

    const age = Date.now() - entry.timestamp;
    if (age > this.config.ttl) {
      this.delete(key);
      return false;
    }

    return true;
  }

  delete(key: string): boolean {
    const entry = this.cache.get(key);
    
    if (entry) {
      this.totalSize -= entry.size;
      this.cache.delete(key);
      this.emit('delete', { key, size: entry.size });
      return true;
    }
    
    return false;
  }

  clear(): void {
    const size = this.totalSize;
    this.cache.clear();
    this.totalSize = 0;
    this.accessLog = [];
    this.emit('clear', { size });
  }

  private evict(): void {
    let keyToEvict: string | null = null;
    let minScore = Infinity;

    for (const [key, entry] of this.cache.entries()) {
      let score: number;

      switch (this.config.strategy) {
        case 'lru':
          score = entry.timestamp;
          break;
        case 'lfu':
          score = entry.accessCount;
          break;
        case 'fifo':
          score = this.accessLog.indexOf(key);
          break;
        default:
          score = entry.timestamp;
      }

      if (score < minScore) {
        minScore = score;
        keyToEvict = key;
      }
    }

    if (keyToEvict) {
      this.delete(keyToEvict);
    }
  }

  private calculateSize(data: any): number {
    if (data instanceof Uint8Array) {
      return data.byteLength;
    }
    
    if (typeof data === 'string') {
      return data.length * 2;
    }
    
    if (Buffer.isBuffer(data)) {
      return data.length;
    }
    
    try {
      return JSON.stringify(data).length;
    } catch {
      return 0;
    }
  }

  keys(): string[] {
    return Array.from(this.cache.keys());
  }

  size(): number {
    return this.cache.size;
  }

  getTotalSize(): number {
    return this.totalSize;
  }

  getEntry(key: string): CacheEntry | undefined {
    return this.cache.get(key);
  }

  getStats(): any {
    const entries = Array.from(this.cache.values());
    
    return {
      size: this.cache.size,
      totalSize: this.totalSize,
      maxSize: this.config.cacheSize,
      usagePercent: (this.totalSize / this.config.cacheSize) * 100,
      avgAccessCount: entries.reduce((sum, e) => sum + e.accessCount, 0) / (entries.length || 1),
      oldestEntry: entries.length > 0 ? Math.min(...entries.map(e => e.timestamp)) : null,
      newestEntry: entries.length > 0 ? Math.max(...entries.map(e => e.timestamp)) : null,
      strategy: this.config.strategy,
      ttl: this.config.ttl,
    };
  }

  on(event: string, listener: Function): void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event)!.push(listener);
  }

  off(event: string, listener: Function): void {
    const listeners = this.listeners.get(event);
    if (listeners) {
      const index = listeners.indexOf(listener);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    }
  }

  private emit(event: string, data: any): void {
    const listeners = this.listeners.get(event);
    if (listeners) {
      for (const listener of listeners) {
        try {
          listener(data);
        } catch (err) {
          console.error('[PackageCache] 事件监听器错误:', err);
        }
      }
    }
  }

  getTopAccessed(count = 10): Array<{ key: string; accessCount: number }> {
    return Array.from(this.cache.entries())
      .map(([key, entry]) => ({ key, accessCount: entry.accessCount }))
      .sort((a, b) => b.accessCount - a.accessCount)
      .slice(0, count);
  }

  getLeastAccessed(count = 10): Array<{ key: string; accessCount: number }> {
    return Array.from(this.cache.entries())
      .map(([key, entry]) => ({ key, accessCount: entry.accessCount }))
      .sort((a, b) => a.accessCount - b.accessCount)
      .slice(0, count);
  }

  cleanup(): void {
    const now = Date.now();
    const toDelete: string[] = [];

    for (const [key, entry] of this.cache.entries()) {
      const age = now - entry.timestamp;
      if (age > this.config.ttl) {
        toDelete.push(key);
      }
    }

    for (const key of toDelete) {
      this.delete(key);
    }

    if (toDelete.length > 0) {
      console.log(`[PackageCache] 清理了 ${toDelete.length} 个过期条目`);
    }
  }

  serialize(): string {
    const data: any = {};
    
    for (const [key, entry] of this.cache.entries()) {
      data[key] = {
        timestamp: entry.timestamp,
        accessCount: entry.accessCount,
        metadata: entry.metadata,
      };
    }

    return JSON.stringify(data);
  }

  static fromSerialized(serialized: string): Map<string, any> {
    const data = JSON.parse(serialized);
    const result = new Map();

    for (const [key, info] of Object.entries(data)) {
      result.set(key, info);
    }

    return result;
  }
}

export class LazyLoader {
  private packageManager: any;
  private cache: PackageCacheManager;
  private preloadedPackages: Set<string>;
  private loadingPromises: Map<string, Promise<any>>;

  constructor(packageManager: any) {
    this.packageManager = packageManager;
    this.cache = new PackageCacheManager();
    this.preloadedPackages = new Set();
    this.loadingPromises = new Map();
  }

  async lazyLoad(packages: string | string[]): Promise<void> {
    const pkgList = Array.isArray(packages) ? packages : [packages];
    
    const promises = pkgList.map(pkg => this.loadSingle(pkg));
    await Promise.all(promises);
  }

  private async loadSingle(packageName: string): Promise<void> {
    if (this.preloadedPackages.has(packageName)) {
      return;
    }

    if (this.loadingPromises.has(packageName)) {
      return this.loadingPromises.get(packageName);
    }

    const promise = (async () => {
      console.log(`[LazyLoader] 懒加载包: ${packageName}`);
      
      try {
        await this.packageManager.installPackage(packageName, { verbose: false });
        this.preloadedPackages.add(packageName);
        this.cache.set(packageName, { loaded: true, timestamp: Date.now() });
        
        console.log(`[LazyLoader] ✓ ${packageName} 加载完成`);
      } catch (err) {
        console.error(`[LazyLoader] ✗ ${packageName} 加载失败:`, err);
        throw err;
      } finally {
        this.loadingPromises.delete(packageName);
      }
    })();

    this.loadingPromises.set(packageName, promise);
    return promise;
  }

  preload(packages: string | string[]): void {
    const pkgList = Array.isArray(packages) ? packages : [packages];
    
    for (const pkg of pkgList) {
      if (!this.preloadedPackages.has(pkg)) {
        console.log(`[LazyLoader] 预加载: ${pkg}`);
        this.loadSingle(pkg).catch(err => {
          console.warn(`[LazyLoader] 预加载 ${pkg} 失败:`, err);
        });
      }
    }
  }

  isLoaded(packageName: string): boolean {
    return this.preloadedPackages.has(packageName);
  }

  getPreloadedPackages(): string[] {
    return Array.from(this.preloadedPackages);
  }

  getCacheStats(): any {
    return this.cache.getStats();
  }

  clearCache(): void {
    this.cache.clear();
  }

  getLoadingPromises(): string[] {
    return Array.from(this.loadingPromises.keys());
  }
}

let globalCacheManager: PackageCacheManager | null = null;

export function getCacheManager(config?: Partial<LazyLoadConfig>): PackageCacheManager {
  if (!globalCacheManager) {
    globalCacheManager = new PackageCacheManager(config);
  }
  return globalCacheManager;
}

export function initializeCacheManager(config?: Partial<LazyLoadConfig>): PackageCacheManager {
  const manager = getCacheManager(config);
  
  if (typeof API !== 'undefined') {
    API._cacheManager = manager;
  }
  
  return manager;
}
