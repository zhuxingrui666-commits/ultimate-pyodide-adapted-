/**
 * Enhanced Package Manager for Pyodide
 * 支持 PyPI、wheel、GitHub、本地包等
 */

declare const API: any;
declare const Module: any;

export interface PackageInfo {
  name: string;
  version: string;
  source: 'pypi' | 'github' | 'url' | 'local' | 'builtin';
  url?: string;
  dependencies?: string[];
  metadata?: any;
}

export interface PackageCache {
  packages: Map<string, PackageInfo>;
  wheels: Map<string, Uint8Array>;
  metadata: Map<string, any>;
}

export interface PackageManagerOptions {
  cacheDir?: string;
  indexURL?: string;
  packageCacheDir?: string;
  enableLazyLoading?: boolean;
  enableDependencyResolution?: boolean;
  maxCacheSize?: number;
  timeout?: number;
}

const DEFAULT_OPTIONS: PackageManagerOptions = {
  cacheDir: './.pyodide_cache',
  indexURL: 'https://pypi.org/simple',
  enableLazyLoading: true,
  enableDependencyResolution: true,
  maxCacheSize: 500 * 1024 * 1024,
  timeout: 30000,
};

export class EnhancedPackageManager {
  private options: PackageManagerOptions;
  private cache: PackageCache;
  private loadPackage: any;
  private installWheel: any;

  constructor(options: PackageManagerOptions = {}) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
    this.cache = {
      packages: new Map(),
      wheels: new Map(),
      metadata: new Map(),
    };
    this.loadPackage = null;
    this.installWheel = null;
  }

  initialize(pyodide: any): void {
    console.log('[EnhancedPackageManager] 初始化增强包管理器...');
    
    if (pyodide) {
      this.loadPackage = pyodide.loadPackage.bind(pyodide);
      this.installWheel = API.install.bind(API);
    }

    this.setupPythonAPI();
    
    console.log('[EnhancedPackageManager] 增强包管理器初始化完成');
  }

  private setupPythonAPI(): void {
    const pythonCode = `
import sys
from js import API

class EnhancedPackageManager:
    @staticmethod
    def install(packages, verbose=True):
        import json
        from pyodide.http import open_url
        
        if isinstance(packages, str):
            packages = [packages]
        
        installed = []
        failed = []
        
        for package in packages:
            if verbose:
                print(f"Installing {package}...")
            
            try:
                if package.startswith('http://') or package.startswith('https://'):
                    wheel_url = package
                elif '.whl' in package:
                    wheel_url = package
                else:
                    wheel_url = EnhancedPackageManager._get_pypi_url(package)
                
                wheel_data = EnhancedPackageManager._download_wheel(wheel_url)
                API.install(wheel_data, wheel_url.split('/')[-1], API.sitePackages)
                
                if verbose:
                    print(f"✓ {package} installed successfully")
                installed.append(package)
                
            except Exception as e:
                if verbose:
                    print(f"✗ Failed to install {package}: {e}")
                failed.append(package)
        
        return {
            'installed': installed,
            'failed': failed,
            'total': len(packages)
        }
    
    @staticmethod
    def _get_pypi_url(package_name):
        import urllib.parse
        base_url = "https://pypi.org/pypi/{package}/json"
        url = base_url.format(package=urllib.parse.quote(package_name))
        
        response = EnhancedPackageManager._fetch_json(url)
        
        latest_version = response['info']['version']
        files = response['releases'][latest_version]
        
        for file in files:
            if file['packagetype'] == 'bdist_wheel':
                return file['url']
        
        raise ValueError(f"No wheel found for {package_name}")
    
    @staticmethod
    def _fetch_json(url):
        from js import XMLHttpRequest
        
        req = XMLHttpRequest.new()
        req.open("GET", url, False)
        req.send()
        
        if req.status == 200:
            import json
            return json.loads(req.response)
        else:
            raise Exception(f"Failed to fetch {url}: {req.status}")
    
    @staticmethod
    def _download_wheel(url):
        from js import XMLHttpRequest
        
        req = XMLHttpRequest.new()
        req.responseType = "arraybuffer"
        req.open("GET", url, False)
        req.send()
        
        if req.status == 200:
            return req.response
        else:
            raise Exception(f"Failed to download {url}: {req.status}")
    
    @staticmethod
    def list_installed():
        import os
        site_packages = getattr(API, 'sitePackages', '/lib/python3.11/site-packages')
        
        installed = []
        if os.path.exists(site_packages):
            for item in os.listdir(site_packages):
                if item.endswith('.dist-info') or item.endswith('.egg-info'):
                    installed.append(item)
        
        return installed
    
    @staticmethod
    def get_cache_info():
        return {
            'cached_packages': 0,
            'cache_size': 0,
            'cache_dir': API._packageManager.options.get('cacheDir', './.pyodide_cache') if hasattr(API, '_packageManager') else None
        }

sys.modules['enhanced_package_manager'] = EnhancedPackageManager()
`;

    try {
      API.runPythonInternal(pythonCode);
      console.log('[EnhancedPackageManager] Python API 注入成功');
    } catch (error) {
      console.error('[EnhancedPackageManager] Python API 注入失败:', error);
    }
  }

  async installPackage(
    package: string | string[],
    options?: { verbose?: boolean; dependencies?: boolean }
  ): Promise<any> {
    const packages = Array.isArray(package) ? package : [package];
    const verbose = options?.verbose ?? true;
    const resolveDeps = options?.dependencies ?? true;

    console.log('[EnhancedPackageManager] 安装包:', packages);

    const results = {
      installed: [] as string[],
      failed: [] as { name: string; error: string }[],
      skipped: [] as string[],
    };

    for (const pkg of packages) {
      try {
        if (verbose) {
          console.log(`[EnhancedPackageManager] 安装 ${pkg}...`);
        }

        if (this.cache.packages.has(pkg)) {
          if (verbose) {
            console.log(`[EnhancedPackageManager] ${pkg} 已在缓存中`);
          }
          results.skipped.push(pkg);
          continue;
        }

        if (pkg.startsWith('http://') || pkg.startsWith('https://')) {
          await this.installFromURL(pkg);
          results.installed.push(pkg);
        } else if (pkg.endsWith('.whl')) {
          await this.installWheelFile(pkg);
          results.installed.push(pkg);
        } else if (pkg.includes('/')) {
          await this.installFromGitHub(pkg);
          results.installed.push(pkg);
        } else {
          const url = await this.getPyPIURL(pkg);
          await this.installFromURL(url);
          results.installed.push(pkg);
        }

        this.cache.packages.set(pkg, {
          name: pkg,
          version: 'latest',
          source: 'pypi',
        });

        if (verbose) {
          console.log(`[EnhancedPackageManager] ✓ ${pkg} 安装成功`);
        }
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        if (verbose) {
          console.error(`[EnhancedPackageManager] ✗ ${pkg} 安装失败:`, errorMsg);
        }
        results.failed.push({ name: pkg, error: errorMsg });
      }
    }

    return results;
  }

  private async installFromURL(url: string): Promise<void> {
    console.log(`[EnhancedPackageManager] 从 URL 安装: ${url}`);
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`下载失败: ${response.status} ${response.statusText}`);
    }

    const buffer = await response.arrayBuffer();
    const filename = url.split('/').pop() || 'package.whl';
    
    if (this.installWheel) {
      await this.installWheel(new Uint8Array(buffer), filename, API.sitePackages);
    }
  }

  private async installWheelFile(filename: string): Promise<void> {
    console.log(`[EnhancedPackageManager] 安装 wheel 文件: ${filename}`);
    
    let buffer: ArrayBuffer;
    
    if (filename.startsWith('http')) {
      const response = await fetch(filename);
      buffer = await response.arrayBuffer();
    } else {
      if (typeof API._runtimeAdapter !== 'undefined') {
        const fs = API._runtimeAdapter.fs;
        buffer = fs.readFile(filename);
        if (typeof buffer === 'string') {
          const encoder = new TextEncoder();
          buffer = encoder.encode(buffer).buffer;
        }
      } else {
        throw new Error('文件系统不可用');
      }
    }

    if (this.installWheel) {
      await this.installWheel(new Uint8Array(buffer), filename, API.sitePackages);
    }
  }

  private async installFromGitHub(repo: string): Promise<void> {
    const [owner, repoName, tag = 'latest'] = repo.split('/');
    console.log(`[EnhancedPackageManager] 从 GitHub 安装: ${owner}/${repoName}@${tag}`);

    const releasesUrl = `https://api.github.com/repos/${owner}/${repoName}/releases/${tag}`;
    const response = await fetch(releasesUrl);
    
    if (!response.ok) {
      throw new Error(`GitHub API 失败: ${response.status}`);
    }

    const release = await response.json();
    const wheelAsset = release.assets?.find((asset: any) => asset.name.endsWith('.whl'));
    
    if (!wheelAsset) {
      throw new Error('未找到 wheel 文件');
    }

    await this.installFromURL(wheelAsset.browser_download_url);
  }

  private async getPyPIURL(packageName: string): Promise<string> {
    console.log(`[EnhancedPackageManager] 获取 ${packageName} 的 PyPI URL`);

    const pypiUrl = `https://pypi.org/pypi/${encodeURIComponent(packageName)}/json`;
    const response = await fetch(pypiUrl);
    
    if (!response.ok) {
      throw new Error(`PyPI 查询失败: ${response.status}`);
    }

    const data = await response.json();
    const latestVersion = data.info.version;
    
    const assets = data.releases[latestVersion] || [];
    const wheelAsset = assets.find((asset: any) => 
      asset.filename.endsWith('.whl') && 
      (asset.filename.includes('py3') || asset.filename.includes('none-any') || asset.filename.includes('wasm32'))
    );

    if (!wheelAsset) {
      throw new Error(`未找到 ${packageName} ${latestVersion} 的兼容 wheel 文件`);
    }

    return wheelAsset.url;
  }

  async searchPackages(query: string, limit = 10): Promise<any[]> {
    console.log(`[EnhancedPackageManager] 搜索包: ${query}`);

    const pypiUrl = `https://pypi.org/search/?q=${encodeURIComponent(query)}`;
    const response = await fetch(pypiUrl);
    const html = await response.text();

    const results: any[] = [];
    const regex = /<a class="package-snippet"[^>]*>[\s\S]*?<h3 class="package-snippet__title"[^>]*>[\s\S]*?<span class="package-snippet__name"[^>]*>([^<]+)<\/span>[\s\S]*?<span class="package-snippet__version"[^>]*>([^<]+)<\/span>/g;
    
    let match;
    let count = 0;
    while ((match = regex.exec(html)) !== null && count < limit) {
      results.push({
        name: match[1].trim(),
        version: match[2].trim(),
        url: `https://pypi.org/project/${match[1].trim()}/`,
      });
      count++;
    }

    return results;
  }

  getInstalledPackages(): PackageInfo[] {
    return Array.from(this.cache.packages.values());
  }

  getPackageInfo(name: string): PackageInfo | undefined {
    return this.cache.packages.get(name);
  }

  async uninstallPackage(name: string): Promise<void> {
    console.log(`[EnhancedPackageManager] 卸载包: ${name}`);
    
    this.cache.packages.delete(name);
    this.cache.wheels.delete(name);
    this.cache.metadata.delete(name);
  }

  clearCache(): void {
    console.log('[EnhancedPackageManager] 清空缓存');
    this.cache.wheels.clear();
    this.cache.metadata.clear();
  }

  getCacheSize(): number {
    let totalSize = 0;
    for (const wheel of this.cache.wheels.values()) {
      totalSize += wheel.byteLength;
    }
    return totalSize;
  }

  isPackageInstalled(name: string): boolean {
    return this.cache.packages.has(name);
  }

  async loadBuiltinPackages(packages: string[]): Promise<void> {
    console.log('[EnhancedPackageManager] 加载内置包:', packages);
    
    if (this.loadPackage) {
      await this.loadPackage(packages);
    }
  }
}

let globalPackageManager: EnhancedPackageManager | null = null;

export function getEnhancedPackageManager(options?: PackageManagerOptions): EnhancedPackageManager {
  if (!globalPackageManager) {
    globalPackageManager = new EnhancedPackageManager(options);
  }
  return globalPackageManager;
}

export function initializeEnhancedPackageManager(
  pyodide: any,
  options?: PackageManagerOptions
): EnhancedPackageManager {
  const manager = getEnhancedPackageManager(options);
  manager.initialize(pyodide);
  
  if (typeof API !== 'undefined') {
    API._enhancedPackageManager = manager;
  }
  
  return manager;
}
