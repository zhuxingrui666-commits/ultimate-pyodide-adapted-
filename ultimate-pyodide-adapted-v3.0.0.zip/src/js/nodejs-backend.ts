/**
 * Pyodide Node.js Backend Adapter
 * 
 * 这个适配器为 Pyodide 提供完整的 Node.js 后端支持，包括：
 * - 真实文件系统访问
 * - 完整网络功能
 * - 进程管理
 * - 系统调用
 */

import * as fs from 'fs';
import * as path from 'path';
import * as http from 'http';
import * as https from 'https';
import * as net from 'net';
import * as tls from 'tls';
import * as child_process from 'child_process';
import * as os from 'os';
import { URL } from 'url';

declare const Module: any;
declare const API: any;

export interface BackendConfig {
  enableFullFS: boolean;
  enableFullNetwork: boolean;
  enableProcessAccess: boolean;
  workingDirectory?: string;
  environment?: NodeJS.ProcessEnv;
}

const defaultConfig: BackendConfig = {
  enableFullFS: true,
  enableFullNetwork: true,
  enableProcessAccess: true,
  workingDirectory: process.cwd(),
  environment: process.env,
};

export class NodeJSBackendAdapter {
  private config: BackendConfig;
  private originalFS: any;

  constructor(config: Partial<BackendConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
    this.originalFS = Module.FS;
  }

  async initialize(): Promise<void> {
    console.log('[NodeJS Backend] 初始化适配器...');
    
    if (this.config.enableFullFS) {
      await this.setupFullFileSystem();
    }
    
    if (this.config.enableFullNetwork) {
      await this.setupFullNetwork();
    }
    
    if (this.config.enableProcessAccess) {
      this.setupProcessAccess();
    }
    
    this.setupEnvironment();
    this.injectPythonBindings();
    
    console.log('[NodeJS Backend] 初始化完成');
  }

  private async setupFullFileSystem(): Promise<void> {
    console.log('[NodeJS Backend] 设置完整文件系统访问...');
    
    const NodeFS = {
      FS: this.originalFS,
      
      readFile: (filepath: string, encoding?: string): any => {
        try {
          if (encoding) {
            return fs.readFileSync(filepath, encoding);
          }
          return fs.readFileSync(filepath);
        } catch (err) {
          throw new Error(`读取文件失败 ${filepath}: ${err}`);
        }
      },
      
      writeFile: (filepath: string, data: any, encoding?: string): void => {
        try {
          if (encoding) {
            fs.writeFileSync(filepath, data, encoding);
          } else {
            fs.writeFileSync(filepath, data);
          }
        } catch (err) {
          throw new Error(`写入文件失败 ${filepath}: ${err}`);
        }
      },
      
      appendFile: (filepath: string, data: any, encoding?: string): void => {
        try {
          if (encoding) {
            fs.appendFileSync(filepath, data, encoding);
          } else {
            fs.appendFileSync(filepath, data);
          }
        } catch (err) {
          throw new Error(`追加文件失败 ${filepath}: ${err}`);
        }
      },
      
      exists: (filepath: string): boolean => {
        return fs.existsSync(filepath);
      },
      
      mkdir: (dirpath: string, recursive = true): void => {
        try {
          fs.mkdirSync(dirpath, { recursive });
        } catch (err) {
          throw new Error(`创建目录失败 ${dirpath}: ${err}`);
        }
      },
      
      rmdir: (dirpath: string, recursive = false): void => {
        try {
          if (recursive) {
            fs.rmSync(dirpath, { recursive: true, force: true });
          } else {
            fs.rmdirSync(dirpath);
          }
        } catch (err) {
          throw new Error(`删除目录失败 ${dirpath}: ${err}`);
        }
      },
      
      unlink: (filepath: string): void => {
        try {
          fs.unlinkSync(filepath);
        } catch (err) {
          throw new Error(`删除文件失败 ${filepath}: ${err}`);
        }
      },
      
      readdir: (dirpath: string): string[] => {
        try {
          return fs.readdirSync(dirpath);
        } catch (err) {
          throw new Error(`读取目录失败 ${dirpath}: ${err}`);
        }
      },
      
      stat: (filepath: string): any => {
        try {
          const stats = fs.statSync(filepath);
          return {
            isFile: stats.isFile(),
            isDirectory: stats.isDirectory(),
            isSymbolicLink: stats.isSymbolicLink(),
            size: stats.size,
            mtime: stats.mtime.getTime() / 1000,
            atime: stats.atime.getTime() / 1000,
            ctime: stats.ctime.getTime() / 1000,
            mode: stats.mode,
            uid: stats.uid,
            gid: stats.gid,
          };
        } catch (err) {
          throw new Error(`获取文件状态失败 ${filepath}: ${err}`);
        }
      },
      
      copyFile: (src: string, dest: string): void => {
        try {
          fs.copyFileSync(src, dest);
        } catch (err) {
          throw new Error(`复制文件失败: ${err}`);
        }
      },
      
      rename: (oldPath: string, newPath: string): void => {
        try {
          fs.renameSync(oldPath, newPath);
        } catch (err) {
          throw new Error(`重命名文件失败: ${err}`);
        }
      },
      
      chmod: (filepath: string, mode: number): void => {
        try {
          fs.chmodSync(filepath, mode);
        } catch (err) {
          throw new Error(`修改权限失败 ${filepath}: ${err}`);
        }
      },
      
      realpath: (filepath: string): string => {
        try {
          return fs.realpathSync(filepath);
        } catch (err) {
          throw new Error(`获取真实路径失败 ${filepath}: ${err}`);
        }
      },
      
      watch: (filepath: string, callback: (eventType: string, filename: string) => void): any => {
        return fs.watch(filepath, (eventType, filename) => {
          callback(eventType, filename || '');
        });
      },
    };
    
    API._nodeFS = NodeFS;
    
    Module.FS.truncate = (filepath: string, len?: number) => {
      try {
        fs.truncateSync(filepath, len);
      } catch (err) {
        throw new Error(`截断文件失败 ${filepath}: ${err}`);
      }
    };
    
    console.log('[NodeJS Backend] 文件系统访问已启用');
  }

  private async setupFullNetwork(): Promise<void> {
    console.log('[NodeJS Backend] 设置完整网络访问...');
    
    const NodeNetwork = {
      http: {
        request: (options: http.RequestOptions | string | URL): Promise<any> => {
          return new Promise((resolve, reject) => {
            const req = http.request(options, (res) => {
              resolve({
                statusCode: res.statusCode,
                statusMessage: res.statusMessage,
                headers: res.headers,
                body: res,
              });
            });
            
            req.on('error', reject);
            req.end();
          });
        },
        
        get: (options: http.RequestOptions | string | URL): Promise<any> => {
          return new Promise((resolve, reject) => {
            const req = http.get(options, (res) => {
              resolve({
                statusCode: res.statusCode,
                statusMessage: res.statusMessage,
                headers: res.headers,
                body: res,
              });
            });
            
            req.on('error', reject);
          });
        },
      },
      
      https: {
        request: (options: https.RequestOptions | string | URL): Promise<any> => {
          return new Promise((resolve, reject) => {
            const req = https.request(options, (res) => {
              resolve({
                statusCode: res.statusCode,
                statusMessage: res.statusMessage,
                headers: res.headers,
                body: res,
              });
            });
            
            req.on('error', reject);
            req.end();
          });
        },
        
        get: (options: https.RequestOptions | string | URL): Promise<any> => {
          return new Promise((resolve, reject) => {
            const req = https.get(options, (res) => {
              resolve({
                statusCode: res.statusCode,
                statusMessage: res.statusMessage,
                headers: res.headers,
                body: res,
              });
            });
            
            req.on('error', reject);
          });
        },
      },
      
      net: {
        createServer: (options?: net.NetServerOptions): any => {
          const server = net.createServer(options);
          return {
            listen: (port: number, host?: string, backlog?: number): Promise<void> => {
              return new Promise((resolve, reject) => {
                server.listen(port, host, backlog, () => resolve());
                server.on('error', reject);
              });
            },
            close: (): Promise<void> => {
              return new Promise((resolve) => {
                server.close(() => resolve());
              });
            },
            on: (event: string, callback: any) => {
              server.on(event, callback);
            },
            server,
          };
        },
        
        connect: (options: net.NetConnectOptions, connectionListener?: () => void): any => {
          const socket = net.createConnection(options, connectionListener);
          return {
            on: (event: string, callback: any) => {
              socket.on(event, callback);
            },
            write: (data: any, encoding?: string, callback?: Function) => {
              return socket.write(data, encoding, callback);
            },
            end: (data?: any, encoding?: string, callback?: Function) => {
              return socket.end(data, encoding, callback);
            },
            destroy: () => {
              socket.destroy();
            },
            socket,
          };
        },
      },
      
      tls: {
        createServer: (options: tls.ServerOptions): any => {
          const server = tls.createServer(options);
          return {
            listen: (port: number, host?: string, backlog?: number): Promise<void> => {
              return new Promise((resolve, reject) => {
                server.listen(port, host, backlog, () => resolve());
                server.on('error', reject);
              });
            },
            close: (): Promise<void> => {
              return new Promise((resolve) => {
                server.close(() => resolve());
              });
            },
            on: (event: string, callback: any) => {
              server.on(event, callback);
            },
            server,
          },
        },
        
        connect: (options: tls.ConnectionOptions, callback?: () => void): any => {
          const socket = tls.connect(options, callback);
          return {
            on: (event: string, callback: any) => {
              socket.on(event, callback);
            },
            write: (data: any, encoding?: string, callback?: Function) => {
              return socket.write(data, encoding, callback);
            },
            end: (data?: any, encoding?: string, callback?: Function) => {
              return socket.end(data, encoding, callback);
            },
            destroy: () => {
              socket.destroy();
            },
            socket,
          };
        },
      },
    };
    
    API._nodeNetwork = NodeNetwork;
    
    console.log('[NodeJS Backend] 网络访问已启用');
  }

  private setupProcessAccess(): void {
    console.log('[NodeJS Backend] 设置进程访问...');
    
    const NodeProcess = {
      exec: (command: string, options?: child_process.ExecOptions): Promise<any> => {
        return new Promise((resolve, reject) => {
          child_process.exec(command, options, (error, stdout, stderr) => {
            if (error) {
              reject({ error, stdout, stderr });
            } else {
              resolve({ stdout, stderr });
            }
          });
        });
      },
      
      execSync: (command: string, options?: child_process.ExecSyncOptions): any => {
        return child_process.execSync(command, options);
      },
      
      spawn: (command: string, args?: string[], options?: child_process.SpawnOptions): any => {
        const child = child_process.spawn(command, args, options);
        return {
          pid: child.pid,
          on: (event: string, callback: any) => {
            child.on(event, callback);
          },
          stdout: child.stdout,
          stderr: child.stderr,
          stdin: child.stdin,
          kill: (signal?: string) => {
            child.kill(signal);
          },
          child,
        };
      },
      
      spawnSync: (command: string, args?: string[], options?: child_process.SpawnSyncOptions): any => {
        return child_process.spawnSync(command, args, options);
      },
      
      fork: (modulePath: string, args?: string[], options?: child_process.ForkOptions): any => {
        const child = child_process.fork(modulePath, args, options);
        return {
          pid: child.pid,
          on: (event: string, callback: any) => {
            child.on(event, callback);
          },
          send: (message: any, callback?: Function) => {
            child.send(message, callback);
          },
          kill: (signal?: string) => {
            child.kill(signal);
          },
          child,
        };
      },
      
      exit: (code: number) => {
        process.exit(code);
      },
      
      cwd: () => {
        return process.cwd();
      },
      
      chdir: (directory: string) => {
        process.chdir(directory);
      },
      
      env: process.env,
      
      platform: process.platform,
      
      arch: process.arch,
      
      version: process.version,
      
      versions: process.versions,
      
      pid: process.pid,
      
      ppid: process.ppid,
      
      uptime: process.uptime(),
      
      memoryUsage: process.memoryUsage(),
      
      cpuUsage: process.cpuUsage(),
    };
    
    API._nodeProcess = NodeProcess;
    
    console.log('[NodeJS Backend] 进程访问已启用');
  }

  private setupEnvironment(): void {
    console.log('[NodeJS Backend] 设置环境...');
    
    if (this.config.workingDirectory) {
      try {
        process.chdir(this.config.workingDirectory);
        console.log(`[NodeJS Backend] 工作目录: ${this.config.workingDirectory}`);
      } catch (err) {
        console.error(`[NodeJS Backend] 设置工作目录失败: ${err}`);
      }
    }
    
    API._nodeEnvironment = {
      cwd: process.cwd(),
      env: process.env,
      platform: process.platform,
      arch: process.arch,
      homedir: os.homedir(),
      hostname: os.hostname(),
      tmpdir: os.tmpdir(),
      EOL: os.EOL,
    };
    
    console.log('[NodeJS Backend] 环境设置完成');
  }

  private injectPythonBindings(): void {
    console.log('[NodeJS Backend] 注入 Python 绑定...');
    
    const pythonCode = `
import sys
from js import API

class NodeJSBackend:
    @staticmethod
    def read_file(filepath, encoding=None):
        return API._nodeFS.readFile(filepath, encoding)
    
    @staticmethod
    def write_file(filepath, data, encoding=None):
        return API._nodeFS.writeFile(filepath, data, encoding)
    
    @staticmethod
    def file_exists(filepath):
        return API._nodeFS.exists(filepath)
    
    @staticmethod
    def make_dir(dirpath, recursive=True):
        return API._nodeFS.mkdir(dirpath, recursive)
    
    @staticmethod
    def remove_dir(dirpath, recursive=False):
        return API._nodeFS.rmdir(dirpath, recursive)
    
    @staticmethod
    def delete_file(filepath):
        return API._nodeFS.unlink(filepath)
    
    @staticmethod
    def list_dir(dirpath):
        return list(API._nodeFS.readdir(dirpath))
    
    @staticmethod
    def file_stat(filepath):
        return API._nodeFS.stat(filepath)
    
    @staticmethod
    def http_request(options):
        import asyncio
        return asyncio.ensure_future(API._nodeNetwork.http.request(options))
    
    @staticmethod
    def https_request(options):
        import asyncio
        return asyncio.ensure_future(API._nodeNetwork.https.request(options))
    
    @staticmethod
    def create_server(port=8080, host='0.0.0.0'):
        return API._nodeNetwork.net.createServer({'port': port, 'host': host})
    
    @staticmethod
    def exec_command(command, options=None):
        return API._nodeProcess.exec(command, options)
    
    @staticmethod
    def exec_command_sync(command, options=None):
        return API._nodeProcess.execSync(command, options)
    
    @staticmethod
    def spawn_process(command, args=None, options=None):
        return API._nodeProcess.spawn(command, args, options)
    
    @staticmethod
    def get_env():
        return API._nodeEnvironment.env
    
    @staticmethod
    def get_cwd():
        return API._nodeEnvironment.cwd
    
    @staticmethod
    def get_platform():
        return API._nodeEnvironment.platform

sys.modules['nodejs_backend'] = NodeJSBackend()
`;

    try {
      API.runPythonInternal(pythonCode);
      console.log('[NodeJS Backend] Python 绑定注入成功');
    } catch (err) {
      console.error('[NodeJS Backend] Python 绑定注入失败:', err);
    }
  }

  getConfig(): BackendConfig {
    return { ...this.config };
  }
}

export function createBackendAdapter(config?: Partial<BackendConfig>): NodeJSBackendAdapter {
  return new NodeJSBackendAdapter(config);
}
