/**
 * Process Management Adapter for Pyodide
 * 提供完整的进程管理能力，包括子进程管理、信号处理等
 */

import * as child_process from 'child_process';
import * as os from 'os';

declare const Module: any;
declare const API: any;

export interface ProcessOptions {
  enableChildProcess?: boolean;
  enableSignals?: boolean;
  enableEnvironment?: boolean;
  enableWorkingDirectory?: boolean;
  maxProcesses?: number;
}

const defaultProcessOptions: ProcessOptions = {
  enableChildProcess: true,
  enableSignals: true,
  enableEnvironment: true,
  enableWorkingDirectory: true,
  maxProcesses: 50,
};

export class ProcessAdapter {
  private options: ProcessOptions;
  private childProcesses: Map<number, child_process.ChildProcess>;
  private signalHandlers: Map<string, Function[]>;

  constructor(options: ProcessOptions = {}) {
    this.options = { ...defaultProcessOptions, ...options };
    this.childProcesses = new Map();
    this.signalHandlers = new Map();
  }

  initialize(): void {
    console.log('[ProcessAdapter] 初始化进程适配器...');
    
    if (this.options.enableChildProcess) {
      this.injectChildProcess();
    }
    
    if (this.options.enableSignals) {
      this.injectSignalHandling();
    }
    
    if (this.options.enableEnvironment) {
      this.injectEnvironment();
    }
    
    this.injectProcessInfo();
    
    console.log('[ProcessAdapter] 进程适配完成');
  }

  private injectChildProcess(): void {
    const ChildProcessOperations = {
      exec: (command: string, options?: child_process.ExecOptions): Promise<any> => {
        return new Promise((resolve, reject) => {
          const child = child_process.exec(command, options, (error, stdout, stderr) => {
            if (this.childProcesses.has(child.pid)) {
              this.childProcesses.delete(child.pid);
            }
            
            if (error) {
              reject({
                error,
                stdout,
                stderr,
                pid: child.pid,
                signal: (error as any).signal,
                code: (error as any).code,
              });
            } else {
              resolve({
                stdout,
                stderr,
                pid: child.pid,
                code: 0,
              });
            }
          });
          
          if (this.childProcesses.size < (this.options.maxProcesses || 50)) {
            this.childProcesses.set(child.pid, child);
          }
          
          child.on('error', (err) => {
            console.error(`[ProcessAdapter] 子进程 ${child.pid} 错误:`, err);
          });
          
          child.on('exit', (code, signal) => {
            console.log(`[ProcessAdapter] 子进程 ${child.pid} 退出, 代码: ${code}, 信号: ${signal}`);
            if (this.childProcesses.has(child.pid)) {
              this.childProcesses.delete(child.pid);
            }
          });
        });
      },
      
      execSync: (command: string, options?: child_process.ExecSyncOptions): Buffer | string => {
        try {
          const result = child_process.execSync(command, options);
          return result;
        } catch (error) {
          const err = error as Error & { status?: number; signal?: string; stdout?: Buffer; stderr?: Buffer };
          throw {
            error: err,
            status: err.status || 1,
            signal: err.signal,
            stdout: err.stdout ? err.stdout.toString() : '',
            stderr: err.stderr ? err.stderr.toString() : '',
          };
        }
      },
      
      execFile: (file: string, args?: string[], options?: child_process.ExecFileOptions): Promise<any> => {
        return new Promise((resolve, reject) => {
          child_process.execFile(file, args, options, (error, stdout, stderr) => {
            if (error) {
              reject({ error, stdout, stderr });
            } else {
              resolve({ stdout, stderr });
            }
          });
        });
      },
      
      execFileSync: (file: string, args?: string[], options?: child_process.ExecFileSyncOptions): Buffer | string => {
        return child_process.execFileSync(file, args, options);
      },
      
      spawn: (command: string, args?: string[], options?: child_process.SpawnOptions): any => {
        const child = child_process.spawn(command, args || [], options);
        
        if (this.childProcesses.size < (this.options.maxProcesses || 50)) {
          this.childProcesses.set(child.pid, child);
        }
        
        child.on('error', (err) => {
          console.error(`[ProcessAdapter] 进程 ${child.pid} 错误:`, err);
        });
        
        child.on('exit', (code, signal) => {
          console.log(`[ProcessAdapter] 进程 ${child.pid} 退出, 代码: ${code}, 信号: ${signal}`);
          if (this.childProcesses.has(child.pid)) {
            this.childProcesses.delete(child.pid);
          }
        });
        
        const wrapper = {
          pid: child.pid,
          
          on: (event: string, callback: any): any => {
            child.on(event, callback);
            return wrapper;
          },
          
          once: (event: string, callback: any): any => {
            child.once(event, callback);
            return wrapper;
          },
          
          off: (event: string, callback: any): any => {
            child.off(event, callback);
            return wrapper;
          },
          
          send: (message: any, callback?: Function): boolean => {
            return child.send(message, callback);
          },
          
          disconnect: (): void => {
            child.disconnect();
          },
          
          kill: (signal?: string | number): boolean => {
            return child.kill(signal);
          },
          
          terminate: (): void => {
            child.kill('SIGTERM');
          },
          
          stdout: child.stdout ? {
            on: (event: string, callback: any) => {
              child.stdout?.on(event, callback);
              return child.stdout;
            },
            once: (event: string, callback: any) => {
              child.stdout?.once(event, callback);
              return child.stdout;
            },
            removeListener: (event: string, callback: any) => {
              child.stdout?.removeListener(event, callback);
            },
            read: (): string | Buffer | null => {
              return child.stdout?.read() || null;
            },
          } : null,
          
          stderr: child.stderr ? {
            on: (event: string, callback: any) => {
              child.stderr?.on(event, callback);
              return child.stderr;
            },
            once: (event: string, callback: any) => {
              child.stderr?.once(event, callback);
              return child.stderr;
            },
            removeListener: (event: string, callback: any) => {
              child.stderr?.removeListener(event, callback);
            },
            read: (): string | Buffer | null => {
              return child.stderr?.read() || null;
            },
          } : null,
          
          stdin: child.stdin ? {
            write: (data: any, callback?: Function): boolean => {
              return child.stdin?.write(data, callback) || false;
            },
            end: (data?: any, callback?: Function): void => {
              child.stdin?.end(data, callback);
            },
            destroy: (): void => {
              child.stdin?.destroy();
            },
          } : null,
          
          child,
        };
        
        return wrapper;
      },
      
      spawnSync: (command: string, args?: string[], options?: child_process.SpawnSyncOptions): any => {
        const result = child_process.spawnSync(command, args || [], options);
        return {
          pid: result.pid,
          output: result.output,
          stdout: result.stdout ? result.stdout.toString() : '',
          stderr: result.stderr ? result.stderr.toString() : '',
          status: result.status,
          signal: result.signal,
          error: result.error,
        };
      },
      
      fork: (modulePath: string, args?: string[], options?: child_process.ForkOptions): any => {
        const child = child_process.fork(modulePath, args || [], options);
        
        if (this.childProcesses.size < (this.options.maxProcesses || 50)) {
          this.childProcesses.set(child.pid, child);
        }
        
        child.on('error', (err) => {
          console.error(`[ProcessAdapter] fork 进程 ${child.pid} 错误:`, err);
        });
        
        child.on('exit', (code, signal) => {
          console.log(`[ProcessAdapter] fork 进程 ${child.pid} 退出, 代码: ${code}, 信号: ${signal}`);
          if (this.childProcesses.has(child.pid)) {
            this.childProcesses.delete(child.pid);
          }
        });
        
        return {
          pid: child.pid,
          
          on: (event: string, callback: any): any => {
            child.on(event, callback);
            return wrapper;
          },
          
          once: (event: string, callback: any): any => {
            child.once(event, callback);
            return wrapper;
          },
          
          send: (message: any, callback?: Function): boolean => {
            return child.send(message, callback);
          },
          
          disconnect: (): void => {
            child.disconnect();
          },
          
          kill: (signal?: string | number): boolean => {
            return child.kill(signal);
          },
          
          child,
        };
      },
      
      spawnFile: async (file: string, args?: string[], options?: any): Promise<any> => {
        return new Promise((resolve, reject) => {
          const child = child_process.spawn(file, args || [], options);
          
          let stdout = '';
          let stderr = '';
          
          if (child.stdout) {
            child.stdout.on('data', (data) => {
              stdout += data.toString();
            });
          }
          
          if (child.stderr) {
            child.stderr.on('data', (data) => {
              stderr += data.toString();
            });
          }
          
          child.on('close', (code) => {
            resolve({
              pid: child.pid,
              stdout,
              stderr,
              exitCode: code,
            });
          });
          
          child.on('error', reject);
        });
      },
    };
    
    API._childProcessOperations = ChildProcessOperations;
  }

  private injectSignalHandling(): void {
    const SignalOperations = {
      on: (signal: string, handler: () => void): void => {
        if (!this.signalHandlers.has(signal)) {
          this.signalHandlers.set(signal, []);
        }
        
        this.signalHandlers.get(signal)!.push(handler);
        process.on(signal, handler);
        
        console.log(`[ProcessAdapter] 注册信号处理器: ${signal}`);
      },
      
      off: (signal: string, handler: () => void): void => {
        const handlers = this.signalHandlers.get(signal);
        if (handlers) {
          const index = handlers.indexOf(handler);
          if (index > -1) {
            handlers.splice(index, 1);
            process.off(signal, handler);
          }
        }
      },
      
      once: (signal: string): Promise<void> => {
        return new Promise((resolve) => {
          process.once(signal, () => resolve());
        });
      },
      
      raise: (signal: string | number): void => {
        process.kill(process.pid, signal);
      },
      
      signals: {
        SIGHUP: 'SIGHUP',
        SIGINT: 'SIGINT',
        SIGQUIT: 'SIGQUIT',
        SIGILL: 'SIGILL',
        SIGTRAP: 'SIGTRAP',
        SIGABRT: 'SIGABRT',
        SIGBUS: 'SIGBUS',
        SIGFPE: 'SIGFPE',
        SIGKILL: 'SIGKILL',
        SIGUSR1: 'SIGUSR1',
        SIGSEGV: 'SIGSEGV',
        SIGUSR2: 'SIGUSR2',
        SIGPIPE: 'SIGPIPE',
        SIGALRM: 'SIGALRM',
        SIGTERM: 'SIGTERM',
        SIGSTKFLT: 'SIGSTKFLT',
        SIGCHLD: 'SIGCHLD',
        SIGCONT: 'SIGCONT',
        SIGSTOP: 'SIGSTOP',
        SIGTSTP: 'SIGTSTP',
        SIGTTIN: 'SIGTTIN',
        SIGTTOU: 'SIGTTOU',
        SIGURG: 'SIGURG',
        SIGXCPU: 'SIGXCPU',
        SIGXFSZ: 'SIGXFSZ',
        SIGVTALRM: 'SIGVTALRM',
        SIGPROF: 'SIGPROF',
        SIGWINCH: 'SIGWINCH',
        SIGIO: 'SIGIO',
        SIGPWR: 'SIGPWR',
        SIGSYS: 'SIGSYS',
      },
    };
    
    API._signalOperations = SignalOperations;
  }

  private injectEnvironment(): void {
    const EnvironmentOperations = {
      getEnv: (): NodeJS.ProcessEnv => {
        return process.env;
      },
      
      setEnv: (key: string, value: string): void => {
        process.env[key] = value;
      },
      
      unsetEnv: (key: string): void => {
        delete process.env[key];
      },
      
      getcwd: (): string => {
        return process.cwd();
      },
      
      chdir: (directory: string): void => {
        process.chdir(directory);
      },
      
      homeDir: (): string => {
        return os.homedir();
      },
      
      tmpDir: (): string => {
        return os.tmpdir();
      },
      
      getPlatform: (): string => {
        return process.platform;
      },
      
      getArch: (): string => {
        return process.arch;
      },
    };
    
    API._environmentOperations = EnvironmentOperations;
  }

  private injectProcessInfo(): void {
    const ProcessInfo = {
      pid: process.pid,
      ppid: process.ppid,
      uid: process.getuid ? process.getuid() : -1,
      gid: process.getgid ? process.getgid() : -1,
      cwd: process.cwd(),
      execPath: process.execPath,
      version: process.version,
      versions: process.versions,
      platform: process.platform,
      arch: process.arch,
      env: process.env,
      argv: process.argv,
      
      memoryUsage: () => {
        const mem = process.memoryUsage();
        return {
          rss: mem.rss,
          heapTotal: mem.heapTotal,
          heapUsed: mem.heapUsed,
          external: mem.external,
          arrayBuffers: mem.arrayBuffers,
        };
      },
      
      cpuUsage: (previousValue?: { user: number; system: number }) => {
        return process.cpuUsage(previousValue);
      },
      
      resourceUsage: () => {
        if (process.resourceUsage) {
          return process.resourceUsage();
        }
        return null;
      },
      
      uptime: process.uptime(),
      
      hrtime: (bigint?: boolean) => {
        return process.hrtime(bigint);
      },
      
      hrtimeBigInt: () => {
        return process.hrtime.bigInt();
      },
      
      nextTick: (callback: (...args: any[]) => void, ...args: any[]) => {
        process.nextTick(callback, ...args);
      },
      
      release: process.release,
      
      features: {
        inspector: process.features?.inspector || false,
        experimentalModules: process.features?.experimental_modules || false,
        debug: process.features?.debug || false,
        uv: process.features?.uv || false,
        v8: process.features?.v8 || false,
        ipv6: process.features?.ipv6 || false,
        tls_alpn: process.features?.tls_alpn || false,
        tls_sni: process.features?.tls_sni || false,
        tls_ocsp: process.features?.tls_ocsp || false,
        tls: process.features?.tls || false,
      },
      
      activeProcesses: () => {
        return Array.from(this.childProcesses.keys());
      },
      
      killProcess: (pid: number, signal?: string | number): boolean => {
        const child = this.childProcesses.get(pid);
        if (child) {
          return child.kill(signal);
        }
        return false;
      },
      
      killAllProcesses: (): void => {
        for (const [pid, child] of this.childProcesses.entries()) {
          try {
            child.kill('SIGTERM');
            console.log(`[ProcessAdapter] 已终止进程 ${pid}`);
          } catch (err) {
            console.error(`[ProcessAdapter] 终止进程 ${pid} 失败:`, err);
          }
        }
        this.childProcesses.clear();
      },
    };
    
    API._processInfo = ProcessInfo;
  }

  getActiveProcesses(): number[] {
    return Array.from(this.childProcesses.keys());
  }

  getProcessCount(): number {
    return this.childProcesses.size;
  }

  killAll(): void {
    for (const [pid, child] of this.childProcesses.entries()) {
      try {
        child.kill('SIGKILL');
      } catch (err) {
        console.error(`[ProcessAdapter] 强制终止进程 ${pid} 失败:`, err);
      }
    }
    this.childProcesses.clear();
  }
}

export function createProcessAdapter(options?: ProcessOptions): ProcessAdapter {
  return new ProcessAdapter(options);
}
