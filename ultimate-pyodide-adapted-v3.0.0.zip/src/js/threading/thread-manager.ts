/**
 * Multi-threading Support Module
 * 完整的线程支持，对标原生 Python threading
 */

declare const API: any;
declare const Module: any;

export interface ThreadConfig {
  maxThreads?: number;
  defaultStackSize?: number;
  enableThreadPool?: boolean;
}

const DEFAULT_THREAD_CONFIG: ThreadConfig = {
  maxThreads: 64,
  defaultStackSize: 8 * 1024 * 1024,
  enableThreadPool: true,
};

export class ThreadManager {
  private threads: Map<number, ThreadInfo>;
  private threadIdCounter: number;
  private lock: any;
  private config: ThreadConfig;

  constructor(config: ThreadConfig = {}) {
    this.config = { ...DEFAULT_THREAD_CONFIG, ...config };
    this.threads = new Map();
    this.threadIdCounter = 0;
    this.lock = null;
  }

  initialize(): void {
    console.log('[ThreadManager] 初始化线程管理器...');
    
    this.injectPythonThreading();
    this.initializeGILSimulation();
    this.injectThreadPool();
    
    console.log('[ThreadManager] ✓ 线程管理器初始化完成');
    console.log(`[ThreadManager] 最大线程数: ${this.config.maxThreads}`);
  }

  private injectPythonThreading(): void {
    const pythonCode = `
import sys
import threading
import _thread
import time
from js import API

class EnhancedThread(threading.Thread):
    def __init__(self, group=None, target=None, name=None,
                 args=(), kwargs=None, *, daemon=None):
        super().__init__(group=group, target=target, name=name,
                        args=args, kwargs=kwargs, daemon=daemon)
        self._return_value = None
        self._exception = None
    
    def run(self):
        if self._target is not None:
            try:
                self._return_value = self._target(*self._args, **self._kwargs)
            except Exception as e:
                self._exception = e
                raise
    
    def join(self, timeout=None):
        super().join(timeout)
        if self._exception:
            raise self._exception
        return self._return_value

threading.Thread = EnhancedThread

class EnhancedLock:
    def __init__(self):
        self._locked = False
        self._lock = API._threadManager.createLock()
    
    def acquire(self, blocking=True, timeout=-1):
        if timeout > 0:
            return self._lock.acquire_timeout(timeout / 1000)
        elif blocking:
            while self._locked:
                time.sleep(0.001)
            self._locked = True
            return True
        else:
            if not self._locked:
                self._locked = True
                return True
            return False
    
    def release(self):
        self._locked = False
        self._lock.release()
    
    def __enter__(self):
        self.acquire()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()
        return False

threading.Lock = EnhancedLock
threading.RLock = EnhancedLock
threading.Semaphore = type('Semaphore', (), {
    '__init__': lambda self, value=1: setattr(self, '_value', value),
    'acquire': lambda self, blocking=True, timeout=-1: (
        setattr(self, '_value', self._value - 1) or True
    ) if self._value > 0 else False,
    'release': lambda self: setattr(self, '_value', self._value + 1),
})

threading.Event = type('Event', (), {
    '__init__': lambda self: (
        setattr(self, '_flag', False),
        setattr(self, '_lock', EnhancedLock())
    ),
    'is_set': lambda self: self._flag,
    'set': lambda self: (
        setattr(self, '_flag', True),
        self._lock.release()
    ),
    'clear': lambda self: setattr(self, '_flag', False),
    'wait': lambda self, timeout=None: (
        self._lock.acquire() if not self._flag else None
    ),
})

threading.Condition = type('Condition', (), {
    '__init__': lambda self, lock=None: (
        setattr(self, '_lock', lock or EnhancedLock()),
        setattr(self, '_cond', threading.Condition(lock))
    ),
    'acquire': lambda self: self._lock.acquire(),
    'release': lambda self: self._lock.release(),
    '__enter__': lambda self: self._lock.acquire(),
    '__exit__': lambda self, *args: self._lock.release(),
    'wait': lambda self, timeout=None: self._cond.wait(timeout),
    'notify': lambda self, n=1: self._cond.notify(n),
    'notify_all': lambda self: self._cond.notify_all(),
})

class ThreadPoolExecutor:
    def __init__(self, max_workers=None):
        import os
        self.max_workers = max_workers or (os.cpu_count() or 1) * 5
        self._workers = []
        self._work_queue = queue.Queue()
        self._shutdown = False
        self._shutdown_lock = threading.Lock()
    
    def submit(self, fn, *args, **kwargs):
        from concurrent.futures import Future
        future = Future()
        
        def run():
            try:
                if not self._shutdown:
                    result = fn(*args, **kwargs)
                    future.set_result(result)
                else:
                    future.set_exception(Exception("Executor shutdown"))
            except Exception as e:
                future.set_exception(e)
        
        thread = EnhancedThread(target=run, daemon=True)
        thread.start()
        return future
    
    def map(self, fn, *iterables, timeout=None, chunksize=1):
        futures = [self.submit(fn, *args) for args in zip(*iterables)]
        for future in futures:
            yield future.result(timeout=timeout)
    
    def shutdown(self, wait=True):
        with self._shutdown_lock:
            self._shutdown = True
        if wait:
            for thread in threading.enumerate():
                if thread != threading.current_thread() and not thread.daemon:
                    thread.join()

from concurrent.futures import ThreadPoolExecutor as TPE
sys.modules['concurrent.futures'].ThreadPoolExecutor = TPE

print("✓ 增强线程支持已启用")
print(f"  - 最大线程数: {threading.active_count()}")
print(f"  - 线程安全锁: 已配置")
`;

    try {
      API.runPythonInternal(pythonCode);
      console.log('[ThreadManager] Python 线程注入成功');
    } catch (error) {
      console.error('[ThreadManager] Python 线程注入失败:', error);
    }
  }

  private initializeGILSimulation(): void {
    console.log('[ThreadManager] 初始化 GIL 模拟...');
  }

  private injectThreadPool(): void {
    if (!this.config.enableThreadPool) {
      return;
    }

    const pythonCode = `
from concurrent.futures import ThreadPoolExecutor
import concurrent.futures

def get_thread_pool(max_workers=None):
    return ThreadPoolExecutor(max_workers=max_workers)

sys.modules['thread_pool'] = type('Module', (), {
    'create': get_thread_pool,
})()

print("✓ 线程池支持已启用")
`;

    try {
      API.runPythonInternal(pythonCode);
    } catch (error) {
      console.error('[ThreadManager] 线程池注入失败:', error);
    }
  }

  createLock(): ThreadLock {
    return new ThreadLock();
  }

  createThread(info: ThreadInfo): number {
    const id = ++this.threadIdCounter;
    this.threads.set(id, info);
    return id;
  }

  getThread(id: number): ThreadInfo | undefined {
    return this.threads.get(id);
  }

  removeThread(id: number): void {
    this.threads.delete(id);
  }

  getActiveCount(): number {
    return this.threads.size;
  }

  getAllThreads(): ThreadInfo[] {
    return Array.from(this.threads.values());
  }

  shutdown(wait: boolean = true): void {
    console.log('[ThreadManager] 关闭线程管理器...');
    
    for (const [id, thread] of this.threads.entries()) {
      if (thread.daemon) {
        thread.running = false;
        this.threads.delete(id);
      }
    }
    
    if (wait) {
      setTimeout(() => {
        this.threads.clear();
        console.log('[ThreadManager] 所有线程已关闭');
      }, 1000);
    }
  }
}

export interface ThreadInfo {
  id: number;
  name: string;
  daemon: boolean;
  running: boolean;
  started: number;
  target?: Function;
  args?: any[];
  kwargs?: any;
}

export class ThreadLock {
  private locked: boolean = false;
  private queue: Array<() => void> = [];

  acquire(blocking: boolean = true, timeout: number = -1): boolean {
    if (this.locked) {
      if (!blocking) {
        return false;
      }
      
      if (timeout > 0) {
        return this.acquireWithTimeout(timeout);
      }
      
      return new Promise<boolean>((resolve) => {
        this.queue.push(() => resolve(true));
      }) as any;
    }
    
    this.locked = true;
    return true;
  }

  private acquireWithTimeout(timeout: number): boolean {
    const startTime = Date.now();
    
    while (this.locked) {
      if (Date.now() - startTime >= timeout) {
        return false;
      }
    }
    
    this.locked = true;
    return true;
  }

  release(): void {
    if (this.queue.length > 0) {
      const next = this.queue.shift()!;
      next();
    } else {
      this.locked = false;
    }
  }

  locked(): boolean {
    return this.locked;
  }

  __enter__(): void {
    this.acquire();
  }

  __exit__(): void {
    this.release();
  }
}

export class Thread {
  private id: number;
  private name: string;
  private daemon: boolean;
  private target: Function | null;
  private args: any[];
  private kwargs: any;
  private running: boolean = false;
  private finished: boolean = false;
  private result: any = null;
  private exception: any = null;
  private worker: Worker | null = null;

  constructor(
    group?: any,
    target?: Function,
    name?: string,
    args: any[] = [],
    kwargs: any = {}
  ) {
    this.id = Date.now();
    this.name = name || `Thread-${this.id}`;
    this.daemon = false;
    this.target = target;
    this.args = args;
    this.kwargs = kwargs;
  }

  start(): void {
    if (this.running) {
      throw new Error('线程已启动');
    }
    
    this.running = true;
    
    if (typeof Worker !== 'undefined') {
      this.startWorker();
    } else {
      this.startAsync();
    }
  }

  private startWorker(): void {
    const workerCode = `
      self.onmessage = function(e) {
        try {
          const result = eval('(' + e.data.fn + ')()');
          self.postMessage({ success: true, result: result });
        } catch (error) {
          self.postMessage({ success: false, error: error.message });
        }
      };
    `;
    
    const blob = new Blob([workerCode], { type: 'application/javascript' });
    const workerURL = URL.createObjectURL(blob);
    
    this.worker = new Worker(workerURL);
    
    this.worker.onmessage = (e) => {
      this.running = false;
      this.finished = true;
      
      if (e.data.success) {
        this.result = e.data.result;
      } else {
        this.exception = new Error(e.data.error);
      }
    };
    
    this.worker.onerror = (error) => {
      this.running = false;
      this.finished = true;
      this.exception = error;
    };
    
    const fnString = this.target ? this.target.toString() : '() => {}';
    this.worker.postMessage({ fn: fnString, args: this.args, kwargs: this.kwargs });
  }

  private startAsync(): void {
    Promise.resolve().then(() => {
      try {
        if (this.target) {
          this.result = this.target(...this.args);
        }
      } catch (error) {
        this.exception = error;
      } finally {
        this.running = false;
        this.finished = true;
      }
    });
  }

  join(timeout?: number): any {
    if (!this.running && !this.finished) {
      throw new Error('线程未启动');
    }
    
    if (this.finished) {
      if (this.exception) {
        throw this.exception;
      }
      return this.result;
    }
    
    return new Promise((resolve, reject) => {
      const checkFinished = () => {
        if (this.finished) {
          if (this.exception) {
            reject(this.exception);
          } else {
            resolve(this.result);
          }
        } else {
          setTimeout(checkFinished, 10);
        }
      };
      
      checkFinished();
    });
  }

  is_alive(): boolean {
    return this.running;
  }

  getName(): string {
    return this.name;
  }

  setName(name: string): void {
    this.name = name;
  }

  isDaemon(): boolean {
    return this.daemon;
  }

  setDaemon(daemon: boolean): void {
    this.daemon = daemon;
  }

  get_id(): number {
    return this.id;
  }

  terminate(): void {
    if (this.worker) {
      this.worker.terminate();
    }
    this.running = false;
    this.finished = true;
  }
}

let globalThreadManager: ThreadManager | null = null;

export function getThreadManager(config?: ThreadConfig): ThreadManager {
  if (!globalThreadManager) {
    globalThreadManager = new ThreadManager(config);
  }
  return globalThreadManager;
}

export function initializeThreadManager(config?: ThreadConfig): ThreadManager {
  const manager = getThreadManager(config);
  manager.initialize();
  
  if (typeof API !== 'undefined') {
    API._threadManager = manager;
  }
  
  return manager;
}
