#define PY_SSIZE_T_CLEAN
#include "Python.h"
#include <emscripten.h>
#include <emscripten/eventloop.h>
#include <jslib.h>
#include <stdbool.h>

#define FAIL_IF_STATUS_EXCEPTION(status)                                       \
  if (PyStatus_Exception(status)) {                                            \
    goto finally;                                                              \
  }

// Initialize python. exit() and print message to stderr on failure.
static void
initialize_python(int argc, char** argv)
{
  bool success = false;
  PyStatus status;

  PyPreConfig preconfig;
  PyPreConfig_InitPythonConfig(&preconfig);

  status = Py_PreInitializeFromBytesArgs(&preconfig, argc, argv);
  FAIL_IF_STATUS_EXCEPTION(status);

  PyConfig config;
  PyConfig_InitPythonConfig(&config);

  status = PyConfig_SetBytesArgv(&config, argc, argv);
  FAIL_IF_STATUS_EXCEPTION(status);

  status = PyConfig_SetBytesString(&config, &config.home, "/");
  FAIL_IF_STATUS_EXCEPTION(status);

  config.write_bytecode = false;
  status = Py_InitializeFromConfig(&config);
  FAIL_IF_STATUS_EXCEPTION(status);

  success = true;
finally:
  PyConfig_Clear(&config);
  if (!success) {
    // This will exit().
    Py_ExitStatusException(status);
  }
}

PyObject*
PyInit__pyodide_core(void);

/**
 * Bootstrap steps here:
 *  1. Import _pyodide package (we depend on this in _pyodide_core)
 *  2. Initialize the different ffi components and create the _pyodide_core
 *     module
 *  3. Create a PyProxy wrapper around _pyodide package so that JavaScript can
 *     call into _pyodide._base.eval_code and
 *     _pyodide._import_hook.register_js_finder (this happens in loadPyodide in
 *     pyodide.js)
 */
int
main(int argc, char** argv)
{
  // This exits and prints a message to stderr on failure,
  // no status code to check.
  PyImport_AppendInittab("_pyodide_core", PyInit__pyodide_core);
  initialize_python(argc, argv);
  // Normally the runtime would exit when main() returns, don't let that
  // happen.
  emscripten_runtime_keepalive_push();
  return 0;
}

void
pymain_run_python(int* exitcode);

EMSCRIPTEN_KEEPALIVE int
run_main()
{
  int exitcode;
  // run_python may call exit() if `-h` or `-V` have been passed. If we stop it
  // from exiting, we'll segfault. So pop the keep alive, so that exit() will
  // call onExit and shut down the runtime. We notice this in pyodide.ts and
  // throw a ExitStatus error.
  emscripten_runtime_keepalive_pop();
  pymain_run_python(&exitcode);
  emscripten_runtime_keepalive_push();
  return exitcode;
}

void
set_suspender(JsVal suspender);

/**
 * call _pyproxy_apply but save the error flag into the argument so it can't be
 * observed by unrelated Python callframes. callPyObjectKwargsSuspending will
 * restore the error flag before calling pythonexc2js(). See
 * test_stack_switching.test_throw_from_switcher for a detailed explanation.
 */
EMSCRIPTEN_KEEPALIVE int
run_main_promising(JsVal suspender)
{
  set_suspender(suspender);
  return run_main();
}
