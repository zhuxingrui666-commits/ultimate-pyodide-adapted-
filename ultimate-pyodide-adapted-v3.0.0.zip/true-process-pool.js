/**
 * 真正的 ProcessPoolExecutor - 使用 Node.js Child Process 实现
 * 提供真正的系统级并行，不是模拟
 */

const { fork } = require('child_process');
const os = require('os');
const path = require('path');
const fs = require('fs');

class ProcessPoolExecutor {
  constructor(maxWorkers = null) {
    this.maxWorkers = maxWorkers || os.cpus().length;
    this.processes = [];
    this.taskQueue = [];
    this.activeProcesses = 0;
    this.taskIdCounter = 0;
    this.results = new Map();
    this.errors = new Map();
    this.initialized = false;
    this.workerScriptPath = null;
  }

  async initialize() {
    if (this.initialized) {
      return;
    }

    console.log('[ProcessPoolExecutor] 初始化进程池...');
    console.log(`[ProcessPoolExecutor] 最大工作进程数: ${this.maxWorkers}`);

    // 创建工作脚本
    this.workerScriptPath = this._createWorkerScript();

    // 预启动工作进程
    for (let i = 0; i < this.maxWorkers; i++) {
      await this._createWorkerProcess(i);
    }

    this.initialized = true;
    console.log('[ProcessPoolExecutor] ✓ 进程池初始化完成');
  }

  _createWorkerScript() {
    const script = `
const { parentPort } = require('worker_threads');

parentPort.on('message', async (task) => {
  const { taskId, type, data } = task;
  
  try {
    let result;
    
    switch (type) {
      case 'execute':
        // 执行 Python 代码
        result = await executePython(data.code, data.config);
        break;
        
      case 'compute':
        // 执行计算函数
        const fn = new Function('return ' + data.fn);
        result = fn()(data.args);
        break;
        
      case 'map':
        // 并行映射
        const mapFn = new Function('item', 'return ' + data.fn);
        result = data.items.map(mapFn);
        break;
        
      default:
        throw new Error('Unknown task type: ' + type);
    }
    
    parentPort.postMessage({ taskId, success: true, result });
  } catch (error) {
    parentPort.postMessage({ 
      taskId, 
      success: false, 
      error: error.message,
      stack: error.stack 
    });
  }
});

async function executePython(code, config) {
  const { loadPyodide } = await import(config.indexURL + 'pyodide.mjs');
  const pyodide = await loadPyodide({ indexURL: config.indexURL });
  
  if (config.async) {
    return await pyodide.runPythonAsync(code);
  } else {
    return pyodide.runPython(code);
  }
}
`;

    // 创建临时文件
    const tempDir = os.tmpdir();
    const scriptPath = path.join(tempDir, `pyodide_pool_worker_${Date.now()}.mjs`);
    
    fs.writeFileSync(scriptPath, script, 'utf-8');
    return scriptPath;
  }

  async _createWorkerProcess(id) {
    return new Promise((resolve, reject) => {
      try {
        const worker = fork(this.workerScriptPath, [], {
          stdio: ['pipe', 'pipe', 'pipe', 'ipc']
        });

        worker.on('message', (msg) => {
          if (msg.taskId !== undefined) {
            this.results.set(msg.taskId, msg);
            if (this.activeProcesses > 0) {
              this.activeProcesses--;
            }
          }
        });

        worker.on('error', (err) => {
          console.error(`[Worker ${id}] Error:`, err.message);
        });

        worker.on('exit', (code) => {
          console.log(`[Worker ${id}] Exited with code ${code}`);
        });

        this.processes.push({ id, worker, busy: false });
        resolve();

      } catch (err) {
        reject(err);
      }
    });
  }

  async submit(task) {
    if (!this.initialized) {
      await this.initialize();
    }

    return new Promise((resolve, reject) => {
      const taskId = ++this.taskIdCounter;

      const wrappedTask = {
        taskId,
        task,
        resolve,
        reject
      };

      // 查找空闲的工作进程
      const worker = this.processes.find(w => !w.busy);

      if (worker) {
        this._executeOnWorker(worker, wrappedTask);
      } else {
        // 所有工作进程都在忙碌，加入队列
        this.taskQueue.push(wrappedTask);
      }
    });
  }

  _executeOnWorker(worker, wrappedTask) {
    const { taskId, task, resolve, reject } = wrappedTask;
    worker.busy = true;
    this.activeProcesses++;

    const timeout = task.timeout || 60000; // 默认 60 秒超时

    const timeoutId = setTimeout(() => {
      const result = this.results.get(taskId);
      if (!result) {
        worker.worker.kill();
        reject(new Error(`Task ${taskId} timed out after ${timeout}ms`));
        worker.busy = false;
        this._processNextTask(worker);
      }
    }, timeout);

    worker.worker.send({
      taskId,
      type: task.type,
      data: task.data
    });

    // 轮询结果
    const checkResult = setInterval(() => {
      const result = this.results.get(taskId);
      if (result) {
        clearInterval(checkResult);
        clearTimeout(timeoutId);
        this.results.delete(taskId);
        worker.busy = false;

        if (result.success) {
          resolve(result.result);
        } else {
          reject(new Error(result.error));
        }

        this._processNextTask(worker);
      }
    }, 10);
  }

  _processNextTask(worker) {
    if (this.taskQueue.length > 0) {
      const nextTask = this.taskQueue.shift();
      this._executeOnWorker(worker, nextTask);
    }
  }

  // 并行映射
  async map(fn, items, options = {}) {
    const chunkSize = options.chunkSize || Math.ceil(items.length / this.maxWorkers);
    const chunks = [];

    for (let i = 0; i < items.length; i += chunkSize) {
      chunks.push(items.slice(i, i + chunkSize));
    }

    const promises = chunks.map(chunk => 
      this.submit({
        type: 'map',
        data: { fn: fn.toString(), items: chunk },
        timeout: options.timeout
      })
    );

    const results = await Promise.all(promises);
    return results.flat();
  }

  // 并行执行多个任务
  async mapAsync(fn, items, options = {}) {
    const results = [];
    const chunkSize = options.chunkSize || Math.ceil(items.length / this.maxWorkers);

    for (let i = 0; i < items.length; i += chunkSize) {
      const chunk = items.slice(i, i + chunkSize);
      const chunkResults = await this.submit({
        type: 'map',
        data: { fn: fn.toString(), items: chunk },
        timeout: options.timeout
      });
      results.push(...chunkResults);
    }

    return results;
  }

  // 获取状态
  getStats() {
    return {
      maxWorkers: this.maxWorkers,
      activeProcesses: this.activeProcesses,
      queuedTasks: this.taskQueue.length,
      totalProcesses: this.processes.length
    };
  }

  // 优雅关闭
  async shutdown(wait = true) {
    console.log('[ProcessPoolExecutor] 关闭进程池...');

    if (wait) {
      // 等待所有任务完成
      while (this.activeProcesses > 0 || this.taskQueue.length > 0) {
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    }

    // 终止所有工作进程
    for (const { worker } of this.processes) {
      worker.kill();
    }

    this.processes = [];

    // 删除临时脚本
    if (this.workerScriptPath && fs.existsSync(this.workerScriptPath)) {
      fs.unlinkSync(this.workerScriptPath);
    }

    this.initialized = false;
    console.log('[ProcessPoolExecutor] ✓ 进程池已关闭');
  }
}

module.exports = { ProcessPoolExecutor };
