/**
 * Ultimate Pyodide 核心模块测试
 * 测试所有核心功能是否正常工作
 */

const fs = require('fs');
const path = require('path');
const { loadUltimatePyodide } = require('./ultimate-pyodide-core.js');

async function runTests() {
  console.log('='.repeat(80));
  console.log('Ultimate Pyodide 核心模块测试');
  console.log('='.repeat(80));
  console.log();

  try {
    console.log('[测试] 加载 Ultimate Pyodide...');
    const pyodide = await loadUltimatePyodide({
      enableFullFS: true,
      enableFullNetwork: true,
      enableProcessAccess: true
    });
    console.log('✓ Pyodide 加载成功');
    console.log();

    console.log('[测试 1] 基础 Python 执行');
    console.log('-'.repeat(80));
    const result = pyodide.runPython('2 + 2');
    console.log(`✓ 2 + 2 = ${result}`);
    console.log();

    console.log('[测试 2] 访问系统信息');
    console.log('-'.repeat(80));
    pyodide.runPython(`
import pyodide_node

print(f"平台: {pyodide_node.get_platform()}")
print(f"进程 ID: {pyodide_node.get_pid()}")
print(f"当前目录: {pyodide_node.get_cwd()}")
print(f"环境变量数量: {len(pyodide_node.get_env())}")
`);
    console.log('✓ 系统信息访问成功');
    console.log();

    console.log('[测试 3] 文件系统操作');
    console.log('-'.repeat(80));
    const testFile = path.join(__dirname, 'test_output.txt');
    const testContent = 'Hello from Ultimate Pyodide!\nTest successful!';

    pyodide.runPython(`
import pyodide_node

test_file = "${testFile.replace(/\\/g, '\\\\')}"
test_content = """${testContent.replace(/"""/g, '\\"\\"\\"')}"""

pyodide_node.write_file(test_file, test_content)
print(f"✓ 写入文件: {test_file}")

content = pyodide_node.read_file(test_file)
print(f"✓ 读取文件: {content.strip()[:50]}...")

print(f"✓ 文件存在: {pyodide_node.file_exists(test_file)}")

stat = pyodide_node.file_stat(test_file)
print(f"✓ 文件大小: {stat['size']} bytes")

files = pyodide_node.list_dir("${path.dirname(testFile).replace(/\\/g, '\\\\')}")
print(f"✓ 目录包含 {len(files)} 个项目")

pyodide_node.delete_file(test_file)
print(f"✓ 删除文件: {test_file}")
`);
    console.log('✓ 文件系统操作成功');
    console.log();

    console.log('[测试 4] 进程管理');
    console.log('-'.repeat(80));
    pyodide.runPython(`
import pyodide_node

result = pyodide_node.exec_command_sync('echo "Hello from shell!"')
print(f"✓ 命令执行: {result.trim()}")

pid = pyodide_node.get_pid()
print(f"✓ 当前进程 ID: {pid}")
`);
    console.log('✓ 进程管理成功');
    console.log();

    console.log('='.repeat(80));
    console.log('✓ 所有测试通过！');
    console.log('='.repeat(80));
    console.log();
    console.log('🎉 Ultimate Pyodide 核心模块工作正常！');
    console.log();

    return true;

  } catch (error) {
    console.error('✗ 测试失败:', error);
    console.error(error.stack);
    return false;
  }
}

if (require.main === module) {
  runTests()
    .then(success => {
      process.exit(success ? 0 : 1);
    })
    .catch(error => {
      console.error('✗ 未捕获的错误:', error);
      process.exit(1);
    });
}

module.exports = { runTests };
