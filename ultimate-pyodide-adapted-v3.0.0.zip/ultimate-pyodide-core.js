/**
 * Ultimate Pyodide - 简化版核心
 * 可以直接在 Node.js 中使用，无需编译
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const net = require('net');
const tls = require('tls');
const { URL } = require('url');

class PyodideNode {
  constructor(pyodide, config = {}) {
    this.pyodide = pyodide;
    this.config = {
      enableFullFS: true,
      enableFullNetwork: true,
      enableProcessAccess: true,
      ...config
    };
    this.initialized = false;
  }

  async initialize() {
    if (this.initialized) {
      return;
    }

    console.log('[UltimatePyodide] 初始化中...');

    if (this.config.enableFullFS) {
      this.injectFileSystem();
    }

    if (this.config.enableFullNetwork) {
      this.injectNetwork();
    }

    if (this.config.enableProcessAccess) {
      this.injectProcess();
    }

    this.injectPyodideNode();

    this.initialized = true;
    console.log('[UltimatePyodide] ✓ 初始化完成');
  }

  injectFileSystem() {
    this.pyodide.runPython(`
import sys

class PyodideNodeFileSystem:
    @staticmethod
    def read_file(filepath, encoding=None):
        if encoding:
            with open(filepath, 'r', encoding=encoding) as f:
                return f.read()
        else:
            with open(filepath, 'rb') as f:
                return f.read()

    @staticmethod
    def write_file(filepath, data, encoding=None):
        import os
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        if isinstance(data, str) and encoding:
            with open(filepath, 'w', encoding=encoding) as f:
                f.write(data)
        elif isinstance(data, str):
            with open(filepath, 'w') as f:
                f.write(data)
        else:
            with open(filepath, 'wb') as f:
                f.write(data)

    @staticmethod
    def list_dir(dirpath):
        import os
        return os.listdir(dirpath)

    @staticmethod
    def file_exists(filepath):
        import os
        return os.path.exists(filepath)

    @staticmethod
    def make_dir(dirpath, recursive=True):
        import os
        os.makedirs(dirpath, exist_ok=recursive)

    @staticmethod
    def delete_file(filepath):
        import os
        os.remove(filepath)

    @staticmethod
    def file_stat(filepath):
        import os
        stat = os.stat(filepath)
        return {
            'size': stat.size,
            'mtime': stat.mtime,
            'ctime': stat.ctime,
            'is_file': stat.is_file(),
            'is_dir': stat.is_dir()
        }

sys.modules['pyodide_node_fs'] = PyodideNodeFileSystem()
`);

    console.log('[UltimatePyodide] ✓ 文件系统注入完成');
  }

  injectNetwork() {
    this.pyodide.runPython(`
import sys

class PyodideNodeNetwork:
    def __init__(self):
        self._active_connections = {}

    def http_get(self, url, headers=None):
        import urllib.request
        req = urllib.request.Request(url, headers=headers or {})
        response = urllib.request.urlopen(req, timeout=30)
        return {
            'status': response.status,
            'headers': dict(response.headers),
            'body': response.read().decode('utf-8')
        }

    def http_post(self, url, data, headers=None):
        import urllib.request
        req = urllib.request.Request(
            url,
            data=data.encode('utf-8') if isinstance(data, str) else data,
            headers=headers or {},
            method='POST'
        )
        response = urllib.request.urlopen(req, timeout=30)
        return {
            'status': response.status,
            'headers': dict(response.headers),
            'body': response.read().decode('utf-8')
        }

sys.modules['pyodide_node_network'] = PyodideNodeNetwork()
`);

    console.log('[UltimatePyodide] ✓ 网络注入完成');
  }

  injectProcess() {
    this.pyodide.runPython(`
import sys
import os

class PyodideNodeProcess:
    @staticmethod
    def get_pid():
        return os.getpid()

    @staticmethod
    def get_cwd():
        return os.getcwd()

    @staticmethod
    def change_dir(path):
        os.chdir(path)

    @staticmethod
    def get_env():
        return dict(os.environ)

    @staticmethod
    def get_platform():
        import platform
        return platform.platform()

    @staticmethod
    def exec_command_sync(command):
        import subprocess
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True
        )
        return result.stdout

    @staticmethod
    def kill_process(pid):
        import os
        import signal
        os.kill(pid, signal.SIGTERM)

sys.modules['pyodide_node_process'] = PyodideNodeProcess()
`);

    console.log('[UltimatePyodide] ✓ 进程管理注入完成');
  }

  injectPyodideNode() {
    this.pyodide.runPython(`
import sys
from pyodide_node_fs import PyodideNodeFileSystem
from pyodide_node_network import PyodideNodeNetwork
from pyodide_node_process import PyodideNodeProcess

class PyodideNode:
    FS = PyodideNodeFileSystem()
    Network = PyodideNodeNetwork()
    Process = PyodideNodeProcess()

    @staticmethod
    def read_file(filepath, encoding=None):
        return PyodideNodeFileSystem.read_file(filepath, encoding)

    @staticmethod
    def write_file(filepath, data, encoding=None):
        return PyodideNodeFileSystem.write_file(filepath, data, encoding)

    @staticmethod
    def list_dir(dirpath):
        return PyodideNodeFileSystem.list_dir(dirpath)

    @staticmethod
    def file_exists(filepath):
        return PyodideNodeFileSystem.file_exists(filepath)

    @staticmethod
    def make_dir(dirpath, recursive=True):
        return PyodideNodeFileSystem.make_dir(dirpath, recursive)

    @staticmethod
    def delete_file(filepath):
        return PyodideNodeFileSystem.delete_file(filepath)

    @staticmethod
    def file_stat(filepath):
        return PyodideNodeFileSystem.file_stat(filepath)

    @staticmethod
    def exec_command_sync(command):
        return PyodideNodeProcess.exec_command_sync(command)

    @staticmethod
    def get_pid():
        return PyodideNodeProcess.get_pid()

    @staticmethod
    def get_cwd():
        return PyodideNodeProcess.get_cwd()

    @staticmethod
    def change_dir(path):
        return PyodideNodeProcess.change_dir(path)

    @staticmethod
    def get_env():
        return PyodideNodeProcess.get_env()

    @staticmethod
    def get_platform():
        return PyodideNodeProcess.get_platform()

    @staticmethod
    def http_get(url, headers=None):
        return PyodideNodeNetwork().http_get(url, headers)

    @staticmethod
    def http_post(url, data, headers=None):
        return PyodideNodeNetwork().http_post(url, data, headers)

sys.modules['pyodide_node'] = PyodideNode()
`);

    console.log('[UltimatePyodide] ✓ pyodide_node 模块注入完成');
  }

  runPython(code) {
    return this.pyodide.runPython(code);
  }

  runPythonAsync(code) {
    return this.pyodide.runPythonAsync(code);
  }

  loadPackage(packages) {
    return this.pyodide.loadPackage(packages);
  }
}

async function loadUltimatePyodide(config = {}) {
  const indexURL = config.indexURL || 'https://cdn.jsdelivr.net/pyodide/v0.26.0/full/';
  const loadPyodideURL = `${indexURL}pyodide.js`;

  console.log('[UltimatePyodide] 加载 Pyodide 核心...');
  await import(loadPyodideURL);

  const pyodideInstance = await globalThis.loadPyodide({ indexURL });

  console.log('[UltimatePyodide] Pyodide 版本:', pyodideInstance.version);

  const pyodideNode = new PyodideNode(pyodideInstance, config);
  await pyodideNode.initialize();

  return pyodideNode;
}

module.exports = {
  loadUltimatePyodide,
  PyodideNode
};
