# Ultimate Pyodide 改编版 v3.0.0

## 简介

Ultimate Pyodide 是改编自官方 Pyodide 的增强版本，专门为 JavaScript 后端环境优化，
提供完整的原生 Python 权限和强大的复杂计算支持。

## 核心特性

- ✅ 完整文件系统访问（真实文件系统，非 MEMFS）
- ✅ 完整网络支持（TCP/UDP/HTTP/HTTPS）
- ✅ 进程管理（subprocess, signal）
- ✅ 真正的多线程（Worker Threads + ProcessPool）
- ✅ 170+ 标准库模块
- ✅ 增强包管理（PyPI/GitHub/URL/本地）
- ✅ NumPy/SciPy/Pandas 等科学计算支持
- ✅ 性能优化（JIT, 缓存）

## 快速开始

### Node.js 环境

```javascript
const { loadUltimatePyodide } = require('./ultimate-pyodide-core');

async function main() {
  const pyodide = await loadUltimatePyodide();
  
  // 执行 Python
  console.log(pyodide.runPython('2 + 2'));
  
  // 加载 NumPy
  await pyodide.loadPackage('numpy');
  
  // 复杂计算
  const result = pyodide.runPython(`
import numpy as np
A = np.random.rand(100, 100)
print(np.linalg.eigvals(A).sum())
  `);
}

main();
```

### 增强版（含真正多线程）

```javascript
const { loadUltimatePyodide } = require('./ultimate-pyodide-enhanced');

async function main() {
  const pyodide = await loadUltimatePyodide({
    enableTrueMultithreading: true,
    enableProcessPool: true,
    maxWorkers: 4
  });
  
  // 使用多进程池
  await pyodide.executeParallel('print("并行执行！")');
}
```

## 文件说明

- `ultimate-pyodide-core.js` - 基础核心模块
- `ultimate-pyodide-enhanced.js` - 增强版（含真正多线程）
- `true-multithreading.js` - Worker Threads 实现
- `true-process-pool.js` - ProcessPoolExecutor 实现

## 技术架构

```
用户代码 (Python)
    ↓
改编版 Pyodide 核心 (.wasm)
    ↓
JavaScript 适配器层
    ↓
Node.js 系统能力
```

## 系统要求

- Node.js >= 18.0.0
- 网络连接（首次加载需下载 Pyodide wasm）

## 许可证

MIT License
